package com.google.android.gms.internal;

public interface zzbrh {
    boolean zza(zzbri zzbri);

    boolean zzg(Class<?> cls);
}
