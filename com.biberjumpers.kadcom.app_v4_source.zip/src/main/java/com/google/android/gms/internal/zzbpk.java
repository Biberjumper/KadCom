package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbpe.zza;

public class zzbpk extends zzbpb<zzbpk> {
    private final String value;

    public zzbpk(String str, zzbpe zzbpe) {
        super(zzbpe);
        this.value = str;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zzbpk)) {
            return false;
        }
        zzbpk zzbpk = (zzbpk) obj;
        return this.value.equals(zzbpk.value) && this.zzcgQ.equals(zzbpk.zzcgQ);
    }

    public Object getValue() {
        return this.value;
    }

    public int hashCode() {
        return this.value.hashCode() + this.zzcgQ.hashCode();
    }

    protected zza zzYV() {
        return zza.String;
    }

    protected int zza(zzbpk zzbpk) {
        return this.value.compareTo(zzbpk.value);
    }

    public String zza(zza zza) {
        String valueOf;
        String str;
        switch (zza) {
            case V1:
                valueOf = String.valueOf(zzb(zza));
                str = this.value;
                return new StringBuilder((String.valueOf(valueOf).length() + 7) + String.valueOf(str).length()).append(valueOf).append("string:").append(str).toString();
            case V2:
                valueOf = String.valueOf(zzb(zza));
                str = String.valueOf(zzbqg.zzjj(this.value));
                return new StringBuilder((String.valueOf(valueOf).length() + 7) + String.valueOf(str).length()).append(valueOf).append("string:").append(str).toString();
            default:
                str = String.valueOf(zza);
                throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 38).append("Invalid hash version for string node: ").append(str).toString());
        }
    }

    public /* synthetic */ zzbpe zzg(zzbpe zzbpe) {
        return zzs(zzbpe);
    }

    public zzbpk zzs(zzbpe zzbpe) {
        return new zzbpk(this.value, zzbpe);
    }
}
