package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbpe.zza;
import java.util.Map;

public class zzbov extends zzbpb<zzbov> {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbov.class.desiredAssertionStatus());
    private Map<Object, Object> zzchf;

    public zzbov(Map<Object, Object> map, zzbpe zzbpe) {
        super(zzbpe);
        this.zzchf = map;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zzbov)) {
            return false;
        }
        zzbov zzbov = (zzbov) obj;
        return this.zzchf.equals(zzbov.zzchf) && this.zzcgQ.equals(zzbov.zzcgQ);
    }

    public Object getValue() {
        return this.zzchf;
    }

    public int hashCode() {
        return this.zzchf.hashCode() + this.zzcgQ.hashCode();
    }

    protected zza zzYV() {
        return zza.DeferredValue;
    }

    public String zza(zza zza) {
        String valueOf = String.valueOf(zzb(zza));
        String valueOf2 = String.valueOf(this.zzchf);
        return new StringBuilder((String.valueOf(valueOf).length() + 14) + String.valueOf(valueOf2).length()).append(valueOf).append("deferredValue:").append(valueOf2).toString();
    }

    public /* synthetic */ zzbpe zzg(zzbpe zzbpe) {
        return zzj(zzbpe);
    }

    public zzbov zzj(zzbpe zzbpe) {
        if ($assertionsDisabled || zzbpi.zzq(zzbpe)) {
            return new zzbov(this.zzchf, zzbpe);
        }
        throw new AssertionError();
    }
}
