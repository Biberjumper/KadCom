package com.google.android.gms.common.stats;

import android.content.ComponentName;

public final class zzc {
    public static int LOG_LEVEL_OFF = 0;
    public static final ComponentName zzaGj = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
    public static int zzaGk = 1;
    public static int zzaGl = 2;
    public static int zzaGm = 4;
    public static int zzaGn = 8;
    public static int zzaGo = 16;
    public static int zzaGp = 32;
    public static int zzaGq = 1;
}
