package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzbsd<T> {
    public abstract void zza(zzbtk zzbtk, T t) throws IOException;

    public final zzbrr zzaL(T t) {
        try {
            zzbtk zzbsz = new zzbsz();
            zza(zzbsz, t);
            return zzbsz.zzabU();
        } catch (Throwable e) {
            throw new zzbrs(e);
        }
    }

    public abstract T zzb(zzbti zzbti) throws IOException;
}
