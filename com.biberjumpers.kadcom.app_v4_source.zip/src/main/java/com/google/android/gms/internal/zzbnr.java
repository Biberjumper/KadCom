package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbns.zza;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class zzbnr {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbnr.class.desiredAssertionStatus());
    private static final zzbnt<Map<zzbod, zzbnq>> zzcfi = new zzbnt<Map<zzbod, zzbnq>>() {
        public boolean zzaC(Map<zzbod, zzbnq> map) {
            zzbnq zzbnq = (zzbnq) map.get(zzbod.zzcfX);
            return zzbnq != null && zzbnq.zzcfg;
        }

        public /* synthetic */ boolean zzaq(Object obj) {
            return zzaC((Map) obj);
        }
    };
    private static final zzbnt<Map<zzbod, zzbnq>> zzcfj = new zzbnt<Map<zzbod, zzbnq>>() {
        public boolean zzaC(Map<zzbod, zzbnq> map) {
            zzbnq zzbnq = (zzbnq) map.get(zzbod.zzcfX);
            return zzbnq != null && zzbnq.zzcfh;
        }

        public /* synthetic */ boolean zzaq(Object obj) {
            return zzaC((Map) obj);
        }
    };
    private static final zzbnt<zzbnq> zzcfk = new zzbnt<zzbnq>() {
        public /* synthetic */ boolean zzaq(Object obj) {
            return zzc((zzbnq) obj);
        }

        public boolean zzc(zzbnq zzbnq) {
            return !zzbnq.zzcfh;
        }
    };
    private static final zzbnt<zzbnq> zzcfl = new zzbnt<zzbnq>() {
        public /* synthetic */ boolean zzaq(Object obj) {
            return zzc((zzbnq) obj);
        }

        public boolean zzc(zzbnq zzbnq) {
            return !zzbnr.zzcfk.zzaq(zzbnq);
        }
    };
    private final zzbop zzbYx;
    private final zzbno zzceT;
    private zzbns<Map<zzbod, zzbnq>> zzcfm;
    private final zzbpy zzcfn;
    private long zzcfo = 0;

    public zzbnr(zzbno zzbno, zzbop zzbop, zzbpy zzbpy) {
        this.zzceT = zzbno;
        this.zzbYx = zzbop;
        this.zzcfn = zzbpy;
        this.zzcfm = new zzbns(null);
        zzYa();
        for (zzbnq zzbnq : this.zzceT.zzVg()) {
            this.zzcfo = Math.max(zzbnq.id + 1, this.zzcfo);
            zzb(zzbnq);
        }
    }

    private boolean zzE(zzbmj zzbmj) {
        return this.zzcfm.zza(zzbmj, zzcfi) != null;
    }

    private Set<Long> zzF(zzbmj zzbmj) {
        Set<Long> hashSet = new HashSet();
        Map map = (Map) this.zzcfm.zzK(zzbmj);
        if (map != null) {
            for (zzbnq zzbnq : map.values()) {
                if (!zzbnq.zzcfe.zzYD()) {
                    hashSet.add(Long.valueOf(zzbnq.id));
                }
            }
        }
        return hashSet;
    }

    private void zzYa() {
        try {
            this.zzceT.beginTransaction();
            this.zzceT.zzaC(this.zzcfn.zzZY());
            this.zzceT.setTransactionSuccessful();
        } finally {
            this.zzceT.endTransaction();
        }
    }

    private static long zza(zzbnj zzbnj, long j) {
        return j - Math.min((long) Math.floor((double) ((1.0f - zzbnj.zzXV()) * ((float) j))), zzbnj.zzXW());
    }

    private List<zzbnq> zza(zzbnt<zzbnq> zzbnt) {
        List<zzbnq> arrayList = new ArrayList();
        Iterator it = this.zzcfm.iterator();
        while (it.hasNext()) {
            for (zzbnq zzbnq : ((Map) ((Entry) it.next()).getValue()).values()) {
                if (zzbnt.zzaq(zzbnq)) {
                    arrayList.add(zzbnq);
                }
            }
        }
        return arrayList;
    }

    private void zza(zzbnq zzbnq) {
        zzb(zzbnq);
        this.zzceT.zza(zzbnq);
    }

    private void zzb(zzbnq zzbnq) {
        Map map;
        zzj(zzbnq.zzcfe);
        Map map2 = (Map) this.zzcfm.zzK(zzbnq.zzcfe.zzVc());
        if (map2 == null) {
            map2 = new HashMap();
            this.zzcfm = this.zzcfm.zzb(zzbnq.zzcfe.zzVc(), (Object) map2);
            map = map2;
        } else {
            map = map2;
        }
        zzbnq zzbnq2 = (zzbnq) map.get(zzbnq.zzcfe.zzYG());
        boolean z = zzbnq2 == null || zzbnq2.id == zzbnq.id;
        zzbqg.zzaW(z);
        map.put(zzbnq.zzcfe.zzYG(), zzbnq);
    }

    private void zzb(zzboe zzboe, boolean z) {
        zzboe zzk = zzk(zzboe);
        zzbnq zzl = zzl(zzk);
        long zzZY = this.zzcfn.zzZY();
        if (zzl != null) {
            zzl = zzl.zzaO(zzZY).zzbb(z);
        } else if ($assertionsDisabled || z) {
            long j = this.zzcfo;
            this.zzcfo = 1 + j;
            zzl = new zzbnq(j, zzk, zzZY, false, z);
        } else {
            throw new AssertionError("If we're setting the query to inactive, we should already be tracking it!");
        }
        zza(zzl);
    }

    private static void zzj(zzboe zzboe) {
        boolean z = !zzboe.zzYD() || zzboe.isDefault();
        zzbqg.zzb(z, "Can't have tracked non-default query that loads all data");
    }

    private static zzboe zzk(zzboe zzboe) {
        return zzboe.zzYD() ? zzboe.zzN(zzboe.zzVc()) : zzboe;
    }

    public void zzA(zzbmj zzbmj) {
        this.zzcfm.zzI(zzbmj).zza(new zza<Map<zzbod, zzbnq>, Void>(this) {
            final /* synthetic */ zzbnr zzcfp;

            {
                this.zzcfp = r1;
            }

            public Void zza(zzbmj zzbmj, Map<zzbod, zzbnq> map, Void voidR) {
                for (Entry value : map.entrySet()) {
                    zzbnq zzbnq = (zzbnq) value.getValue();
                    if (!zzbnq.zzcfg) {
                        this.zzcfp.zza(zzbnq.zzXZ());
                    }
                }
                return null;
            }
        });
    }

    public Set<zzbos> zzB(zzbmj zzbmj) {
        if ($assertionsDisabled || !zzo(zzboe.zzN(zzbmj))) {
            Set<zzbos> hashSet = new HashSet();
            Set zzF = zzF(zzbmj);
            if (!zzF.isEmpty()) {
                hashSet.addAll(this.zzceT.zzg(zzF));
            }
            Iterator it = this.zzcfm.zzI(zzbmj).zzYe().iterator();
            while (it.hasNext()) {
                Entry entry = (Entry) it.next();
                zzbos zzbos = (zzbos) entry.getKey();
                zzbns zzbns = (zzbns) entry.getValue();
                if (zzbns.getValue() != null && zzcfi.zzaq((Map) zzbns.getValue())) {
                    hashSet.add(zzbos);
                }
            }
            return hashSet;
        }
        throw new AssertionError("Path is fully complete.");
    }

    public void zzC(zzbmj zzbmj) {
        if (!zzE(zzbmj)) {
            zzboe zzN = zzboe.zzN(zzbmj);
            zzbnq zzl = zzl(zzN);
            if (zzl == null) {
                long j = this.zzcfo;
                this.zzcfo = 1 + j;
                zzl = new zzbnq(j, zzN, this.zzcfn.zzZY(), true, false);
            } else if ($assertionsDisabled || !zzl.zzcfg) {
                zzl = zzl.zzXZ();
            } else {
                throw new AssertionError("This should have been handled above!");
            }
            zza(zzl);
        }
    }

    public boolean zzD(zzbmj zzbmj) {
        return this.zzcfm.zzb(zzbmj, zzcfj) != null;
    }

    public long zzYb() {
        return (long) zza(zzcfk).size();
    }

    public zzbnp zza(zzbnj zzbnj) {
        List zza = zza(zzcfk);
        long zza2 = zza(zzbnj, (long) zza.size());
        zzbnp zzbnp = new zzbnp();
        if (this.zzbYx.zzYT()) {
            this.zzbYx.zzi("Pruning old queries.  Prunable: " + zza.size() + " Count to prune: " + zza2, new Object[0]);
        }
        Collections.sort(zza, new Comparator<zzbnq>(this) {
            public /* synthetic */ int compare(Object obj, Object obj2) {
                return zza((zzbnq) obj, (zzbnq) obj2);
            }

            public int zza(zzbnq zzbnq, zzbnq zzbnq2) {
                return zzbqg.zzj(zzbnq.zzcff, zzbnq2.zzcff);
            }
        });
        for (int i = 0; ((long) i) < zza2; i++) {
            zzbnq zzbnq = (zzbnq) zza.get(i);
            zzbnp = zzbnp.zzy(zzbnq.zzcfe.zzVc());
            zzm(zzbnq.zzcfe);
        }
        zzbnp zzbnp2 = zzbnp;
        for (int i2 = (int) zza2; i2 < zza.size(); i2++) {
            zzbnp2 = zzbnp2.zzz(((zzbnq) zza.get(i2)).zzcfe.zzVc());
        }
        List<zzbnq> zza3 = zza(zzcfl);
        if (this.zzbYx.zzYT()) {
            this.zzbYx.zzi("Unprunable queries: " + zza3.size(), new Object[0]);
        }
        for (zzbnq zzbnq2 : zza3) {
            zzbnp2 = zzbnp2.zzz(zzbnq2.zzcfe.zzVc());
        }
        return zzbnp2;
    }

    public void zzg(zzboe zzboe) {
        zzb(zzboe, true);
    }

    public void zzh(zzboe zzboe) {
        zzb(zzboe, false);
    }

    public zzbnq zzl(zzboe zzboe) {
        zzboe zzk = zzk(zzboe);
        Map map = (Map) this.zzcfm.zzK(zzk.zzVc());
        return map != null ? (zzbnq) map.get(zzk.zzYG()) : null;
    }

    public void zzm(zzboe zzboe) {
        zzboe zzk = zzk(zzboe);
        zzbnq zzl = zzl(zzk);
        if ($assertionsDisabled || zzl != null) {
            this.zzceT.zzaB(zzl.id);
            Map map = (Map) this.zzcfm.zzK(zzk.zzVc());
            map.remove(zzk.zzYG());
            if (map.isEmpty()) {
                this.zzcfm = this.zzcfm.zzJ(zzk.zzVc());
                return;
            }
            return;
        }
        throw new AssertionError("Query must exist to be removed.");
    }

    public void zzn(zzboe zzboe) {
        zzbnq zzl = zzl(zzk(zzboe));
        if (zzl != null && !zzl.zzcfg) {
            zza(zzl.zzXZ());
        }
    }

    public boolean zzo(zzboe zzboe) {
        if (zzE(zzboe.zzVc())) {
            return true;
        }
        if (zzboe.zzYD()) {
            return false;
        }
        Map map = (Map) this.zzcfm.zzK(zzboe.zzVc());
        boolean z = map != null && map.containsKey(zzboe.zzYG()) && ((zzbnq) map.get(zzboe.zzYG())).zzcfg;
        return z;
    }
}
