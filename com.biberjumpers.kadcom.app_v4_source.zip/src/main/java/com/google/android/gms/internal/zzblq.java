package com.google.android.gms.internal;

public interface zzblq {
    String zzVM();

    boolean zzVN();

    zzblk zzVO();
}
