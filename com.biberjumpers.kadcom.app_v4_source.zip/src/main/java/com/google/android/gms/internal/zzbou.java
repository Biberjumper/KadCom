package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class zzbou {
    private final List<zzbmj> zzbZh;
    private final List<String> zzbZi;

    static class zza {
        private StringBuilder zzcgW = null;
        private Stack<zzbos> zzcgX = new Stack();
        private int zzcgY = -1;
        private int zzcgZ;
        private boolean zzcha = true;
        private final List<zzbmj> zzchb = new ArrayList();
        private final List<String> zzchc = new ArrayList();
        private final zzc zzchd;

        public zza(zzc zzc) {
            this.zzchd = zzc;
        }

        private void zzZl() {
            if (!zzZi()) {
                this.zzcgW = new StringBuilder();
                this.zzcgW.append("(");
                Iterator it = zzpQ(this.zzcgZ).iterator();
                while (it.hasNext()) {
                    zza(this.zzcgW, (zzbos) it.next());
                    this.zzcgW.append(":(");
                }
                this.zzcha = false;
            }
        }

        private void zzZm() {
            this.zzcgZ--;
            if (zzZi()) {
                this.zzcgW.append(")");
            }
            this.zzcha = true;
        }

        private void zzZn() {
            zzbqg.zzb(this.zzcgZ == 0, "Can't finish hashing in the middle processing a child");
            if (zzZi()) {
                zzZo();
            }
            this.zzchc.add("");
        }

        private void zzZo() {
            zzbqg.zzb(zzZi(), "Can't end range without starting a range!");
            for (int i = 0; i < this.zzcgZ; i++) {
                this.zzcgW.append(")");
            }
            this.zzcgW.append(")");
            zzbmj zzpQ = zzpQ(this.zzcgY);
            this.zzchc.add(zzbqg.zzji(this.zzcgW.toString()));
            this.zzchb.add(zzpQ);
            this.zzcgW = null;
        }

        private void zza(StringBuilder stringBuilder, zzbos zzbos) {
            stringBuilder.append(zzbqg.zzjj(zzbos.asString()));
        }

        private void zzb(zzbpb<?> zzbpb) {
            zzZl();
            this.zzcgY = this.zzcgZ;
            this.zzcgW.append(zzbpb.zza(com.google.android.gms.internal.zzbpe.zza.V2));
            this.zzcha = true;
            if (this.zzchd.zze(this)) {
                zzZo();
            }
        }

        private void zzn(zzbos zzbos) {
            zzZl();
            if (this.zzcha) {
                this.zzcgW.append(",");
            }
            zza(this.zzcgW, zzbos);
            this.zzcgW.append(":(");
            if (this.zzcgZ == this.zzcgX.size()) {
                this.zzcgX.add(zzbos);
            } else {
                this.zzcgX.set(this.zzcgZ, zzbos);
            }
            this.zzcgZ++;
            this.zzcha = false;
        }

        private zzbmj zzpQ(int i) {
            zzbos[] zzbosArr = new zzbos[i];
            for (int i2 = 0; i2 < i; i2++) {
                zzbosArr[i2] = (zzbos) this.zzcgX.get(i2);
            }
            return new zzbmj(zzbosArr);
        }

        public boolean zzZi() {
            return this.zzcgW != null;
        }

        public int zzZj() {
            return this.zzcgW.length();
        }

        public zzbmj zzZk() {
            return zzpQ(this.zzcgZ);
        }
    }

    public interface zzc {
        boolean zze(zza zza);
    }

    private static class zzb implements zzc {
        private final long zzche;

        public zzb(zzbpe zzbpe) {
            this.zzche = Math.max(512, (long) Math.sqrt((double) (zzbqb.zzt(zzbpe) * 100)));
        }

        public boolean zze(zza zza) {
            return ((long) zza.zzZj()) > this.zzche && (zza.zzZk().isEmpty() || !zza.zzZk().zzXl().equals(zzbos.zzYY()));
        }
    }

    /* renamed from: com.google.android.gms.internal.zzbou$1 */
    class AnonymousClass1 extends com.google.android.gms.internal.zzbot.zza {
        final /* synthetic */ zza zzcgV;

        AnonymousClass1(zza zza) {
            this.zzcgV = zza;
        }

        public void zzb(zzbos zzbos, zzbpe zzbpe) {
            this.zzcgV.zzn(zzbos);
            zzbou.zza(zzbpe, this.zzcgV);
            this.zzcgV.zzZm();
        }
    }

    private zzbou(List<zzbmj> list, List<String> list2) {
        if (list.size() != list2.size() - 1) {
            throw new IllegalArgumentException("Number of posts need to be n-1 for n hashes in CompoundHash");
        }
        this.zzbZh = list;
        this.zzbZi = list2;
    }

    public static zzbou zza(zzbpe zzbpe, zzc zzc) {
        if (zzbpe.isEmpty()) {
            return new zzbou(Collections.emptyList(), Collections.singletonList(""));
        }
        zza zza = new zza(zzc);
        zza(zzbpe, zza);
        zza.zzZn();
        return new zzbou(zza.zzchb, zza.zzchc);
    }

    private static void zza(zzbpe zzbpe, zza zza) {
        if (zzbpe.zzZd()) {
            zza.zzb((zzbpb) zzbpe);
        } else if (zzbpe.isEmpty()) {
            throw new IllegalArgumentException("Can't calculate hash on empty node!");
        } else if (zzbpe instanceof zzbot) {
            ((zzbot) zzbpe).zza(new AnonymousClass1(zza), true);
        } else {
            String valueOf = String.valueOf(zzbpe);
            throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 33).append("Expected children node, but got: ").append(valueOf).toString());
        }
    }

    public static zzbou zzi(zzbpe zzbpe) {
        return zza(zzbpe, new zzb(zzbpe));
    }

    public List<zzbmj> zzVF() {
        return Collections.unmodifiableList(this.zzbZh);
    }

    public List<String> zzVG() {
        return Collections.unmodifiableList(this.zzbZi);
    }
}
