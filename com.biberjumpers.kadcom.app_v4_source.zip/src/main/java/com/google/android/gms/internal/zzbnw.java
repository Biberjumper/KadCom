package com.google.android.gms.internal;

public class zzbnw {
    private final zzboz zzcfB;
    private final boolean zzcfC;
    private final boolean zzcfD;

    public zzbnw(zzboz zzboz, boolean z, boolean z2) {
        this.zzcfB = zzboz;
        this.zzcfC = z;
        this.zzcfD = z2;
    }

    public boolean zzM(zzbmj zzbmj) {
        return zzbmj.isEmpty() ? zzYg() && !this.zzcfD : zzf(zzbmj.zzXi());
    }

    public zzbpe zzUY() {
        return this.zzcfB.zzUY();
    }

    public boolean zzYg() {
        return this.zzcfC;
    }

    public boolean zzYh() {
        return this.zzcfD;
    }

    public zzboz zzYi() {
        return this.zzcfB;
    }

    public boolean zzf(zzbos zzbos) {
        return (zzYg() && !this.zzcfD) || this.zzcfB.zzUY().zzk(zzbos);
    }
}
