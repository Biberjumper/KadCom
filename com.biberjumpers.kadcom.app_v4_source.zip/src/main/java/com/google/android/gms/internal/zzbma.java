package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbns.zza;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbma implements Iterable<Entry<zzbmj, zzbpe>> {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbma.class.desiredAssertionStatus());
    private static final zzbma zzcbB = new zzbma(new zzbns(null));
    private final zzbns<zzbpe> zzcbC;

    private zzbma(zzbns<zzbpe> zzbns) {
        this.zzcbC = zzbns;
    }

    public static zzbma zzWE() {
        return zzcbB;
    }

    private zzbpe zza(zzbmj zzbmj, zzbns<zzbpe> zzbns, zzbpe zzbpe) {
        if (zzbns.getValue() != null) {
            return zzbpe.zzl(zzbmj, (zzbpe) zzbns.getValue());
        }
        zzbpe zzbpe2 = null;
        Iterator it = zzbns.zzYe().iterator();
        zzbpe zzbpe3 = zzbpe;
        while (it.hasNext()) {
            zzbpe zza;
            zzbpe zzbpe4;
            Entry entry = (Entry) it.next();
            zzbns zzbns2 = (zzbns) entry.getValue();
            zzbos zzbos = (zzbos) entry.getKey();
            if (!zzbos.zzZa()) {
                zza = zza(zzbmj.zza(zzbos), zzbns2, zzbpe3);
                zzbpe4 = zzbpe2;
            } else if ($assertionsDisabled || zzbns2.getValue() != null) {
                zzbpe4 = (zzbpe) zzbns2.getValue();
                zza = zzbpe3;
            } else {
                throw new AssertionError("Priority writes must always be leaf nodes");
            }
            zzbpe2 = zzbpe4;
            zzbpe3 = zza;
        }
        return (zzbpe3.zzO(zzbmj).isEmpty() || zzbpe2 == null) ? zzbpe3 : zzbpe3.zzl(zzbmj.zza(zzbos.zzYY()), zzbpe2);
    }

    public static zzbma zzaA(Map<String, Object> map) {
        zzbns zzYd = zzbns.zzYd();
        zzbns zzbns = zzYd;
        for (Entry entry : map.entrySet()) {
            zzbns = zzbns.zza(new zzbmj((String) entry.getKey()), new zzbns(zzbpf.zzar(entry.getValue())));
        }
        return new zzbma(zzbns);
    }

    public static zzbma zzaB(Map<zzbmj, zzbpe> map) {
        zzbns zzYd = zzbns.zzYd();
        zzbns zzbns = zzYd;
        for (Entry entry : map.entrySet()) {
            zzbns = zzbns.zza((zzbmj) entry.getKey(), new zzbns((zzbpe) entry.getValue()));
        }
        return new zzbma(zzbns);
    }

    public boolean equals(Object obj) {
        return obj == this ? true : (obj == null || obj.getClass() != getClass()) ? false : ((zzbma) obj).zzaZ(true).equals(zzaZ(true));
    }

    public int hashCode() {
        return zzaZ(true).hashCode();
    }

    public boolean isEmpty() {
        return this.zzcbC.isEmpty();
    }

    public Iterator<Entry<zzbmj, zzbpe>> iterator() {
        return this.zzcbC.iterator();
    }

    public String toString() {
        String valueOf = String.valueOf(zzaZ(true).toString());
        return new StringBuilder(String.valueOf(valueOf).length() + 15).append("CompoundWrite{").append(valueOf).append("}").toString();
    }

    public zzbpe zzWF() {
        return (zzbpe) this.zzcbC.getValue();
    }

    public List<zzbpd> zzWG() {
        List<zzbpd> arrayList = new ArrayList();
        if (this.zzcbC.getValue() != null) {
            for (zzbpd zzbpd : (zzbpe) this.zzcbC.getValue()) {
                arrayList.add(new zzbpd(zzbpd.zzZz(), zzbpd.zzUY()));
            }
        } else {
            Iterator it = this.zzcbC.zzYe().iterator();
            while (it.hasNext()) {
                Entry entry = (Entry) it.next();
                zzbns zzbns = (zzbns) entry.getValue();
                if (zzbns.getValue() != null) {
                    arrayList.add(new zzbpd((zzbos) entry.getKey(), (zzbpe) zzbns.getValue()));
                }
            }
        }
        return arrayList;
    }

    public Map<zzbos, zzbma> zzWH() {
        Map<zzbos, zzbma> hashMap = new HashMap();
        Iterator it = this.zzcbC.zzYe().iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            hashMap.put((zzbos) entry.getKey(), new zzbma((zzbns) entry.getValue()));
        }
        return hashMap;
    }

    public zzbma zza(zzbos zzbos, zzbpe zzbpe) {
        return zze(new zzbmj(zzbos), zzbpe);
    }

    public Map<String, Object> zzaZ(final boolean z) {
        final Map<String, Object> hashMap = new HashMap();
        this.zzcbC.zza(new zza<zzbpe, Void>(this) {
            public Void zza(zzbmj zzbmj, zzbpe zzbpe, Void voidR) {
                hashMap.put(zzbmj.zzXg(), zzbpe.getValue(z));
                return null;
            }
        });
        return hashMap;
    }

    public zzbma zzb(final zzbmj zzbmj, zzbma zzbma) {
        return (zzbma) zzbma.zzcbC.zzb((Object) this, new zza<zzbpe, zzbma>(this) {
            public zzbma zza(zzbmj zzbmj, zzbpe zzbpe, zzbma zzbma) {
                return zzbma.zze(zzbmj.zzh(zzbmj), zzbpe);
            }
        });
    }

    public zzbpe zzb(zzbpe zzbpe) {
        return zza(zzbmj.zzXf(), this.zzcbC, zzbpe);
    }

    public zzbma zzd(zzbmj zzbmj) {
        return zzbmj.isEmpty() ? zzcbB : new zzbma(this.zzcbC.zza(zzbmj, zzbns.zzYd()));
    }

    public zzbma zze(zzbmj zzbmj, zzbpe zzbpe) {
        if (zzbmj.isEmpty()) {
            return new zzbma(new zzbns(zzbpe));
        }
        zzbmj zzG = this.zzcbC.zzG(zzbmj);
        if (zzG != null) {
            zzbmj zza = zzbmj.zza(zzG, zzbmj);
            zzbpe zzbpe2 = (zzbpe) this.zzcbC.zzK(zzG);
            zzbos zzXl = zza.zzXl();
            if (zzXl != null && zzXl.zzZa() && zzbpe2.zzO(zza.zzXk()).isEmpty()) {
                return this;
            }
            return new zzbma(this.zzcbC.zzb(zzG, zzbpe2.zzl(zza, zzbpe)));
        }
        return new zzbma(this.zzcbC.zza(zzbmj, new zzbns(zzbpe)));
    }

    public boolean zze(zzbmj zzbmj) {
        return zzf(zzbmj) != null;
    }

    public zzbpe zzf(zzbmj zzbmj) {
        zzbmj zzG = this.zzcbC.zzG(zzbmj);
        return zzG != null ? ((zzbpe) this.zzcbC.zzK(zzG)).zzO(zzbmj.zza(zzG, zzbmj)) : null;
    }

    public zzbma zzg(zzbmj zzbmj) {
        if (zzbmj.isEmpty()) {
            return this;
        }
        zzbpe zzf = zzf(zzbmj);
        return zzf != null ? new zzbma(new zzbns(zzf)) : new zzbma(this.zzcbC.zzI(zzbmj));
    }
}
