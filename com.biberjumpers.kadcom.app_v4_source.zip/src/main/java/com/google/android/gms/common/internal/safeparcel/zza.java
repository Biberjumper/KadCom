package com.google.android.gms.common.internal.safeparcel;

public abstract class zza implements SafeParcelable {
    public final int describeContents() {
        return 0;
    }
}
