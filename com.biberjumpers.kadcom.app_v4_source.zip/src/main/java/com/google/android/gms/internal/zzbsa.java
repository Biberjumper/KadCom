package com.google.android.gms.internal;

public final class zzbsa extends zzbrv {
    public zzbsa(String str) {
        super(str);
    }

    public zzbsa(String str, Throwable th) {
        super(str, th);
    }

    public zzbsa(Throwable th) {
        super(th);
    }
}
