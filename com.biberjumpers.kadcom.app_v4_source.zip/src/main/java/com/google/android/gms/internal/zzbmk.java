package com.google.android.gms.internal;

import com.google.android.gms.internal.zzblr.zza;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

public interface zzbmk {
    zzblr zza(zzbmc zzbmc, zzbln zzbln, zzblp zzblp, zza zza);

    zzbly zza(ScheduledExecutorService scheduledExecutorService);

    zzbmg zza(zzbmc zzbmc);

    zzbnn zza(zzbmc zzbmc, String str);

    zzboq zza(zzbmc zzbmc, zzboq.zza zza, List<String> list);

    zzbmo zzb(zzbmc zzbmc);

    String zzc(zzbmc zzbmc);
}
