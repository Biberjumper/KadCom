package com.google.android.gms.internal;

public class zzbpg extends zzboy {
    private final zzbmj zzchy;

    public zzbpg(zzbmj zzbmj) {
        if (zzbmj.size() == 1 && zzbmj.zzXi().zzZa()) {
            throw new IllegalArgumentException("Can't create PathIndex with '.priority' as key. Please use PriorityIndex instead!");
        }
        this.zzchy = zzbmj;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return zza((zzbpd) obj, (zzbpd) obj2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.zzchy.equals(((zzbpg) obj).zzchy);
    }

    public int hashCode() {
        return this.zzchy.hashCode();
    }

    public zzbpd zzZr() {
        return new zzbpd(zzbos.zzYX(), zzbox.zzZp().zzl(this.zzchy, zzbpe.zzchu));
    }

    public String zzZs() {
        return this.zzchy.zzXg();
    }

    public int zza(zzbpd zzbpd, zzbpd zzbpd2) {
        int compareTo = zzbpd.zzUY().zzO(this.zzchy).compareTo(zzbpd2.zzUY().zzO(this.zzchy));
        return compareTo == 0 ? zzbpd.zzZz().zzi(zzbpd2.zzZz()) : compareTo;
    }

    public zzbpd zzg(zzbos zzbos, zzbpe zzbpe) {
        return new zzbpd(zzbos, zzbox.zzZp().zzl(this.zzchy, zzbpe));
    }

    public boolean zzm(zzbpe zzbpe) {
        return !zzbpe.zzO(this.zzchy).isEmpty();
    }
}
