package com.google.android.gms.internal;

public class zzbpz implements zzbpy {
    public long zzZY() {
        return System.currentTimeMillis();
    }
}
