package com.google.android.gms.internal;

import com.google.android.gms.internal.zzboa.zza;
import com.google.firebase.database.DatabaseError;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class zzbme {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbme.class.desiredAssertionStatus());
    private AtomicBoolean zzcbT = new AtomicBoolean(false);
    private zzbmf zzcbU;
    private boolean zzcbV = false;

    public abstract zzboe zzWD();

    public void zzXa() {
        if (this.zzcbT.compareAndSet(false, true) && this.zzcbU != null) {
            this.zzcbU.zzd(this);
            this.zzcbU = null;
        }
    }

    public boolean zzXb() {
        return this.zzcbT.get();
    }

    public boolean zzXc() {
        return this.zzcbV;
    }

    public abstract zzbme zza(zzboe zzboe);

    public abstract zzbnz zza(zzbny zzbny, zzboe zzboe);

    public void zza(zzbmf zzbmf) {
        if (!$assertionsDisabled && zzXb()) {
            throw new AssertionError();
        } else if ($assertionsDisabled || this.zzcbU == null) {
            this.zzcbU = zzbmf;
        } else {
            throw new AssertionError();
        }
    }

    public abstract void zza(zzbnz zzbnz);

    public abstract void zza(DatabaseError databaseError);

    public abstract boolean zza(zza zza);

    public void zzba(boolean z) {
        this.zzcbV = z;
    }

    public abstract boolean zzc(zzbme zzbme);
}
