package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbol.zza;
import java.util.Iterator;

public class zzbok implements zzbol {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbok.class.desiredAssertionStatus());
    private final int limit;
    private final zzboy zzcfT;
    private final zzbom zzcgx;
    private final boolean zzcgy;

    public zzbok(zzbod zzbod) {
        this.zzcgx = new zzbom(zzbod);
        this.zzcfT = zzbod.zzYz();
        this.limit = zzbod.getLimit();
        this.zzcgy = !zzbod.zzYB();
    }

    private zzboz zza(zzboz zzboz, zzbos zzbos, zzbpe zzbpe, zza zza, zzboi zzboi) {
        if ($assertionsDisabled || zzboz.zzUY().getChildCount() == this.limit) {
            zzbpd zzbpd = new zzbpd(zzbos, zzbpe);
            zzbpd zzZu = this.zzcgy ? zzboz.zzZu() : zzboz.zzZv();
            boolean zza2 = this.zzcgx.zza(zzbpd);
            if (zzboz.zzUY().zzk(zzbos)) {
                zzbpe zzm = zzboz.zzUY().zzm(zzbos);
                zzbpd zza3 = zza.zza(this.zzcfT, zzZu, this.zzcgy);
                while (zza3 != null && (zza3.zzZz().equals(zzbos) || zzboz.zzUY().zzk(zza3.zzZz()))) {
                    zza3 = zza.zza(this.zzcfT, zza3, this.zzcgy);
                }
                Object obj = (!zza2 || zzbpe.isEmpty() || (zza3 == null ? 1 : this.zzcfT.zza(zza3, zzbpd, this.zzcgy)) < 0) ? null : 1;
                if (obj != null) {
                    if (zzboi != null) {
                        zzboi.zza(zzbny.zza(zzbos, zzbpe, zzm));
                    }
                    return zzboz.zzh(zzbos, zzbpe);
                }
                if (zzboi != null) {
                    zzboi.zza(zzbny.zzd(zzbos, zzm));
                }
                zzboz = zzboz.zzh(zzbos, zzbox.zzZp());
                obj = (zza3 == null || !this.zzcgx.zza(zza3)) ? null : 1;
                if (obj == null) {
                    return zzboz;
                }
                if (zzboi != null) {
                    zzboi.zza(zzbny.zzc(zza3.zzZz(), zza3.zzUY()));
                }
                return zzboz.zzh(zza3.zzZz(), zza3.zzUY());
            } else if (zzbpe.isEmpty() || !zza2 || this.zzcfT.zza(zzZu, zzbpd, this.zzcgy) < 0) {
                return zzboz;
            } else {
                if (zzboi != null) {
                    zzboi.zza(zzbny.zzd(zzZu.zzZz(), zzZu.zzUY()));
                    zzboi.zza(zzbny.zzc(zzbos, zzbpe));
                }
                return zzboz.zzh(zzbos, zzbpe).zzh(zzZu.zzZz(), zzbox.zzZp());
            }
        }
        throw new AssertionError();
    }

    public zzbol zzYP() {
        return this.zzcgx.zzYP();
    }

    public boolean zzYQ() {
        return true;
    }

    public zzboy zzYz() {
        return this.zzcfT;
    }

    public zzboz zza(zzboz zzboz, zzbos zzbos, zzbpe zzbpe, zzbmj zzbmj, zza zza, zzboi zzboi) {
        zzbpe zzZp = !this.zzcgx.zza(new zzbpd(zzbos, zzbpe)) ? zzbox.zzZp() : zzbpe;
        return zzboz.zzUY().zzm(zzbos).equals(zzZp) ? zzboz : zzboz.zzUY().getChildCount() < this.limit ? this.zzcgx.zzYP().zza(zzboz, zzbos, zzZp, zzbmj, zza, zzboi) : zza(zzboz, zzbos, zzZp, zza, zzboi);
    }

    public zzboz zza(zzboz zzboz, zzboz zzboz2, zzboi zzboi) {
        zzboz zza;
        if (zzboz2.zzUY().zzZd() || zzboz2.zzUY().isEmpty()) {
            zza = zzboz.zza(zzbox.zzZp(), this.zzcfT);
        } else {
            Object zzYR;
            Iterator it;
            int i;
            zzboz zzo = zzboz2.zzo(zzbpi.zzZB());
            if (this.zzcgy) {
                Iterator zzVl = zzboz2.zzVl();
                Object zzYS = this.zzcgx.zzYS();
                zzYR = this.zzcgx.zzYR();
                it = zzVl;
                i = -1;
            } else {
                Iterator it2 = zzboz2.iterator();
                zzbpd zzYR2 = this.zzcgx.zzYR();
                zzbpd zzYS2 = this.zzcgx.zzYS();
                zzbpd zzbpd = zzYR2;
                i = 1;
                it = it2;
            }
            int i2 = 0;
            zza = zzo;
            Object obj = null;
            while (it.hasNext()) {
                int i3;
                zzboz zzboz3;
                zzbpd zzbpd2 = (zzbpd) it.next();
                if (obj == null && this.zzcfT.compare(r5, zzbpd2) * i <= 0) {
                    obj = 1;
                }
                Object obj2 = (obj == null || i2 >= this.limit || this.zzcfT.compare(zzbpd2, zzYR) * i > 0) ? null : 1;
                if (obj2 != null) {
                    i3 = i2 + 1;
                    zzboz3 = zza;
                } else {
                    zza = zza.zzh(zzbpd2.zzZz(), zzbox.zzZp());
                    i3 = i2;
                    zzboz3 = zza;
                }
                zza = zzboz3;
                i2 = i3;
            }
        }
        return this.zzcgx.zzYP().zza(zzboz, zza, zzboi);
    }

    public zzboz zza(zzboz zzboz, zzbpe zzbpe) {
        return zzboz;
    }
}
