package com.google.android.gms.internal;

import java.io.Reader;
import java.io.StringReader;

public final class zzbrw {
    public zzbrr zza(Reader reader) throws zzbrs, zzbsa {
        try {
            zzbti zzbti = new zzbti(reader);
            zzbrr zzh = zzh(zzbti);
            if (zzh.zzaby() || zzbti.zzabQ() == zzbtj.END_DOCUMENT) {
                return zzh;
            }
            throw new zzbsa("Did not consume the entire document.");
        } catch (Throwable e) {
            throw new zzbsa(e);
        } catch (Throwable e2) {
            throw new zzbrs(e2);
        } catch (Throwable e22) {
            throw new zzbsa(e22);
        }
    }

    public zzbrr zzh(zzbti zzbti) throws zzbrs, zzbsa {
        String valueOf;
        boolean isLenient = zzbti.isLenient();
        zzbti.setLenient(true);
        try {
            zzbrr zzh = zzbss.zzh(zzbti);
            zzbti.setLenient(isLenient);
            return zzh;
        } catch (Throwable e) {
            valueOf = String.valueOf(zzbti);
            throw new zzbrv(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed parsing JSON source: ").append(valueOf).append(" to Json").toString(), e);
        } catch (Throwable e2) {
            valueOf = String.valueOf(zzbti);
            throw new zzbrv(new StringBuilder(String.valueOf(valueOf).length() + 36).append("Failed parsing JSON source: ").append(valueOf).append(" to Json").toString(), e2);
        } catch (Throwable th) {
            zzbti.setLenient(isLenient);
        }
    }

    public zzbrr zzjU(String str) throws zzbsa {
        return zza(new StringReader(str));
    }
}
