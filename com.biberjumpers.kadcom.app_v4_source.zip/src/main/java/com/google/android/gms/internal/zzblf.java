package com.google.android.gms.internal;

import java.util.Comparator;

public interface zzblf<K, V> {

    public enum zza {
        RED,
        BLACK
    }

    public static abstract class zzb<K, V> {
        public abstract void zzk(K k, V v);
    }

    K getKey();

    V getValue();

    boolean isEmpty();

    boolean zzVq();

    zzblf<K, V> zzVs();

    zzblf<K, V> zzVt();

    zzblf<K, V> zzVu();

    zzblf<K, V> zzVv();

    int zzVw();

    zzblf<K, V> zza(K k, V v, zza zza, zzblf<K, V> zzblf, zzblf<K, V> zzblf2);

    zzblf<K, V> zza(K k, V v, Comparator<K> comparator);

    zzblf<K, V> zza(K k, Comparator<K> comparator);

    void zza(zzb<K, V> zzb);
}
