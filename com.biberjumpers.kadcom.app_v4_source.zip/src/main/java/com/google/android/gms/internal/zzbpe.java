package com.google.android.gms.internal;

import java.util.Iterator;

public interface zzbpe extends Comparable<zzbpe>, Iterable<zzbpd> {
    public static final zzbot zzchu = new zzbot() {
        public /* synthetic */ int compareTo(Object obj) {
            return zzh((zzbpe) obj);
        }

        public boolean equals(Object obj) {
            return obj == this;
        }

        public boolean isEmpty() {
            return false;
        }

        public String toString() {
            return "<Max Node>";
        }

        public zzbpe zzZe() {
            return this;
        }

        public int zzh(zzbpe zzbpe) {
            return zzbpe == this ? 0 : 1;
        }

        public boolean zzk(zzbos zzbos) {
            return false;
        }

        public zzbpe zzm(zzbos zzbos) {
            return zzbos.zzZa() ? zzZe() : zzbox.zzZp();
        }
    };

    public enum zza {
        V1,
        V2
    }

    int getChildCount();

    Object getValue();

    Object getValue(boolean z);

    boolean isEmpty();

    zzbpe zzO(zzbmj zzbmj);

    Iterator<zzbpd> zzVl();

    String zzZc();

    boolean zzZd();

    zzbpe zzZe();

    String zza(zza zza);

    zzbpe zze(zzbos zzbos, zzbpe zzbpe);

    zzbpe zzg(zzbpe zzbpe);

    boolean zzk(zzbos zzbos);

    zzbos zzl(zzbos zzbos);

    zzbpe zzl(zzbmj zzbmj, zzbpe zzbpe);

    zzbpe zzm(zzbos zzbos);
}
