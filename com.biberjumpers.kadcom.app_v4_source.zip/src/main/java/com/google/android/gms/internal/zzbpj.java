package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class zzbpj {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbpj.class.desiredAssertionStatus());
    private final zzbmj zzchA;
    private final zzbmj zzchB;
    private final zzbpe zzchC;

    public zzbpj(zzblt zzblt) {
        zzbmj zzbmj = null;
        List zzWm = zzblt.zzWm();
        this.zzchA = zzWm != null ? new zzbmj(zzWm) : null;
        List zzWn = zzblt.zzWn();
        if (zzWn != null) {
            zzbmj = new zzbmj(zzWn);
        }
        this.zzchB = zzbmj;
        this.zzchC = zzbpf.zzar(zzblt.zzWo());
    }

    private zzbpe zzb(zzbmj zzbmj, zzbpe zzbpe, zzbpe zzbpe2) {
        Object obj = 1;
        int zzj = this.zzchA == null ? 1 : zzbmj.zzj(this.zzchA);
        int zzj2 = this.zzchB == null ? -1 : zzbmj.zzj(this.zzchB);
        Object obj2 = (this.zzchA == null || !zzbmj.zzi(this.zzchA)) ? null : 1;
        if (this.zzchB == null || !zzbmj.zzi(this.zzchB)) {
            obj = null;
        }
        if (zzj > 0 && zzj2 < 0 && r1 == null) {
            return zzbpe2;
        }
        if (zzj > 0 && r1 != null && zzbpe2.zzZd()) {
            return zzbpe2;
        }
        if (zzj <= 0 || zzj2 != 0) {
            if (obj2 != null || r1 != null) {
                Collection hashSet = new HashSet();
                for (zzbpd zzZz : zzbpe) {
                    hashSet.add(zzZz.zzZz());
                }
                for (zzbpd zzZz2 : zzbpe2) {
                    hashSet.add(zzZz2.zzZz());
                }
                List<zzbos> arrayList = new ArrayList(hashSet.size() + 1);
                arrayList.addAll(hashSet);
                if (!(zzbpe2.zzZe().isEmpty() && zzbpe.zzZe().isEmpty())) {
                    arrayList.add(zzbos.zzYY());
                }
                zzbpe zzbpe3 = zzbpe;
                for (zzbos zzbos : arrayList) {
                    zzbpe zzm = zzbpe.zzm(zzbos);
                    zzbpe zzb = zzb(zzbmj.zza(zzbos), zzbpe.zzm(zzbos), zzbpe2.zzm(zzbos));
                    zzbpe3 = zzb != zzm ? zzbpe3.zze(zzbos, zzb) : zzbpe3;
                }
                return zzbpe3;
            } else if ($assertionsDisabled || zzj2 > 0 || zzj <= 0) {
                return zzbpe;
            } else {
                throw new AssertionError();
            }
        } else if (!$assertionsDisabled && r1 == null) {
            throw new AssertionError();
        } else if ($assertionsDisabled || !zzbpe2.zzZd()) {
            return zzbpe.zzZd() ? zzbox.zzZp() : zzbpe;
        } else {
            throw new AssertionError();
        }
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzchA);
        String valueOf2 = String.valueOf(this.zzchB);
        String valueOf3 = String.valueOf(this.zzchC);
        return new StringBuilder(((String.valueOf(valueOf).length() + 55) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("RangeMerge{optExclusiveStart=").append(valueOf).append(", optInclusiveEnd=").append(valueOf2).append(", snap=").append(valueOf3).append("}").toString();
    }

    public zzbpe zzr(zzbpe zzbpe) {
        return zzb(zzbmj.zzXf(), zzbpe, this.zzchC);
    }
}
