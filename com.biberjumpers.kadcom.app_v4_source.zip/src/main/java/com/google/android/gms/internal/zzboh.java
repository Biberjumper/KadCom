package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzboh {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzboh.class.desiredAssertionStatus());
    private static com.google.android.gms.internal.zzbol.zza zzcgs = new com.google.android.gms.internal.zzbol.zza() {
        public zzbpd zza(zzboy zzboy, zzbpd zzbpd, boolean z) {
            return null;
        }

        public zzbpe zzh(zzbos zzbos) {
            return null;
        }
    };
    private final zzbol zzcgr;

    public static class zza {
        public final zzbog zzcgk;
        public final List<zzbny> zzcgo;

        public zza(zzbog zzbog, List<zzbny> list) {
            this.zzcgk = zzbog;
            this.zzcgo = list;
        }
    }

    private static class zzb implements com.google.android.gms.internal.zzbol.zza {
        private final zzbog zzcgk;
        private final zzbnb zzcgu;
        private final zzbpe zzcgv;

        public zzb(zzbnb zzbnb, zzbog zzbog, zzbpe zzbpe) {
            this.zzcgu = zzbnb;
            this.zzcgk = zzbog;
            this.zzcgv = zzbpe;
        }

        public zzbpd zza(zzboy zzboy, zzbpd zzbpd, boolean z) {
            return this.zzcgu.zza(this.zzcgv != null ? this.zzcgv : this.zzcgk.zzYN(), zzbpd, z, zzboy);
        }

        public zzbpe zzh(zzbos zzbos) {
            zzbnw zzYK = this.zzcgk.zzYK();
            if (zzYK.zzf(zzbos)) {
                return zzYK.zzUY().zzm(zzbos);
            }
            return this.zzcgu.zza(zzbos, this.zzcgv != null ? new zzbnw(zzboz.zza(this.zzcgv, zzbpa.zzZw()), true, false) : this.zzcgk.zzYM());
        }
    }

    public zzboh(zzbol zzbol) {
        this.zzcgr = zzbol;
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbma zzbma, zzbnb zzbnb, zzbpe zzbpe, zzboi zzboi) {
        if ($assertionsDisabled || zzbma.zzWF() == null) {
            Entry entry;
            zzbmj zzh;
            Iterator it = zzbma.iterator();
            zzbog zzbog2 = zzbog;
            while (it.hasNext()) {
                entry = (Entry) it.next();
                zzh = zzbmj.zzh((zzbmj) entry.getKey());
                if (zza(zzbog, zzh.zzXi())) {
                    zzbog2 = zza(zzbog2, zzh, (zzbpe) entry.getValue(), zzbnb, zzbpe, zzboi);
                }
            }
            it = zzbma.iterator();
            while (it.hasNext()) {
                entry = (Entry) it.next();
                zzh = zzbmj.zzh((zzbmj) entry.getKey());
                if (!zza(zzbog, zzh.zzXi())) {
                    zzbog2 = zza(zzbog2, zzh, (zzbpe) entry.getValue(), zzbnb, zzbpe, zzboi);
                }
            }
            return zzbog2;
        }
        throw new AssertionError("Can't have a merge that is an overwrite");
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbma zzbma, zzbnb zzbnb, zzbpe zzbpe, boolean z, zzboi zzboi) {
        if (zzbog.zzYM().zzUY().isEmpty() && !zzbog.zzYM().zzYg()) {
            return zzbog;
        }
        if ($assertionsDisabled || zzbma.zzWF() == null) {
            zzbos zzbos;
            if (!zzbmj.isEmpty()) {
                zzbma = zzbma.zzWE().zzb(zzbmj, zzbma);
            }
            zzbpe zzUY = zzbog.zzYM().zzUY();
            Map zzWH = zzbma.zzWH();
            zzbog zzbog2 = zzbog;
            for (Entry entry : zzWH.entrySet()) {
                zzbos = (zzbos) entry.getKey();
                if (zzUY.zzk(zzbos)) {
                    zzbog2 = zza(zzbog2, new zzbmj(zzbos), ((zzbma) entry.getValue()).zzb(zzUY.zzm(zzbos)), zzbnb, zzbpe, z, zzboi);
                }
            }
            for (Entry entry2 : zzWH.entrySet()) {
                zzbos = (zzbos) entry2.getKey();
                Object obj = (zzbog.zzYM().zzf(zzbos) || ((zzbma) entry2.getValue()).zzWF() != null) ? null : 1;
                if (!zzUY.zzk(zzbos) && obj == null) {
                    zzbog2 = zza(zzbog2, new zzbmj(zzbos), ((zzbma) entry2.getValue()).zzb(zzUY.zzm(zzbos)), zzbnb, zzbpe, z, zzboi);
                }
            }
            return zzbog2;
        }
        throw new AssertionError("Can't have a merge that is an overwrite");
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbnb zzbnb, com.google.android.gms.internal.zzbol.zza zza, zzboi zzboi) {
        zzbnw zzYK = zzbog.zzYK();
        if (zzbnb.zzv(zzbmj) != null) {
            return zzbog;
        }
        zzboz zza2;
        zzbpe zza3;
        if (!zzbmj.isEmpty()) {
            zzbos zzXi = zzbmj.zzXi();
            if (!zzXi.zzZa()) {
                zzbpe zzl;
                zzbmj zzXj = zzbmj.zzXj();
                if (zzYK.zzf(zzXi)) {
                    zza3 = zzbnb.zza(zzbmj, zzYK.zzUY(), zzbog.zzYM().zzUY());
                    zzl = zza3 != null ? zzYK.zzUY().zzm(zzXi).zzl(zzXj, zza3) : zzYK.zzUY().zzm(zzXi);
                } else {
                    zzl = zzbnb.zza(zzXi, zzbog.zzYM());
                }
                zza2 = zzl != null ? this.zzcgr.zza(zzYK.zzYi(), zzXi, zzl, zzXj, zza, zzboi) : zzYK.zzYi();
            } else if ($assertionsDisabled || zzbmj.size() == 1) {
                zza3 = zzbnb.zza(zzbmj, zzYK.zzUY(), zzbog.zzYM().zzUY());
                zza2 = zza3 != null ? this.zzcgr.zza(zzYK.zzYi(), zza3) : zzYK.zzYi();
            } else {
                throw new AssertionError("Can't have a priority with additional path components");
            }
        } else if ($assertionsDisabled || zzbog.zzYM().zzYg()) {
            if (zzbog.zzYM().zzYh()) {
                zza3 = zzbog.zzYN();
                if (!(zza3 instanceof zzbot)) {
                    zza3 = zzbox.zzZp();
                }
                zza3 = zzbnb.zzd(zza3);
            } else {
                zza3 = zzbnb.zzc(zzbog.zzYN());
            }
            zza2 = this.zzcgr.zza(zzbog.zzYK().zzYi(), zzboz.zza(zza3, this.zzcgr.zzYz()), zzboi);
        } else {
            throw new AssertionError("If change path is empty, we must have complete server data");
        }
        boolean z = zzYK.zzYg() || zzbmj.isEmpty();
        return zzbog.zza(zza2, z, this.zzcgr.zzYQ());
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbns<Boolean> zzbns, zzbnb zzbnb, zzbpe zzbpe, zzboi zzboi) {
        if (zzbnb.zzv(zzbmj) != null) {
            return zzbog;
        }
        boolean zzYh = zzbog.zzYM().zzYh();
        zzbnw zzYM = zzbog.zzYM();
        zzbma zzWE;
        if (zzbns.getValue() == null) {
            zzWE = zzbma.zzWE();
            Iterator it = zzbns.iterator();
            while (it.hasNext()) {
                zzbmj zzbmj2 = (zzbmj) ((Entry) it.next()).getKey();
                zzbmj zzh = zzbmj.zzh(zzbmj2);
                if (zzYM.zzM(zzh)) {
                    zzWE = zzWE.zze(zzbmj2, zzYM.zzUY().zzO(zzh));
                }
            }
            return zza(zzbog, zzbmj, zzWE, zzbnb, zzbpe, zzYh, zzboi);
        } else if ((zzbmj.isEmpty() && zzYM.zzYg()) || zzYM.zzM(zzbmj)) {
            return zza(zzbog, zzbmj, zzYM.zzUY().zzO(zzbmj), zzbnb, zzbpe, zzYh, zzboi);
        } else if (!zzbmj.isEmpty()) {
            return zzbog;
        } else {
            zzWE = zzbma.zzWE();
            for (zzbpd zzbpd : zzYM.zzUY()) {
                zzWE = zzWE.zza(zzbpd.zzZz(), zzbpd.zzUY());
            }
            return zza(zzbog, zzbmj, zzWE, zzbnb, zzbpe, zzYh, zzboi);
        }
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbpe zzbpe, zzbnb zzbnb, zzbpe zzbpe2, zzboi zzboi) {
        zzbnw zzYK = zzbog.zzYK();
        com.google.android.gms.internal.zzbol.zza zzb = new zzb(zzbnb, zzbog, zzbpe2);
        if (zzbmj.isEmpty()) {
            return zzbog.zza(this.zzcgr.zza(zzbog.zzYK().zzYi(), zzboz.zza(zzbpe, this.zzcgr.zzYz()), zzboi), true, this.zzcgr.zzYQ());
        }
        zzbos zzXi = zzbmj.zzXi();
        if (zzXi.zzZa()) {
            return zzbog.zza(this.zzcgr.zza(zzbog.zzYK().zzYi(), zzbpe), zzYK.zzYg(), zzYK.zzYh());
        }
        zzbpe zzbpe3;
        zzbmj zzXj = zzbmj.zzXj();
        zzbpe zzm = zzYK.zzUY().zzm(zzXi);
        if (zzXj.isEmpty()) {
            zzbpe3 = zzbpe;
        } else {
            zzbpe3 = zzb.zzh(zzXi);
            if (zzbpe3 == null) {
                zzbpe3 = zzbox.zzZp();
            } else if (!(zzXj.zzXl().zzZa() && zzbpe3.zzO(zzXj.zzXk()).isEmpty())) {
                zzbpe3 = zzbpe3.zzl(zzXj, zzbpe);
            }
        }
        return !zzm.equals(zzbpe3) ? zzbog.zza(this.zzcgr.zza(zzYK.zzYi(), zzXi, zzbpe3, zzXj, zzb, zzboi), zzYK.zzYg(), this.zzcgr.zzYQ()) : zzbog;
    }

    private zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbpe zzbpe, zzbnb zzbnb, zzbpe zzbpe2, boolean z, zzboi zzboi) {
        zzboz zza;
        zzbnw zzYM = zzbog.zzYM();
        zzbol zzYP = z ? this.zzcgr : this.zzcgr.zzYP();
        if (zzbmj.isEmpty()) {
            zza = zzYP.zza(zzYM.zzYi(), zzboz.zza(zzbpe, zzYP.zzYz()), null);
        } else if (!zzYP.zzYQ() || zzYM.zzYh()) {
            zzbos zzXi = zzbmj.zzXi();
            if (!zzYM.zzM(zzbmj) && zzbmj.size() > 1) {
                return zzbog;
            }
            zzbmj zzXj = zzbmj.zzXj();
            zzbpe zzl = zzYM.zzUY().zzm(zzXi).zzl(zzXj, zzbpe);
            zza = zzXi.zzZa() ? zzYP.zza(zzYM.zzYi(), zzl) : zzYP.zza(zzYM.zzYi(), zzXi, zzl, zzXj, zzcgs, null);
        } else if ($assertionsDisabled || !zzbmj.isEmpty()) {
            zzbos zzXi2 = zzbmj.zzXi();
            zza = zzYP.zza(zzYM.zzYi(), zzYM.zzYi().zzh(zzXi2, zzYM.zzUY().zzm(zzXi2).zzl(zzbmj.zzXj(), zzbpe)), null);
        } else {
            throw new AssertionError("An empty path should have been caught in the other branch");
        }
        boolean z2 = zzYM.zzYg() || zzbmj.isEmpty();
        zzbog zzb = zzbog.zzb(zza, z2, zzYP.zzYQ());
        return zza(zzb, zzbmj, zzbnb, new zzb(zzbnb, zzb, zzbpe2), zzboi);
    }

    private void zza(zzbog zzbog, zzbog zzbog2, List<zzbny> list) {
        zzbnw zzYK = zzbog2.zzYK();
        if (zzYK.zzYg()) {
            Object obj = (zzYK.zzUY().zzZd() || zzYK.zzUY().isEmpty()) ? 1 : null;
            if (!list.isEmpty() || !zzbog.zzYK().zzYg() || ((obj != null && !zzYK.zzUY().equals(zzbog.zzYL())) || !zzYK.zzUY().zzZe().equals(zzbog.zzYL().zzZe()))) {
                list.add(zzbny.zza(zzYK.zzYi()));
            }
        }
    }

    private static boolean zza(zzbog zzbog, zzbos zzbos) {
        return zzbog.zzYK().zzf(zzbos);
    }

    private zzbog zzb(zzbog zzbog, zzbmj zzbmj, zzbnb zzbnb, zzbpe zzbpe, zzboi zzboi) {
        zzbnw zzYM = zzbog.zzYM();
        zzboz zzYi = zzYM.zzYi();
        boolean z = zzYM.zzYg() || zzbmj.isEmpty();
        return zza(zzbog.zzb(zzYi, z, zzYM.zzYh()), zzbmj, zzbnb, zzcgs, zzboi);
    }

    public zzbog zza(zzbog zzbog, zzbmj zzbmj, zzbnb zzbnb, zzbpe zzbpe, zzboi zzboi) {
        if (zzbnb.zzv(zzbmj) != null) {
            return zzbog;
        }
        com.google.android.gms.internal.zzbol.zza zzb = new zzb(zzbnb, zzbog, zzbpe);
        zzboz zzYi = zzbog.zzYK().zzYi();
        if (zzbmj.isEmpty() || zzbmj.zzXi().zzZa()) {
            zzYi = this.zzcgr.zza(zzYi, zzboz.zza(zzbog.zzYM().zzYg() ? zzbnb.zzc(zzbog.zzYN()) : zzbnb.zzd(zzbog.zzYM().zzUY()), this.zzcgr.zzYz()), zzboi);
        } else {
            zzbos zzXi = zzbmj.zzXi();
            zzbpe zza = zzbnb.zza(zzXi, zzbog.zzYM());
            if (zza == null && zzbog.zzYM().zzf(zzXi)) {
                zza = zzYi.zzUY().zzm(zzXi);
            }
            if (zza != null) {
                zzYi = this.zzcgr.zza(zzYi, zzXi, zza, zzbmj.zzXj(), zzb, zzboi);
            } else if (zza == null && zzbog.zzYK().zzUY().zzk(zzXi)) {
                zzYi = this.zzcgr.zza(zzYi, zzXi, zzbox.zzZp(), zzbmj.zzXj(), zzb, zzboi);
            }
            if (zzYi.zzUY().isEmpty() && zzbog.zzYM().zzYg()) {
                zzbpe zzc = zzbnb.zzc(zzbog.zzYN());
                if (zzc.zzZd()) {
                    zzYi = this.zzcgr.zza(zzYi, zzboz.zza(zzc, this.zzcgr.zzYz()), zzboi);
                }
            }
        }
        boolean z = zzbog.zzYM().zzYg() || zzbnb.zzv(zzbmj.zzXf()) != null;
        return zzbog.zza(zzYi, z, this.zzcgr.zzYQ());
    }

    public zza zza(zzbog zzbog, zzbng zzbng, zzbnb zzbnb, zzbpe zzbpe) {
        zzbog zza;
        zzboi zzboi = new zzboi();
        boolean z;
        switch (zzbng.zzXP()) {
            case Overwrite:
                zzbni zzbni = (zzbni) zzbng;
                if (zzbni.zzXO().zzXQ()) {
                    zza = zza(zzbog, zzbni.zzVc(), zzbni.zzXU(), zzbnb, zzbpe, zzboi);
                    break;
                } else if ($assertionsDisabled || zzbni.zzXO().zzXR()) {
                    z = zzbni.zzXO().zzXS() || (zzbog.zzYM().zzYh() && !zzbni.zzVc().isEmpty());
                    zza = zza(zzbog, zzbni.zzVc(), zzbni.zzXU(), zzbnb, zzbpe, z, zzboi);
                    break;
                } else {
                    throw new AssertionError();
                }
                break;
            case Merge:
                zzbnf zzbnf = (zzbnf) zzbng;
                if (zzbnf.zzXO().zzXQ()) {
                    zza = zza(zzbog, zzbnf.zzVc(), zzbnf.zzXN(), zzbnb, zzbpe, zzboi);
                    break;
                } else if ($assertionsDisabled || zzbnf.zzXO().zzXR()) {
                    z = zzbnf.zzXO().zzXS() || zzbog.zzYM().zzYh();
                    zza = zza(zzbog, zzbnf.zzVc(), zzbnf.zzXN(), zzbnb, zzbpe, z, zzboi);
                    break;
                } else {
                    throw new AssertionError();
                }
                break;
            case AckUserWrite:
                zzbnd zzbnd = (zzbnd) zzbng;
                if (!zzbnd.zzXM()) {
                    zza = zza(zzbog, zzbnd.zzVc(), zzbnd.zzXL(), zzbnb, zzbpe, zzboi);
                    break;
                }
                zza = zza(zzbog, zzbnd.zzVc(), zzbnb, zzbpe, zzboi);
                break;
            case ListenComplete:
                zza = zzb(zzbog, zzbng.zzVc(), zzbnb, zzbpe, zzboi);
                break;
            default:
                String valueOf = String.valueOf(zzbng.zzXP());
                throw new AssertionError(new StringBuilder(String.valueOf(valueOf).length() + 19).append("Unknown operation: ").append(valueOf).toString());
        }
        List arrayList = new ArrayList(zzboi.zzYO());
        zza(zzbog, zza, arrayList);
        return new zza(zza, arrayList);
    }
}
