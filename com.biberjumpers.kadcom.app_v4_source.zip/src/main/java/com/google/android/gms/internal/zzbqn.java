package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.firebase.FirebaseException;

public class zzbqn extends FirebaseException {
    public zzbqn(@NonNull String str) {
        super(str);
    }
}
