package com.google.android.gms.internal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class zzaao {
    private static final ExecutorService zzaAN = Executors.newFixedThreadPool(2, new zzacu("GAC_Executor"));

    public static ExecutorService zzvR() {
        return zzaAN;
    }
}
