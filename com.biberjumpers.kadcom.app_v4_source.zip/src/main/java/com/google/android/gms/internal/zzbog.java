package com.google.android.gms.internal;

public class zzbog {
    private final zzbnw zzcgp;
    private final zzbnw zzcgq;

    public zzbog(zzbnw zzbnw, zzbnw zzbnw2) {
        this.zzcgp = zzbnw;
        this.zzcgq = zzbnw2;
    }

    public zzbnw zzYK() {
        return this.zzcgp;
    }

    public zzbpe zzYL() {
        return this.zzcgp.zzYg() ? this.zzcgp.zzUY() : null;
    }

    public zzbnw zzYM() {
        return this.zzcgq;
    }

    public zzbpe zzYN() {
        return this.zzcgq.zzYg() ? this.zzcgq.zzUY() : null;
    }

    public zzbog zza(zzboz zzboz, boolean z, boolean z2) {
        return new zzbog(new zzbnw(zzboz, z, z2), this.zzcgq);
    }

    public zzbog zzb(zzboz zzboz, boolean z, boolean z2) {
        return new zzbog(this.zzcgp, new zzbnw(zzboz, z, z2));
    }
}
