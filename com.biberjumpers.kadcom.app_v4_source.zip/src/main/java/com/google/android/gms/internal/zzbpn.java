package com.google.android.gms.internal;

public interface zzbpn {
    void zza(Thread thread, String str);
}
