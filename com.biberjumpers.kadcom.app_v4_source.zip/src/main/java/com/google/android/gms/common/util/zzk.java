package com.google.android.gms.common.util;

public final class zzk {
    public static boolean zzdi(int i) {
        return i >= 3200000;
    }
}
