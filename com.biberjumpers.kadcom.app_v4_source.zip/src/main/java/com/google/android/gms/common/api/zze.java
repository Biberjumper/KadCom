package com.google.android.gms.common.api;

import android.support.annotation.NonNull;

public class zze<T extends Result> {
    private T zzayd;

    public void zzb(@NonNull T t) {
        this.zzayd = t;
    }
}
