package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public final class zzbsu<E> extends zzbsd<Object> {
    public static final zzbse zzcnX = new zzbse() {
        public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
            Type zzacc = zzbth.zzacc();
            if (!(zzacc instanceof GenericArrayType) && (!(zzacc instanceof Class) || !((Class) zzacc).isArray())) {
                return null;
            }
            zzacc = zzbsk.zzh(zzacc);
            return new zzbsu(zzbrl, zzbrl.zza(zzbth.zzl(zzacc)), zzbsk.zzf(zzacc));
        }
    };
    private final Class<E> zzcnY;
    private final zzbsd<E> zzcnZ;

    public zzbsu(zzbrl zzbrl, zzbsd<E> zzbsd, Class<E> cls) {
        this.zzcnZ = new zzbtf(zzbrl, zzbsd, cls);
        this.zzcnY = cls;
    }

    public void zza(zzbtk zzbtk, Object obj) throws IOException {
        if (obj == null) {
            zzbtk.zzaca();
            return;
        }
        zzbtk.zzabW();
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            this.zzcnZ.zza(zzbtk, Array.get(obj, i));
        }
        zzbtk.zzabX();
    }

    public Object zzb(zzbti zzbti) throws IOException {
        if (zzbti.zzabQ() == zzbtj.NULL) {
            zzbti.nextNull();
            return null;
        }
        List arrayList = new ArrayList();
        zzbti.beginArray();
        while (zzbti.hasNext()) {
            arrayList.add(this.zzcnZ.zzb(zzbti));
        }
        zzbti.endArray();
        Object newInstance = Array.newInstance(this.zzcnY, arrayList.size());
        for (int i = 0; i < arrayList.size(); i++) {
            Array.set(newInstance, i, arrayList.get(i));
        }
        return newInstance;
    }
}
