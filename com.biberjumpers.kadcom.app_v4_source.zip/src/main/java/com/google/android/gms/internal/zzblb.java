package com.google.android.gms.internal;

import java.util.AbstractMap.SimpleEntry;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Stack;

public class zzblb<K, V> implements Iterator<Entry<K, V>> {
    private final Stack<zzblh<K, V>> zzbYM = new Stack();
    private final boolean zzbYN;

    zzblb(zzblf<K, V> zzblf, K k, Comparator<K> comparator, boolean z) {
        this.zzbYN = z;
        zzblf zzblf2 = zzblf;
        while (!zzblf2.isEmpty()) {
            int compare = k != null ? z ? comparator.compare(k, zzblf2.getKey()) : comparator.compare(zzblf2.getKey(), k) : 1;
            if (compare < 0) {
                zzblf2 = z ? zzblf2.zzVs() : zzblf2.zzVt();
            } else if (compare == 0) {
                this.zzbYM.push((zzblh) zzblf2);
                return;
            } else {
                this.zzbYM.push((zzblh) zzblf2);
                zzblf2 = z ? zzblf2.zzVt() : zzblf2.zzVs();
            }
        }
    }

    public boolean hasNext() {
        return this.zzbYM.size() > 0;
    }

    public Entry<K, V> next() {
        try {
            zzblh zzblh = (zzblh) this.zzbYM.pop();
            Entry simpleEntry = new SimpleEntry(zzblh.getKey(), zzblh.getValue());
            zzblf zzVs;
            if (this.zzbYN) {
                for (zzVs = zzblh.zzVs(); !zzVs.isEmpty(); zzVs = zzVs.zzVt()) {
                    this.zzbYM.push((zzblh) zzVs);
                }
            } else {
                for (zzVs = zzblh.zzVt(); !zzVs.isEmpty(); zzVs = zzVs.zzVs()) {
                    this.zzbYM.push((zzblh) zzVs);
                }
            }
            return simpleEntry;
        } catch (EmptyStackException e) {
            throw new NoSuchElementException();
        }
    }

    public void remove() {
        throw new UnsupportedOperationException("remove called on immutable collection");
    }
}
