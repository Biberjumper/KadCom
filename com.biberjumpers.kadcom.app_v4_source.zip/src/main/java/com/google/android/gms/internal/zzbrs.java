package com.google.android.gms.internal;

public final class zzbrs extends zzbrv {
    public zzbrs(String str) {
        super(str);
    }

    public zzbrs(Throwable th) {
        super(th);
    }
}
