package com.google.android.gms.internal;

public class zzbmm {
    public String zzaFs;
    public String zzbZA;
    public boolean zzbZB;
    public String zzcdm;

    public String toString() {
        String str = this.zzbZB ? "s" : "";
        String str2 = this.zzbZA;
        return new StringBuilder((String.valueOf(str).length() + 7) + String.valueOf(str2).length()).append("http").append(str).append("://").append(str2).toString();
    }
}
