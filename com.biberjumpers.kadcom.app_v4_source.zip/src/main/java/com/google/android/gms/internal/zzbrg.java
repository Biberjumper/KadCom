package com.google.android.gms.internal;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

final class zzbrg implements zzbrq<Date>, zzbrz<Date> {
    private final DateFormat zzcmh;
    private final DateFormat zzcmi;
    private final DateFormat zzcmj;

    zzbrg() {
        this(DateFormat.getDateTimeInstance(2, 2, Locale.US), DateFormat.getDateTimeInstance(2, 2));
    }

    public zzbrg(int i, int i2) {
        this(DateFormat.getDateTimeInstance(i, i2, Locale.US), DateFormat.getDateTimeInstance(i, i2));
    }

    zzbrg(String str) {
        this(new SimpleDateFormat(str, Locale.US), new SimpleDateFormat(str));
    }

    zzbrg(DateFormat dateFormat, DateFormat dateFormat2) {
        this.zzcmh = dateFormat;
        this.zzcmi = dateFormat2;
        this.zzcmj = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        this.zzcmj.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    private Date zza(zzbrr zzbrr) {
        Date parse;
        synchronized (this.zzcmi) {
            try {
                parse = this.zzcmi.parse(zzbrr.zzabu());
            } catch (ParseException e) {
                try {
                    parse = this.zzcmh.parse(zzbrr.zzabu());
                } catch (ParseException e2) {
                    try {
                        parse = this.zzcmj.parse(zzbrr.zzabu());
                    } catch (Throwable e3) {
                        throw new zzbsa(zzbrr.zzabu(), e3);
                    }
                }
            }
        }
        return parse;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(zzbrg.class.getSimpleName());
        stringBuilder.append('(').append(this.zzcmi.getClass().getSimpleName()).append(')');
        return stringBuilder.toString();
    }

    public zzbrr zza(Date date, Type type, zzbry zzbry) {
        zzbrr zzbrx;
        synchronized (this.zzcmi) {
            zzbrx = new zzbrx(this.zzcmh.format(date));
        }
        return zzbrx;
    }

    public Date zza(zzbrr zzbrr, Type type, zzbrp zzbrp) throws zzbrv {
        if (zzbrr instanceof zzbrx) {
            Date zza = zza(zzbrr);
            if (type == Date.class) {
                return zza;
            }
            if (type == Timestamp.class) {
                return new Timestamp(zza.getTime());
            }
            if (type == java.sql.Date.class) {
                return new java.sql.Date(zza.getTime());
            }
            String valueOf = String.valueOf(getClass());
            String valueOf2 = String.valueOf(type);
            throw new IllegalArgumentException(new StringBuilder((String.valueOf(valueOf).length() + 23) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot deserialize to ").append(valueOf2).toString());
        }
        throw new zzbrv("The date should be a string value");
    }

    public /* synthetic */ Object zzb(zzbrr zzbrr, Type type, zzbrp zzbrp) throws zzbrv {
        return zza(zzbrr, type, zzbrp);
    }
}
