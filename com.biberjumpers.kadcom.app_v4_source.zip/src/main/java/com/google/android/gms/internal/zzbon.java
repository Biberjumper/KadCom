package com.google.android.gms.internal;

import android.util.Log;
import com.google.android.gms.internal.zzboq.zza;
import java.util.List;

public class zzbon extends zzboo {
    public zzbon(zza zza, List<String> list) {
        super(zza, list);
    }

    protected String zza(zza zza, String str, String str2, long j) {
        return str2;
    }

    protected void zzaq(String str, String str2) {
        Log.e(str, str2);
    }

    protected void zzar(String str, String str2) {
        Log.w(str, str2);
    }

    protected void zzas(String str, String str2) {
        Log.i(str, str2);
    }

    protected void zzat(String str, String str2) {
        Log.d(str, str2);
    }
}
