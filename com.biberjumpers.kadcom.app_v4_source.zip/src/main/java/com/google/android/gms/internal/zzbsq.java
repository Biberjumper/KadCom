package com.google.android.gms.internal;

public interface zzbsq<T> {
    T zzabJ();
}
