package com.google.android.gms.internal;

public interface zzbmg {
    void restart();

    void shutdown();

    void zzq(Runnable runnable);
}
