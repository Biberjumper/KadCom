package com.google.android.gms.internal;

import com.google.android.gms.internal.zzblf.zzb;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbli<K, V> extends zzbla<K, V> {
    private Comparator<K> zzbYG;
    private zzblf<K, V> zzbYX;

    private static class zza<A, B, C> {
        private final Map<B, C> values;
        private final List<A> zzbYY;
        private final com.google.android.gms.internal.zzbla.zza.zza<A, B> zzbYZ;
        private zzblh<A, C> zzbZa;
        private zzblh<A, C> zzbZb;

        static class zza implements Iterable<zzb> {
            private final int length;
            private long value;

            public zza(int i) {
                int i2 = i + 1;
                this.length = (int) Math.floor(Math.log((double) i2) / Math.log(2.0d));
                this.value = ((long) i2) & (((long) Math.pow(2.0d, (double) this.length)) - 1);
            }

            public Iterator<zzb> iterator() {
                return new Iterator<zzb>(this) {
                    private int zzbZc = (this.zzbZd.length - 1);
                    final /* synthetic */ zza zzbZd;

                    {
                        this.zzbZd = r2;
                    }

                    public boolean hasNext() {
                        return this.zzbZc >= 0;
                    }

                    public /* synthetic */ Object next() {
                        return zzVE();
                    }

                    public void remove() {
                    }

                    public zzb zzVE() {
                        boolean z = true;
                        long zzb = this.zzbZd.value & ((long) (1 << this.zzbZc));
                        zzb zzb2 = new zzb();
                        if (zzb != 0) {
                            z = false;
                        }
                        zzb2.zzbZe = z;
                        zzb2.zzbZf = (int) Math.pow(2.0d, (double) this.zzbZc);
                        this.zzbZc--;
                        return zzb2;
                    }
                };
            }
        }

        static class zzb {
            public boolean zzbZe;
            public int zzbZf;

            zzb() {
            }
        }

        private zza(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbla.zza.zza<A, B> zza) {
            this.zzbYY = list;
            this.values = map;
            this.zzbYZ = zza;
        }

        private zzblf<A, C> zzB(int i, int i2) {
            if (i2 == 0) {
                return zzble.zzVr();
            }
            if (i2 == 1) {
                Object obj = this.zzbYY.get(i);
                return new zzbld(obj, zzan(obj), null, null);
            }
            int i3 = i2 / 2;
            int i4 = i + i3;
            zzblf zzB = zzB(i, i3);
            zzblf zzB2 = zzB(i4 + 1, i3);
            obj = this.zzbYY.get(i4);
            return new zzbld(obj, zzan(obj), zzB, zzB2);
        }

        private void zza(com.google.android.gms.internal.zzblf.zza zza, int i, int i2) {
            zzblf zzB = zzB(i2 + 1, i - 1);
            Object obj = this.zzbYY.get(i2);
            Object zzblg = zza == com.google.android.gms.internal.zzblf.zza.RED ? new zzblg(obj, zzan(obj), null, zzB) : new zzbld(obj, zzan(obj), null, zzB);
            if (this.zzbZa == null) {
                this.zzbZa = zzblg;
                this.zzbZb = zzblg;
                return;
            }
            this.zzbZb.zzb(zzblg);
            this.zzbZb = zzblg;
        }

        private C zzan(A a) {
            return this.values.get(this.zzbYZ.zzai(a));
        }

        public static <A, B, C> zzbli<A, C> zzc(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbla.zza.zza<A, B> zza, Comparator<A> comparator) {
            zza zza2 = new zza(list, map, zza);
            Collections.sort(list, comparator);
            Iterator it = new zza(list.size()).iterator();
            int size = list.size();
            while (it.hasNext()) {
                int i;
                zzb zzb = (zzb) it.next();
                size -= zzb.zzbZf;
                if (zzb.zzbZe) {
                    zza2.zza(com.google.android.gms.internal.zzblf.zza.BLACK, zzb.zzbZf, size);
                    i = size;
                } else {
                    zza2.zza(com.google.android.gms.internal.zzblf.zza.BLACK, zzb.zzbZf, size);
                    size -= zzb.zzbZf;
                    zza2.zza(com.google.android.gms.internal.zzblf.zza.RED, zzb.zzbZf, size);
                    i = size;
                }
                size = i;
            }
            return new zzbli(zza2.zzbZa == null ? zzble.zzVr() : zza2.zzbZa, comparator);
        }
    }

    private zzbli(zzblf<K, V> zzblf, Comparator<K> comparator) {
        this.zzbYX = zzblf;
        this.zzbYG = comparator;
    }

    private zzblf<K, V> zzam(K k) {
        zzblf<K, V> zzblf = this.zzbYX;
        while (!zzblf.isEmpty()) {
            int compare = this.zzbYG.compare(k, zzblf.getKey());
            if (compare < 0) {
                zzblf = zzblf.zzVs();
            } else if (compare == 0) {
                return zzblf;
            } else {
                zzblf = zzblf.zzVt();
            }
        }
        return null;
    }

    public static <A, B, C> zzbli<A, C> zzc(List<A> list, Map<B, C> map, com.google.android.gms.internal.zzbla.zza.zza<A, B> zza, Comparator<A> comparator) {
        return zza.zzc(list, map, zza, comparator);
    }

    public static <A, B> zzbli<A, B> zzc(Map<A, B> map, Comparator<A> comparator) {
        return zza.zzc(new ArrayList(map.keySet()), map, com.google.android.gms.internal.zzbla.zza.zzVm(), comparator);
    }

    public boolean containsKey(K k) {
        return zzam(k) != null;
    }

    public V get(K k) {
        zzblf zzam = zzam(k);
        return zzam != null ? zzam.getValue() : null;
    }

    public Comparator<K> getComparator() {
        return this.zzbYG;
    }

    public boolean isEmpty() {
        return this.zzbYX.isEmpty();
    }

    public Iterator<Entry<K, V>> iterator() {
        return new zzblb(this.zzbYX, null, this.zzbYG, false);
    }

    public int size() {
        return this.zzbYX.zzVw();
    }

    public K zzVj() {
        return this.zzbYX.zzVu().getKey();
    }

    public K zzVk() {
        return this.zzbYX.zzVv().getKey();
    }

    public Iterator<Entry<K, V>> zzVl() {
        return new zzblb(this.zzbYX, null, this.zzbYG, true);
    }

    public void zza(zzb<K, V> zzb) {
        this.zzbYX.zza(zzb);
    }

    public zzbla<K, V> zzae(K k) {
        if (!containsKey(k)) {
            return this;
        }
        return new zzbli(this.zzbYX.zza(k, this.zzbYG).zza(null, null, com.google.android.gms.internal.zzblf.zza.BLACK, null, null), this.zzbYG);
    }

    public K zzaf(K k) {
        zzblf zzblf = this.zzbYX;
        zzblf zzblf2 = null;
        while (!zzblf.isEmpty()) {
            int compare = this.zzbYG.compare(k, zzblf.getKey());
            if (compare == 0) {
                if (zzblf.zzVs().isEmpty()) {
                    return zzblf2 != null ? zzblf2.getKey() : null;
                } else {
                    zzblf2 = zzblf.zzVs();
                    while (!zzblf2.zzVt().isEmpty()) {
                        zzblf2 = zzblf2.zzVt();
                    }
                    return zzblf2.getKey();
                }
            } else if (compare < 0) {
                zzblf = zzblf.zzVs();
            } else {
                zzblf zzblf3 = zzblf;
                zzblf = zzblf.zzVt();
                zzblf2 = zzblf3;
            }
        }
        String valueOf = String.valueOf(k);
        throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Couldn't find predecessor key of non-present key: ").append(valueOf).toString());
    }

    public zzbla<K, V> zzj(K k, V v) {
        return new zzbli(this.zzbYX.zza(k, v, this.zzbYG).zza(null, null, com.google.android.gms.internal.zzblf.zza.BLACK, null, null), this.zzbYG);
    }
}
