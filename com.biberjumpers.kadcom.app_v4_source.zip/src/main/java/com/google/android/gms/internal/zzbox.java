package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbpe.zza;
import java.util.Collections;
import java.util.Iterator;

public class zzbox extends zzbot implements zzbpe {
    private static final zzbox zzchh = new zzbox();

    private zzbox() {
    }

    public static zzbox zzZp() {
        return zzchh;
    }

    public /* synthetic */ int compareTo(Object obj) {
        return zzh((zzbpe) obj);
    }

    public boolean equals(Object obj) {
        if (obj instanceof zzbox) {
            return true;
        }
        boolean z = (obj instanceof zzbpe) && ((zzbpe) obj).isEmpty() && zzZe().equals(((zzbpe) obj).zzZe());
        return z;
    }

    public int getChildCount() {
        return 0;
    }

    public Object getValue() {
        return null;
    }

    public Object getValue(boolean z) {
        return null;
    }

    public int hashCode() {
        return 0;
    }

    public boolean isEmpty() {
        return true;
    }

    public Iterator<zzbpd> iterator() {
        return Collections.emptyList().iterator();
    }

    public String toString() {
        return "<Empty Node>";
    }

    public zzbpe zzO(zzbmj zzbmj) {
        return this;
    }

    public Iterator<zzbpd> zzVl() {
        return Collections.emptyList().iterator();
    }

    public String zzZc() {
        return "";
    }

    public boolean zzZd() {
        return false;
    }

    public zzbpe zzZe() {
        return this;
    }

    public String zza(zza zza) {
        return "";
    }

    public zzbpe zze(zzbos zzbos, zzbpe zzbpe) {
        return (zzbpe.isEmpty() || zzbos.zzZa()) ? this : new zzbot().zze(zzbos, zzbpe);
    }

    public /* synthetic */ zzbpe zzg(zzbpe zzbpe) {
        return zzl(zzbpe);
    }

    public int zzh(zzbpe zzbpe) {
        return zzbpe.isEmpty() ? 0 : -1;
    }

    public boolean zzk(zzbos zzbos) {
        return false;
    }

    public zzbos zzl(zzbos zzbos) {
        return null;
    }

    public zzbox zzl(zzbpe zzbpe) {
        return this;
    }

    public zzbpe zzl(zzbmj zzbmj, zzbpe zzbpe) {
        if (zzbmj.isEmpty()) {
            return zzbpe;
        }
        zzbos zzXi = zzbmj.zzXi();
        return zze(zzXi, zzm(zzXi).zzl(zzbmj.zzXj(), zzbpe));
    }

    public zzbpe zzm(zzbos zzbos) {
        return this;
    }
}
