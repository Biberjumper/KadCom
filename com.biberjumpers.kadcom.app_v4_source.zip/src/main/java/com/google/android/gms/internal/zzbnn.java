package com.google.android.gms.internal;

import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

public interface zzbnn {
    List<zzbmx> zzVe();

    void zzVh();

    void zza(zzbmj zzbmj, zzbma zzbma, long j);

    void zza(zzbmj zzbmj, zzbpe zzbpe, long j);

    void zza(zzboe zzboe, zzbpe zzbpe);

    void zza(zzboe zzboe, Set<zzbos> set);

    void zza(zzboe zzboe, Set<zzbos> set, Set<zzbos> set2);

    void zzaA(long j);

    void zzc(zzbmj zzbmj, zzbma zzbma);

    void zzd(zzbmj zzbmj, zzbma zzbma);

    zzbnw zzf(zzboe zzboe);

    <T> T zzf(Callable<T> callable);

    void zzg(zzboe zzboe);

    void zzh(zzboe zzboe);

    void zzi(zzboe zzboe);

    void zzk(zzbmj zzbmj, zzbpe zzbpe);
}
