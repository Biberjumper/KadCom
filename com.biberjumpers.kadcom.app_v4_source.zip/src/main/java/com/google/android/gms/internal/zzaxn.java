package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzr;

public interface zzaxn extends zze {
    void connect();

    void zzOe();

    void zza(zzr zzr, boolean z);

    void zza(zzaxu zzaxu);
}
