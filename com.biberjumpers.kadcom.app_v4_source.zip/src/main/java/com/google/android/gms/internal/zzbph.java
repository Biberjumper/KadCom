package com.google.android.gms.internal;

public class zzbph extends zzboy {
    private static final zzbph zzchz = new zzbph();

    private zzbph() {
    }

    public static zzbph zzZA() {
        return zzchz;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return zza((zzbpd) obj, (zzbpd) obj2);
    }

    public boolean equals(Object obj) {
        return obj instanceof zzbph;
    }

    public int hashCode() {
        return 3155577;
    }

    public String toString() {
        return "PriorityIndex";
    }

    public zzbpd zzZr() {
        return zzg(zzbos.zzYX(), zzbpe.zzchu);
    }

    public String zzZs() {
        throw new IllegalArgumentException("Can't get query definition on priority index!");
    }

    public int zza(zzbpd zzbpd, zzbpd zzbpd2) {
        return zzbpf.zza(zzbpd.zzZz(), zzbpd.zzUY().zzZe(), zzbpd2.zzZz(), zzbpd2.zzUY().zzZe());
    }

    public zzbpd zzg(zzbos zzbos, zzbpe zzbpe) {
        return new zzbpd(zzbos, new zzbpk("[PRIORITY-POST]", zzbpe));
    }

    public boolean zzm(zzbpe zzbpe) {
        return !zzbpe.zzZe().isEmpty();
    }
}
