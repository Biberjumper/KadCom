package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseError;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class zzbof {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbof.class.desiredAssertionStatus());
    private final zzboe zzcfS;
    private final zzboh zzcgj;
    private zzbog zzcgk;
    private final List<zzbme> zzcgl = new ArrayList();
    private final zzbob zzcgm;

    public static class zza {
        public final List<zzbnz> zzcgn;
        public final List<zzbny> zzcgo;

        public zza(List<zzbnz> list, List<zzbny> list2) {
            this.zzcgn = list;
            this.zzcgo = list2;
        }
    }

    public zzbof(zzboe zzboe, zzbog zzbog) {
        this.zzcfS = zzboe;
        zzboj zzboj = new zzboj(zzboe.zzYz());
        zzbol zzYF = zzboe.zzYG().zzYF();
        this.zzcgj = new zzboh(zzYF);
        zzbnw zzYM = zzbog.zzYM();
        zzbnw zzYK = zzbog.zzYK();
        zzboz zza = zzboz.zza(zzbox.zzZp(), zzboe.zzYz());
        zzboz zza2 = zzboj.zza(zza, zzYM.zzYi(), null);
        zza = zzYF.zza(zza, zzYK.zzYi(), null);
        this.zzcgk = new zzbog(new zzbnw(zza, zzYK.zzYg(), zzYF.zzYQ()), new zzbnw(zza2, zzYM.zzYg(), zzboj.zzYQ()));
        this.zzcgm = new zzbob(zzboe);
    }

    private List<zzbnz> zza(List<zzbny> list, zzboz zzboz, zzbme zzbme) {
        List list2;
        if (zzbme == null) {
            list2 = this.zzcgl;
        } else {
            list2 = Arrays.asList(new zzbme[]{zzbme});
        }
        return this.zzcgm.zza((List) list, zzboz, list2);
    }

    public boolean isEmpty() {
        return this.zzcgl.isEmpty();
    }

    public zzboe zzYH() {
        return this.zzcfS;
    }

    public zzbpe zzYI() {
        return this.zzcgk.zzYM().zzUY();
    }

    public zzbpe zzYJ() {
        return this.zzcgk.zzYK().zzUY();
    }

    public List<zzboa> zza(zzbme zzbme, DatabaseError databaseError) {
        zzbme zzbme2;
        List<zzboa> list;
        if (databaseError != null) {
            List<zzboa> arrayList = new ArrayList();
            if ($assertionsDisabled || zzbme == null) {
                zzbmj zzVc = this.zzcfS.zzVc();
                for (zzbme zzbme22 : this.zzcgl) {
                    arrayList.add(new zzbnx(zzbme22, databaseError, zzVc));
                }
                list = arrayList;
            } else {
                throw new AssertionError("A cancel should cancel all event registrations");
            }
        }
        list = Collections.emptyList();
        if (zzbme != null) {
            int i = 0;
            int i2 = -1;
            while (i < this.zzcgl.size()) {
                zzbme22 = (zzbme) this.zzcgl.get(i);
                if (zzbme22.zzc(zzbme)) {
                    if (zzbme22.zzXb()) {
                        break;
                    }
                    i2 = i;
                }
                i++;
            }
            i = i2;
            if (i != -1) {
                zzbme22 = (zzbme) this.zzcgl.get(i);
                this.zzcgl.remove(i);
                zzbme22.zzXa();
            }
        } else {
            for (zzbme zzbme222 : this.zzcgl) {
                zzbme222.zzXa();
            }
            this.zzcgl.clear();
        }
        return list;
    }

    public zza zzb(zzbng zzbng, zzbnb zzbnb, zzbpe zzbpe) {
        if (zzbng.zzXP() == com.google.android.gms.internal.zzbng.zza.Merge && zzbng.zzXO().zzXT() != null) {
            if (!$assertionsDisabled && this.zzcgk.zzYN() == null) {
                throw new AssertionError("We should always have a full cache before handling merges");
            } else if (!$assertionsDisabled && this.zzcgk.zzYL() == null) {
                throw new AssertionError("Missing event cache, even though we have a server cache");
            }
        }
        zzbog zzbog = this.zzcgk;
        com.google.android.gms.internal.zzboh.zza zza = this.zzcgj.zza(zzbog, zzbng, zzbnb, zzbpe);
        if ($assertionsDisabled || zza.zzcgk.zzYM().zzYg() || !zzbog.zzYM().zzYg()) {
            this.zzcgk = zza.zzcgk;
            return new zza(zza(zza.zzcgo, zza.zzcgk.zzYK().zzYi(), null), zza.zzcgo);
        }
        throw new AssertionError("Once a server snap is complete, it should never go back");
    }

    public void zzb(zzbme zzbme) {
        this.zzcgl.add(zzbme);
    }

    public List<zzbnz> zzl(zzbme zzbme) {
        zzbnw zzYK = this.zzcgk.zzYK();
        List arrayList = new ArrayList();
        for (zzbpd zzbpd : zzYK.zzUY()) {
            arrayList.add(zzbny.zzc(zzbpd.zzZz(), zzbpd.zzUY()));
        }
        if (zzYK.zzYg()) {
            arrayList.add(zzbny.zza(zzYK.zzYi()));
        }
        return zza(arrayList, zzYK.zzYi(), zzbme);
    }

    public zzbpe zzs(zzbmj zzbmj) {
        zzbpe zzYN = this.zzcgk.zzYN();
        return (zzYN == null || (!this.zzcfS.zzYD() && (zzbmj.isEmpty() || zzYN.zzm(zzbmj.zzXi()).isEmpty()))) ? null : zzYN.zzO(zzbmj);
    }
}
