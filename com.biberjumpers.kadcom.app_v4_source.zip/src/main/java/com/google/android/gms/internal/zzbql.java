package com.google.android.gms.internal;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.GetTokenResult;

public interface zzbql {
    Task<GetTokenResult> zzaS(boolean z);
}
