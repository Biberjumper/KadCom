package com.google.android.gms.internal;

import com.google.android.gms.internal.zzboa.zza;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class zzbob {
    private final zzboe zzcfS;
    private final zzboy zzcfT;

    public zzbob(zzboe zzboe) {
        this.zzcfS = zzboe;
        this.zzcfT = zzboe.zzYz();
    }

    private Comparator<zzbny> zzYq() {
        return new Comparator<zzbny>(this) {
            static final /* synthetic */ boolean $assertionsDisabled = (!zzbob.class.desiredAssertionStatus());
            final /* synthetic */ zzbob zzcfU;

            {
                this.zzcfU = r1;
            }

            public /* synthetic */ int compare(Object obj, Object obj2) {
                return zza((zzbny) obj, (zzbny) obj2);
            }

            public int zza(zzbny zzbny, zzbny zzbny2) {
                if ($assertionsDisabled || !(zzbny.zzYk() == null || zzbny2.zzYk() == null)) {
                    return this.zzcfU.zzcfT.compare(new zzbpd(zzbny.zzYk(), zzbny.zzYi().zzUY()), new zzbpd(zzbny2.zzYk(), zzbny2.zzYi().zzUY()));
                }
                throw new AssertionError();
            }
        };
    }

    private zzbnz zza(zzbny zzbny, zzbme zzbme, zzboz zzboz) {
        if (!(zzbny.zzYl().equals(zza.VALUE) || zzbny.zzYl().equals(zza.CHILD_REMOVED))) {
            zzbny = zzbny.zzg(zzboz.zza(zzbny.zzYk(), zzbny.zzYi().zzUY(), this.zzcfT));
        }
        return zzbme.zza(zzbny, this.zzcfS);
    }

    private void zza(List<zzbnz> list, zza zza, List<zzbny> list2, List<zzbme> list3, zzboz zzboz) {
        List<zzbny> arrayList = new ArrayList();
        for (zzbny zzbny : list2) {
            if (zzbny.zzYl().equals(zza)) {
                arrayList.add(zzbny);
            }
        }
        Collections.sort(arrayList, zzYq());
        for (zzbny zzbny2 : arrayList) {
            for (zzbme zzbme : list3) {
                if (zzbme.zza(zza)) {
                    list.add(zza(zzbny2, zzbme, zzboz));
                }
            }
        }
    }

    public List<zzbnz> zza(List<zzbny> list, zzboz zzboz, List<zzbme> list2) {
        List<zzbnz> arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        for (zzbny zzbny : list) {
            if (zzbny.zzYl().equals(zza.CHILD_CHANGED) && this.zzcfT.zza(zzbny.zzYn().zzUY(), zzbny.zzYi().zzUY())) {
                arrayList2.add(zzbny.zzc(zzbny.zzYk(), zzbny.zzYi()));
            }
        }
        zza(arrayList, zza.CHILD_REMOVED, list, list2, zzboz);
        zza(arrayList, zza.CHILD_ADDED, list, list2, zzboz);
        zza(arrayList, zza.CHILD_MOVED, arrayList2, list2, zzboz);
        zza(arrayList, zza.CHILD_CHANGED, list, list2, zzboz);
        zza(arrayList, zza.VALUE, list, list2, zzboz);
        return arrayList;
    }
}
