package com.google.android.gms.internal;

public class zzbqc implements zzbpy {
    private final zzbpy zzciw;
    private long zzcix = 0;

    public zzbqc(zzbpy zzbpy, long j) {
        this.zzciw = zzbpy;
        this.zzcix = j;
    }

    public long zzZY() {
        return this.zzciw.zzZY() + this.zzcix;
    }

    public void zzaP(long j) {
        this.zzcix = j;
    }
}
