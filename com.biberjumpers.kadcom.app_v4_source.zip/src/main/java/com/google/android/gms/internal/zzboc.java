package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class zzboc {
    private final zzbop zzbYx;
    private final zzbmg zzcbK;

    public zzboc(zzbmc zzbmc) {
        this.zzcbK = zzbmc.zzWQ();
        this.zzbYx = zzbmc.zziW("EventRaiser");
    }

    public void zzY(List<? extends zzboa> list) {
        if (this.zzbYx.zzYT()) {
            this.zzbYx.zzi("Raising " + list.size() + " event(s)", new Object[0]);
        }
        final ArrayList arrayList = new ArrayList(list);
        this.zzcbK.zzq(new Runnable(this) {
            final /* synthetic */ zzboc zzcfW;

            public void run() {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    zzboa zzboa = (zzboa) it.next();
                    if (this.zzcfW.zzbYx.zzYT()) {
                        zzbop zza = this.zzcfW.zzbYx;
                        String str = "Raising ";
                        String valueOf = String.valueOf(zzboa.toString());
                        zza.zzi(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), new Object[0]);
                    }
                    zzboa.zzYj();
                }
            }
        });
    }
}
