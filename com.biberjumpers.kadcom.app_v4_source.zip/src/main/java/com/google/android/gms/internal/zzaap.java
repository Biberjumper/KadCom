package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions;
import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.zzc;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.internal.zzal;
import com.google.android.gms.common.internal.zzf.zzf;
import com.google.android.gms.common.internal.zzr;
import com.google.android.gms.internal.zzzq.zzd;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class zzaap implements Callback {
    public static final Status zzaAO = new Status(4, "Sign-out occurred while this API call was in progress.");
    private static final Status zzaAP = new Status(4, "The user must be signed in to make this API call.");
    private static zzaap zzaAR;
    private static final Object zztU = new Object();
    private final Context mContext;
    private final Handler mHandler;
    private long zzaAQ = 10000;
    private int zzaAS = -1;
    private final AtomicInteger zzaAT = new AtomicInteger(1);
    private final AtomicInteger zzaAU = new AtomicInteger(0);
    private zzaae zzaAV = null;
    private final Set<zzzs<?>> zzaAW = new com.google.android.gms.common.util.zza();
    private final Set<zzzs<?>> zzaAX = new com.google.android.gms.common.util.zza();
    private long zzaAn = 120000;
    private long zzaAo = 5000;
    private final GoogleApiAvailability zzaxX;
    private final Map<zzzs<?>, zza<?>> zzazt = new ConcurrentHashMap(5, 0.75f, 1);

    private class zzb implements zzf, com.google.android.gms.internal.zzabj.zza {
        final /* synthetic */ zzaap zzaBg;
        private boolean zzaBj = false;
        private Set<Scope> zzajm = null;
        private final zzzs<?> zzaxH;
        private zzr zzazW = null;
        private final zze zzazq;

        public zzb(zzaap zzaap, zze zze, zzzs<?> zzzs) {
            this.zzaBg = zzaap;
            this.zzazq = zze;
            this.zzaxH = zzzs;
        }

        @WorkerThread
        private void zzwi() {
            if (this.zzaBj && this.zzazW != null) {
                this.zzazq.zza(this.zzazW, this.zzajm);
            }
        }

        @WorkerThread
        public void zzb(zzr zzr, Set<Scope> set) {
            if (zzr == null || set == null) {
                Log.wtf("GoogleApiManager", "Received null response from onSignInSuccess", new Exception());
                zzi(new ConnectionResult(4));
                return;
            }
            this.zzazW = zzr;
            this.zzajm = set;
            zzwi();
        }

        public void zzg(@NonNull final ConnectionResult connectionResult) {
            this.zzaBg.mHandler.post(new Runnable(this) {
                final /* synthetic */ zzb zzaBk;

                public void run() {
                    if (connectionResult.isSuccess()) {
                        this.zzaBk.zzaBj = true;
                        if (this.zzaBk.zzazq.zzqD()) {
                            this.zzaBk.zzwi();
                            return;
                        } else {
                            this.zzaBk.zzazq.zza(null, Collections.emptySet());
                            return;
                        }
                    }
                    ((zza) this.zzaBk.zzaBg.zzazt.get(this.zzaBk.zzaxH)).onConnectionFailed(connectionResult);
                }
            });
        }

        @WorkerThread
        public void zzi(ConnectionResult connectionResult) {
            ((zza) this.zzaBg.zzazt.get(this.zzaxH)).zzi(connectionResult);
        }
    }

    public class zza<O extends ApiOptions> implements ConnectionCallbacks, OnConnectionFailedListener, zzzz {
        private final Queue<zzzq> zzaAY = new LinkedList();
        private final com.google.android.gms.common.api.Api.zzb zzaAZ;
        private boolean zzaAm;
        private final zzaad zzaBa;
        private final Set<zzzu> zzaBb = new HashSet();
        private final Map<com.google.android.gms.internal.zzaaz.zzb<?>, zzabf> zzaBc = new HashMap();
        private final int zzaBd;
        private final zzabj zzaBe;
        private ConnectionResult zzaBf = null;
        final /* synthetic */ zzaap zzaBg;
        private final zzzs<O> zzaxH;
        private final zze zzazq;

        @WorkerThread
        public zza(zzaap zzaap, zzc<O> zzc) {
            this.zzaBg = zzaap;
            this.zzazq = zzc.buildApiClient(zzaap.mHandler.getLooper(), this);
            if (this.zzazq instanceof zzal) {
                this.zzaAZ = ((zzal) this.zzazq).zzxG();
            } else {
                this.zzaAZ = this.zzazq;
            }
            this.zzaxH = zzc.getApiKey();
            this.zzaBa = new zzaad();
            this.zzaBd = zzc.getInstanceId();
            if (this.zzazq.zzqD()) {
                this.zzaBe = zzc.createSignInCoordinator(zzaap.mContext, zzaap.mHandler);
            } else {
                this.zzaBe = null;
            }
        }

        @WorkerThread
        private void zzb(zzzq zzzq) {
            zzzq.zza(this.zzaBa, zzqD());
            try {
                zzzq.zza(this);
            } catch (DeadObjectException e) {
                onConnectionSuspended(1);
                this.zzazq.disconnect();
            }
        }

        @WorkerThread
        private void zzj(ConnectionResult connectionResult) {
            for (zzzu zza : this.zzaBb) {
                zza.zza(this.zzaxH, connectionResult);
            }
            this.zzaBb.clear();
        }

        @WorkerThread
        private void zzvZ() {
            zzwd();
            zzj(ConnectionResult.zzawX);
            zzwf();
            Iterator it = this.zzaBc.values().iterator();
            while (it.hasNext()) {
                it.next();
                try {
                    TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
                } catch (DeadObjectException e) {
                    onConnectionSuspended(1);
                    this.zzazq.disconnect();
                } catch (RemoteException e2) {
                }
            }
            zzwb();
            zzwg();
        }

        @WorkerThread
        private void zzwa() {
            zzwd();
            this.zzaAm = true;
            this.zzaBa.zzvw();
            this.zzaBg.mHandler.sendMessageDelayed(Message.obtain(this.zzaBg.mHandler, 7, this.zzaxH), this.zzaBg.zzaAo);
            this.zzaBg.mHandler.sendMessageDelayed(Message.obtain(this.zzaBg.mHandler, 9, this.zzaxH), this.zzaBg.zzaAn);
            this.zzaBg.zzaAS = -1;
        }

        @WorkerThread
        private void zzwb() {
            while (this.zzazq.isConnected() && !this.zzaAY.isEmpty()) {
                zzb((zzzq) this.zzaAY.remove());
            }
        }

        @WorkerThread
        private void zzwf() {
            if (this.zzaAm) {
                this.zzaBg.mHandler.removeMessages(9, this.zzaxH);
                this.zzaBg.mHandler.removeMessages(7, this.zzaxH);
                this.zzaAm = false;
            }
        }

        private void zzwg() {
            this.zzaBg.mHandler.removeMessages(10, this.zzaxH);
            this.zzaBg.mHandler.sendMessageDelayed(this.zzaBg.mHandler.obtainMessage(10, this.zzaxH), this.zzaBg.zzaAQ);
        }

        @WorkerThread
        public void connect() {
            zzac.zza(this.zzaBg.mHandler);
            if (!this.zzazq.isConnected() && !this.zzazq.isConnecting()) {
                if (this.zzazq.zzuI() && this.zzaBg.zzaAS != 0) {
                    this.zzaBg.zzaAS = this.zzaBg.zzaxX.isGooglePlayServicesAvailable(this.zzaBg.mContext);
                    if (this.zzaBg.zzaAS != 0) {
                        onConnectionFailed(new ConnectionResult(this.zzaBg.zzaAS, null));
                        return;
                    }
                }
                Object zzb = new zzb(this.zzaBg, this.zzazq, this.zzaxH);
                if (this.zzazq.zzqD()) {
                    this.zzaBe.zza(zzb);
                }
                this.zzazq.zza(zzb);
            }
        }

        public int getInstanceId() {
            return this.zzaBd;
        }

        boolean isConnected() {
            return this.zzazq.isConnected();
        }

        public void onConnected(@Nullable Bundle bundle) {
            if (Looper.myLooper() == this.zzaBg.mHandler.getLooper()) {
                zzvZ();
            } else {
                this.zzaBg.mHandler.post(new Runnable(this) {
                    final /* synthetic */ zza zzaBh;

                    {
                        this.zzaBh = r1;
                    }

                    public void run() {
                        this.zzaBh.zzvZ();
                    }
                });
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        @android.support.annotation.WorkerThread
        public void onConnectionFailed(@android.support.annotation.NonNull com.google.android.gms.common.ConnectionResult r6) {
            /*
            r5 = this;
            r0 = r5.zzaBg;
            r0 = r0.mHandler;
            com.google.android.gms.common.internal.zzac.zza(r0);
            r0 = r5.zzaBe;
            if (r0 == 0) goto L_0x0012;
        L_0x000d:
            r0 = r5.zzaBe;
            r0.zzwr();
        L_0x0012:
            r5.zzwd();
            r0 = r5.zzaBg;
            r1 = -1;
            r0.zzaAS = r1;
            r5.zzj(r6);
            r0 = r6.getErrorCode();
            r1 = 4;
            if (r0 != r1) goto L_0x002d;
        L_0x0025:
            r0 = com.google.android.gms.internal.zzaap.zzaAP;
            r5.zzC(r0);
        L_0x002c:
            return;
        L_0x002d:
            r0 = r5.zzaAY;
            r0 = r0.isEmpty();
            if (r0 == 0) goto L_0x0038;
        L_0x0035:
            r5.zzaBf = r6;
            goto L_0x002c;
        L_0x0038:
            r1 = com.google.android.gms.internal.zzaap.zztU;
            monitor-enter(r1);
            r0 = r5.zzaBg;	 Catch:{ all -> 0x0060 }
            r0 = r0.zzaAV;	 Catch:{ all -> 0x0060 }
            if (r0 == 0) goto L_0x0063;
        L_0x0045:
            r0 = r5.zzaBg;	 Catch:{ all -> 0x0060 }
            r0 = r0.zzaAW;	 Catch:{ all -> 0x0060 }
            r2 = r5.zzaxH;	 Catch:{ all -> 0x0060 }
            r0 = r0.contains(r2);	 Catch:{ all -> 0x0060 }
            if (r0 == 0) goto L_0x0063;
        L_0x0053:
            r0 = r5.zzaBg;	 Catch:{ all -> 0x0060 }
            r0 = r0.zzaAV;	 Catch:{ all -> 0x0060 }
            r2 = r5.zzaBd;	 Catch:{ all -> 0x0060 }
            r0.zzb(r6, r2);	 Catch:{ all -> 0x0060 }
            monitor-exit(r1);	 Catch:{ all -> 0x0060 }
            goto L_0x002c;
        L_0x0060:
            r0 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x0060 }
            throw r0;
        L_0x0063:
            monitor-exit(r1);	 Catch:{ all -> 0x0060 }
            r0 = r5.zzaBg;
            r1 = r5.zzaBd;
            r0 = r0.zzc(r6, r1);
            if (r0 != 0) goto L_0x002c;
        L_0x006e:
            r0 = r6.getErrorCode();
            r1 = 18;
            if (r0 != r1) goto L_0x0079;
        L_0x0076:
            r0 = 1;
            r5.zzaAm = r0;
        L_0x0079:
            r0 = r5.zzaAm;
            if (r0 == 0) goto L_0x009a;
        L_0x007d:
            r0 = r5.zzaBg;
            r0 = r0.mHandler;
            r1 = r5.zzaBg;
            r1 = r1.mHandler;
            r2 = 7;
            r3 = r5.zzaxH;
            r1 = android.os.Message.obtain(r1, r2, r3);
            r2 = r5.zzaBg;
            r2 = r2.zzaAo;
            r0.sendMessageDelayed(r1, r2);
            goto L_0x002c;
        L_0x009a:
            r0 = new com.google.android.gms.common.api.Status;
            r1 = 17;
            r2 = r5.zzaxH;
            r2 = r2.zzuV();
            r2 = java.lang.String.valueOf(r2);
            r3 = new java.lang.StringBuilder;
            r4 = java.lang.String.valueOf(r2);
            r4 = r4.length();
            r4 = r4 + 38;
            r3.<init>(r4);
            r4 = "API: ";
            r3 = r3.append(r4);
            r2 = r3.append(r2);
            r3 = " is not available on this device.";
            r2 = r2.append(r3);
            r2 = r2.toString();
            r0.<init>(r1, r2);
            r5.zzC(r0);
            goto L_0x002c;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzaap.zza.onConnectionFailed(com.google.android.gms.common.ConnectionResult):void");
        }

        public void onConnectionSuspended(int i) {
            if (Looper.myLooper() == this.zzaBg.mHandler.getLooper()) {
                zzwa();
            } else {
                this.zzaBg.mHandler.post(new Runnable(this) {
                    final /* synthetic */ zza zzaBh;

                    {
                        this.zzaBh = r1;
                    }

                    public void run() {
                        this.zzaBh.zzwa();
                    }
                });
            }
        }

        @WorkerThread
        public void resume() {
            zzac.zza(this.zzaBg.mHandler);
            if (this.zzaAm) {
                connect();
            }
        }

        @WorkerThread
        public void signOut() {
            zzac.zza(this.zzaBg.mHandler);
            zzC(zzaap.zzaAO);
            this.zzaBa.zzvv();
            for (com.google.android.gms.internal.zzaaz.zzb zze : this.zzaBc.keySet()) {
                zza(new zzzq.zze(zze, new TaskCompletionSource()));
            }
            this.zzazq.disconnect();
        }

        @WorkerThread
        public void zzC(Status status) {
            zzac.zza(this.zzaBg.mHandler);
            for (zzzq zzy : this.zzaAY) {
                zzy.zzy(status);
            }
            this.zzaAY.clear();
        }

        public void zza(final ConnectionResult connectionResult, Api<?> api, int i) {
            if (Looper.myLooper() == this.zzaBg.mHandler.getLooper()) {
                onConnectionFailed(connectionResult);
            } else {
                this.zzaBg.mHandler.post(new Runnable(this) {
                    final /* synthetic */ zza zzaBh;

                    public void run() {
                        this.zzaBh.onConnectionFailed(connectionResult);
                    }
                });
            }
        }

        @WorkerThread
        public void zza(zzzq zzzq) {
            zzac.zza(this.zzaBg.mHandler);
            if (this.zzazq.isConnected()) {
                zzb(zzzq);
                zzwg();
                return;
            }
            this.zzaAY.add(zzzq);
            if (this.zzaBf == null || !this.zzaBf.hasResolution()) {
                connect();
            } else {
                onConnectionFailed(this.zzaBf);
            }
        }

        @WorkerThread
        public void zzb(zzzu zzzu) {
            zzac.zza(this.zzaBg.mHandler);
            this.zzaBb.add(zzzu);
        }

        @WorkerThread
        public void zzi(@NonNull ConnectionResult connectionResult) {
            zzac.zza(this.zzaBg.mHandler);
            this.zzazq.disconnect();
            onConnectionFailed(connectionResult);
        }

        public boolean zzqD() {
            return this.zzazq.zzqD();
        }

        @WorkerThread
        public void zzvJ() {
            zzac.zza(this.zzaBg.mHandler);
            if (this.zzaAm) {
                zzwf();
                zzC(this.zzaBg.zzaxX.isGooglePlayServicesAvailable(this.zzaBg.mContext) == 18 ? new Status(8, "Connection timed out while waiting for Google Play services update to complete.") : new Status(8, "API failed to connect while resuming due to an unknown error."));
                this.zzazq.disconnect();
            }
        }

        public zze zzvr() {
            return this.zzazq;
        }

        public Map<com.google.android.gms.internal.zzaaz.zzb<?>, zzabf> zzwc() {
            return this.zzaBc;
        }

        @WorkerThread
        public void zzwd() {
            zzac.zza(this.zzaBg.mHandler);
            this.zzaBf = null;
        }

        @WorkerThread
        public ConnectionResult zzwe() {
            zzac.zza(this.zzaBg.mHandler);
            return this.zzaBf;
        }

        @WorkerThread
        public void zzwh() {
            zzac.zza(this.zzaBg.mHandler);
            if (!this.zzazq.isConnected() || this.zzaBc.size() != 0) {
                return;
            }
            if (this.zzaBa.zzvu()) {
                zzwg();
            } else {
                this.zzazq.disconnect();
            }
        }
    }

    private zzaap(Context context, Looper looper, GoogleApiAvailability googleApiAvailability) {
        this.mContext = context;
        this.mHandler = new Handler(looper, this);
        this.zzaxX = googleApiAvailability;
    }

    @WorkerThread
    private void zza(int i, ConnectionResult connectionResult) {
        for (zza zza : this.zzazt.values()) {
            if (zza.getInstanceId() == i) {
                break;
            }
        }
        zza zza2 = null;
        if (zza2 != null) {
            String valueOf = String.valueOf(this.zzaxX.getErrorString(connectionResult.getErrorCode()));
            String valueOf2 = String.valueOf(connectionResult.getErrorMessage());
            zza2.zzC(new Status(17, new StringBuilder((String.valueOf(valueOf).length() + 69) + String.valueOf(valueOf2).length()).append("Error resolution was canceled by the user, original error message: ").append(valueOf).append(": ").append(valueOf2).toString()));
            return;
        }
        Log.wtf("GoogleApiManager", "Could not find API instance " + i + " while trying to fail enqueued calls.", new Exception());
    }

    @WorkerThread
    private void zza(zzabd zzabd) {
        zza zza = (zza) this.zzazt.get(zzabd.zzaBF.getApiKey());
        if (zza == null) {
            zzb(zzabd.zzaBF);
            zza = (zza) this.zzazt.get(zzabd.zzaBF.getApiKey());
        }
        if (!zza.zzqD() || this.zzaAU.get() == zzabd.zzaBE) {
            zza.zza(zzabd.zzaBD);
            return;
        }
        zzabd.zzaBD.zzy(zzaAO);
        zza.signOut();
    }

    @WorkerThread
    private void zza(zzzu zzzu) {
        for (zzzs zzzs : zzzu.zzuY()) {
            zza zza = (zza) this.zzazt.get(zzzs);
            if (zza == null) {
                zzzu.zza(zzzs, new ConnectionResult(13));
                return;
            } else if (zza.isConnected()) {
                zzzu.zza(zzzs, ConnectionResult.zzawX);
            } else if (zza.zzwe() != null) {
                zzzu.zza(zzzs, zza.zzwe());
            } else {
                zza.zzb(zzzu);
            }
        }
    }

    public static zzaap zzax(Context context) {
        zzaap zzaap;
        synchronized (zztU) {
            if (zzaAR == null) {
                zzaAR = new zzaap(context.getApplicationContext(), zzvT(), GoogleApiAvailability.getInstance());
            }
            zzaap = zzaAR;
        }
        return zzaap;
    }

    @WorkerThread
    private void zzb(zzc<?> zzc) {
        zzzs apiKey = zzc.getApiKey();
        if (!this.zzazt.containsKey(apiKey)) {
            this.zzazt.put(apiKey, new zza(this, zzc));
        }
        zza zza = (zza) this.zzazt.get(apiKey);
        if (zza.zzqD()) {
            this.zzaAX.add(apiKey);
        }
        zza.connect();
    }

    public static zzaap zzvS() {
        zzaap zzaap;
        synchronized (zztU) {
            zzac.zzb(zzaAR, (Object) "Must guarantee manager is non-null before using getInstance");
            zzaap = zzaAR;
        }
        return zzaap;
    }

    private static Looper zzvT() {
        HandlerThread handlerThread = new HandlerThread("GoogleApiHandler", 9);
        handlerThread.start();
        return handlerThread.getLooper();
    }

    @WorkerThread
    private void zzvV() {
        for (zza zza : this.zzazt.values()) {
            zza.zzwd();
            zza.connect();
        }
    }

    @WorkerThread
    private void zzvW() {
        for (zzzs remove : this.zzaAX) {
            ((zza) this.zzazt.remove(remove)).signOut();
        }
        this.zzaAX.clear();
    }

    @WorkerThread
    public boolean handleMessage(Message message) {
        switch (message.what) {
            case 1:
                zza((zzzu) message.obj);
                break;
            case 2:
                zzvV();
                break;
            case 3:
            case 6:
            case 11:
                zza((zzabd) message.obj);
                break;
            case 4:
                zza(message.arg1, (ConnectionResult) message.obj);
                break;
            case 5:
                zzb((zzc) message.obj);
                break;
            case 7:
                if (this.zzazt.containsKey(message.obj)) {
                    ((zza) this.zzazt.get(message.obj)).resume();
                    break;
                }
                break;
            case 8:
                zzvW();
                break;
            case 9:
                if (this.zzazt.containsKey(message.obj)) {
                    ((zza) this.zzazt.get(message.obj)).zzvJ();
                    break;
                }
                break;
            case 10:
                if (this.zzazt.containsKey(message.obj)) {
                    ((zza) this.zzazt.get(message.obj)).zzwh();
                    break;
                }
                break;
            default:
                Log.w("GoogleApiManager", "Unknown message id: " + message.what);
                return false;
        }
        return true;
    }

    public <O extends ApiOptions> Task<Void> zza(@NonNull zzc<O> zzc, @NonNull com.google.android.gms.internal.zzaaz.zzb<?> zzb) {
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        this.mHandler.sendMessage(this.mHandler.obtainMessage(11, new zzabd(new zzzq.zze(zzb, taskCompletionSource), this.zzaAU.get(), zzc)));
        return taskCompletionSource.getTask();
    }

    public <O extends ApiOptions> Task<Void> zza(@NonNull zzc<O> zzc, @NonNull zzabe<com.google.android.gms.common.api.Api.zzb, ?> zzabe, @NonNull zzabr<com.google.android.gms.common.api.Api.zzb, ?> zzabr) {
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        this.mHandler.sendMessage(this.mHandler.obtainMessage(6, new zzabd(new zzzq.zzc(new zzabf(zzabe, zzabr), taskCompletionSource), this.zzaAU.get(), zzc)));
        return taskCompletionSource.getTask();
    }

    public Task<Void> zza(Iterable<zzc<?>> iterable) {
        zzzu zzzu = new zzzu(iterable);
        for (zzc apiKey : iterable) {
            zza zza = (zza) this.zzazt.get(apiKey.getApiKey());
            if (zza != null) {
                if (!zza.isConnected()) {
                }
            }
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, zzzu));
            return zzzu.getTask();
        }
        zzzu.zzuZ();
        return zzzu.getTask();
    }

    public void zza(ConnectionResult connectionResult, int i) {
        if (!zzc(connectionResult, i)) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(4, i, 0, connectionResult));
        }
    }

    public void zza(zzc<?> zzc) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(5, zzc));
    }

    public <O extends ApiOptions, TResult> void zza(zzc<O> zzc, int i, zzabn<com.google.android.gms.common.api.Api.zzb, TResult> zzabn, TaskCompletionSource<TResult> taskCompletionSource, zzabk zzabk) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, new zzabd(new zzd(i, zzabn, taskCompletionSource, zzabk), this.zzaAU.get(), zzc)));
    }

    public <O extends ApiOptions> void zza(zzc<O> zzc, int i, com.google.android.gms.internal.zzzv.zza<? extends Result, com.google.android.gms.common.api.Api.zzb> zza) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3, new zzabd(new com.google.android.gms.internal.zzzq.zzb(i, zza), this.zzaAU.get(), zzc)));
    }

    public void zza(@NonNull zzaae zzaae) {
        synchronized (zztU) {
            if (this.zzaAV != zzaae) {
                this.zzaAV = zzaae;
                this.zzaAW.clear();
                this.zzaAW.addAll(zzaae.zzvx());
            }
        }
    }

    void zzb(@NonNull zzaae zzaae) {
        synchronized (zztU) {
            if (this.zzaAV == zzaae) {
                this.zzaAV = null;
                this.zzaAW.clear();
            }
        }
    }

    boolean zzc(ConnectionResult connectionResult, int i) {
        if (!connectionResult.hasResolution() && !this.zzaxX.isUserResolvableError(connectionResult.getErrorCode())) {
            return false;
        }
        this.zzaxX.zza(this.mContext, connectionResult, i);
        return true;
    }

    public void zzuW() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(2));
    }

    public int zzvU() {
        return this.zzaAT.getAndIncrement();
    }
}
