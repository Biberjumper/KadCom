package com.google.android.gms.internal;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.UUID;

public final class zzbtg {
    public static final zzbsd<Class> zzcoA = new zzbsd<Class>() {
        public void zza(zzbtk zzbtk, Class cls) throws IOException {
            if (cls == null) {
                zzbtk.zzaca();
            } else {
                String valueOf = String.valueOf(cls.getName());
                throw new UnsupportedOperationException(new StringBuilder(String.valueOf(valueOf).length() + 76).append("Attempted to serialize java.lang.Class: ").append(valueOf).append(". Forgot to register a type adapter?").toString());
            }
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzo(zzbti);
        }

        public Class zzo(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
        }
    };
    public static final zzbse zzcoB = zza(Class.class, zzcoA);
    public static final zzbsd<BitSet> zzcoC = new zzbsd<BitSet>() {
        public void zza(zzbtk zzbtk, BitSet bitSet) throws IOException {
            if (bitSet == null) {
                zzbtk.zzaca();
                return;
            }
            zzbtk.zzabW();
            for (int i = 0; i < bitSet.length(); i++) {
                zzbtk.zzaU((long) (bitSet.get(i) ? 1 : 0));
            }
            zzbtk.zzabX();
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzx(zzbti);
        }

        public BitSet zzx(zzbti zzbti) throws IOException {
            String valueOf;
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            BitSet bitSet = new BitSet();
            zzbti.beginArray();
            zzbtj zzabQ = zzbti.zzabQ();
            int i = 0;
            while (zzabQ != zzbtj.END_ARRAY) {
                boolean z;
                switch (zzabQ) {
                    case NUMBER:
                        if (zzbti.nextInt() == 0) {
                            z = false;
                            break;
                        }
                        z = true;
                        break;
                    case BOOLEAN:
                        z = zzbti.nextBoolean();
                        break;
                    case STRING:
                        Object nextString = zzbti.nextString();
                        try {
                            if (Integer.parseInt(nextString) == 0) {
                                z = false;
                                break;
                            }
                            z = true;
                            break;
                        } catch (NumberFormatException e) {
                            String str = "Error: Expecting: bitset number value (1, 0), Found: ";
                            valueOf = String.valueOf(nextString);
                            throw new zzbsa(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                        }
                    default:
                        valueOf = String.valueOf(zzabQ);
                        throw new zzbsa(new StringBuilder(String.valueOf(valueOf).length() + 27).append("Invalid bitset value type: ").append(valueOf).toString());
                }
                if (z) {
                    bitSet.set(i);
                }
                i++;
                zzabQ = zzbti.zzabQ();
            }
            zzbti.endArray();
            return bitSet;
        }
    };
    public static final zzbse zzcoD = zza(BitSet.class, zzcoC);
    public static final zzbsd<Boolean> zzcoE = new zzbsd<Boolean>() {
        public Boolean zzE(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return zzbti.zzabQ() == zzbtj.STRING ? Boolean.valueOf(Boolean.parseBoolean(zzbti.nextString())) : Boolean.valueOf(zzbti.nextBoolean());
            } else {
                zzbti.nextNull();
                return null;
            }
        }

        public void zza(zzbtk zzbtk, Boolean bool) throws IOException {
            if (bool == null) {
                zzbtk.zzaca();
            } else {
                zzbtk.zzbg(bool.booleanValue());
            }
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzE(zzbti);
        }
    };
    public static final zzbsd<Boolean> zzcoF = new zzbsd<Boolean>() {
        public Boolean zzE(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return Boolean.valueOf(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }

        public void zza(zzbtk zzbtk, Boolean bool) throws IOException {
            zzbtk.zzjX(bool == null ? "null" : bool.toString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzE(zzbti);
        }
    };
    public static final zzbse zzcoG = zza(Boolean.TYPE, Boolean.class, zzcoE);
    public static final zzbsd<Number> zzcoH = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return Byte.valueOf((byte) zzbti.nextInt());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbse zzcoI = zza(Byte.TYPE, Byte.class, zzcoH);
    public static final zzbsd<Number> zzcoJ = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return Short.valueOf((short) zzbti.nextInt());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbse zzcoK = zza(Short.TYPE, Short.class, zzcoJ);
    public static final zzbsd<Number> zzcoL = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return Integer.valueOf(zzbti.nextInt());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbse zzcoM = zza(Integer.TYPE, Integer.class, zzcoL);
    public static final zzbsd<Number> zzcoN = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return Long.valueOf(zzbti.nextLong());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbsd<Number> zzcoO = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return Float.valueOf((float) zzbti.nextDouble());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbsd<Number> zzcoP = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return Double.valueOf(zzbti.nextDouble());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbsd<Number> zzcoQ = new zzbsd<Number>() {
        public void zza(zzbtk zzbtk, Number number) throws IOException {
            zzbtk.zza(number);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzg(zzbti);
        }

        public Number zzg(zzbti zzbti) throws IOException {
            zzbtj zzabQ = zzbti.zzabQ();
            switch (zzabQ) {
                case NUMBER:
                    return new zzbso(zzbti.nextString());
                case NULL:
                    zzbti.nextNull();
                    return null;
                default:
                    String valueOf = String.valueOf(zzabQ);
                    throw new zzbsa(new StringBuilder(String.valueOf(valueOf).length() + 23).append("Expecting number, got: ").append(valueOf).toString());
            }
        }
    };
    public static final zzbse zzcoR = zza(Number.class, zzcoQ);
    public static final zzbsd<Character> zzcoS = new zzbsd<Character>() {
        public void zza(zzbtk zzbtk, Character ch) throws IOException {
            zzbtk.zzjX(ch == null ? null : String.valueOf(ch));
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzp(zzbti);
        }

        public Character zzp(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            String nextString = zzbti.nextString();
            if (nextString.length() == 1) {
                return Character.valueOf(nextString.charAt(0));
            }
            String str = "Expecting character, got: ";
            nextString = String.valueOf(nextString);
            throw new zzbsa(nextString.length() != 0 ? str.concat(nextString) : new String(str));
        }
    };
    public static final zzbse zzcoT = zza(Character.TYPE, Character.class, zzcoS);
    public static final zzbsd<String> zzcoU = new zzbsd<String>() {
        public void zza(zzbtk zzbtk, String str) throws IOException {
            zzbtk.zzjX(str);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzq(zzbti);
        }

        public String zzq(zzbti zzbti) throws IOException {
            zzbtj zzabQ = zzbti.zzabQ();
            if (zzabQ != zzbtj.NULL) {
                return zzabQ == zzbtj.BOOLEAN ? Boolean.toString(zzbti.nextBoolean()) : zzbti.nextString();
            } else {
                zzbti.nextNull();
                return null;
            }
        }
    };
    public static final zzbsd<BigDecimal> zzcoV = new zzbsd<BigDecimal>() {
        public void zza(zzbtk zzbtk, BigDecimal bigDecimal) throws IOException {
            zzbtk.zza(bigDecimal);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzr(zzbti);
        }

        public BigDecimal zzr(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return new BigDecimal(zzbti.nextString());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbsd<BigInteger> zzcoW = new zzbsd<BigInteger>() {
        public void zza(zzbtk zzbtk, BigInteger bigInteger) throws IOException {
            zzbtk.zza(bigInteger);
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzs(zzbti);
        }

        public BigInteger zzs(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            try {
                return new BigInteger(zzbti.nextString());
            } catch (Throwable e) {
                throw new zzbsa(e);
            }
        }
    };
    public static final zzbse zzcoX = zza(String.class, zzcoU);
    public static final zzbsd<StringBuilder> zzcoY = new zzbsd<StringBuilder>() {
        public void zza(zzbtk zzbtk, StringBuilder stringBuilder) throws IOException {
            zzbtk.zzjX(stringBuilder == null ? null : stringBuilder.toString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzt(zzbti);
        }

        public StringBuilder zzt(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return new StringBuilder(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbse zzcoZ = zza(StringBuilder.class, zzcoY);
    public static final zzbsd<StringBuffer> zzcpa = new zzbsd<StringBuffer>() {
        public void zza(zzbtk zzbtk, StringBuffer stringBuffer) throws IOException {
            zzbtk.zzjX(stringBuffer == null ? null : stringBuffer.toString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzu(zzbti);
        }

        public StringBuffer zzu(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return new StringBuffer(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbse zzcpb = zza(StringBuffer.class, zzcpa);
    public static final zzbsd<URL> zzcpc = new zzbsd<URL>() {
        public void zza(zzbtk zzbtk, URL url) throws IOException {
            zzbtk.zzjX(url == null ? null : url.toExternalForm());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzv(zzbti);
        }

        public URL zzv(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            String nextString = zzbti.nextString();
            return !"null".equals(nextString) ? new URL(nextString) : null;
        }
    };
    public static final zzbse zzcpd = zza(URL.class, zzcpc);
    public static final zzbsd<URI> zzcpe = new zzbsd<URI>() {
        public void zza(zzbtk zzbtk, URI uri) throws IOException {
            zzbtk.zzjX(uri == null ? null : uri.toASCIIString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzw(zzbti);
        }

        public URI zzw(zzbti zzbti) throws IOException {
            URI uri = null;
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
            } else {
                try {
                    String nextString = zzbti.nextString();
                    if (!"null".equals(nextString)) {
                        uri = new URI(nextString);
                    }
                } catch (Throwable e) {
                    throw new zzbrs(e);
                }
            }
            return uri;
        }
    };
    public static final zzbse zzcpf = zza(URI.class, zzcpe);
    public static final zzbsd<InetAddress> zzcpg = new zzbsd<InetAddress>() {
        public void zza(zzbtk zzbtk, InetAddress inetAddress) throws IOException {
            zzbtk.zzjX(inetAddress == null ? null : inetAddress.getHostAddress());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzy(zzbti);
        }

        public InetAddress zzy(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return InetAddress.getByName(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbse zzcph = zzb(InetAddress.class, zzcpg);
    public static final zzbsd<UUID> zzcpi = new zzbsd<UUID>() {
        public void zza(zzbtk zzbtk, UUID uuid) throws IOException {
            zzbtk.zzjX(uuid == null ? null : uuid.toString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzz(zzbti);
        }

        public UUID zzz(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return UUID.fromString(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }
    };
    public static final zzbse zzcpj = zza(UUID.class, zzcpi);
    public static final zzbse zzcpk = new zzbse() {
        public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
            if (zzbth.zzacb() != Timestamp.class) {
                return null;
            }
            final zzbsd zzj = zzbrl.zzj(Date.class);
            return new zzbsd<Timestamp>(this) {
                final /* synthetic */ AnonymousClass15 zzcpt;

                public Timestamp zzA(zzbti zzbti) throws IOException {
                    Date date = (Date) zzj.zzb(zzbti);
                    return date != null ? new Timestamp(date.getTime()) : null;
                }

                public void zza(zzbtk zzbtk, Timestamp timestamp) throws IOException {
                    zzj.zza(zzbtk, timestamp);
                }

                public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
                    return zzA(zzbti);
                }
            };
        }
    };
    public static final zzbsd<Calendar> zzcpl = new zzbsd<Calendar>() {
        public Calendar zzB(zzbti zzbti) throws IOException {
            int i = 0;
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            zzbti.beginObject();
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            int i5 = 0;
            int i6 = 0;
            while (zzbti.zzabQ() != zzbtj.END_OBJECT) {
                String nextName = zzbti.nextName();
                int nextInt = zzbti.nextInt();
                if ("year".equals(nextName)) {
                    i6 = nextInt;
                } else if ("month".equals(nextName)) {
                    i5 = nextInt;
                } else if ("dayOfMonth".equals(nextName)) {
                    i4 = nextInt;
                } else if ("hourOfDay".equals(nextName)) {
                    i3 = nextInt;
                } else if ("minute".equals(nextName)) {
                    i2 = nextInt;
                } else if ("second".equals(nextName)) {
                    i = nextInt;
                }
            }
            zzbti.endObject();
            return new GregorianCalendar(i6, i5, i4, i3, i2, i);
        }

        public void zza(zzbtk zzbtk, Calendar calendar) throws IOException {
            if (calendar == null) {
                zzbtk.zzaca();
                return;
            }
            zzbtk.zzabY();
            zzbtk.zzjW("year");
            zzbtk.zzaU((long) calendar.get(1));
            zzbtk.zzjW("month");
            zzbtk.zzaU((long) calendar.get(2));
            zzbtk.zzjW("dayOfMonth");
            zzbtk.zzaU((long) calendar.get(5));
            zzbtk.zzjW("hourOfDay");
            zzbtk.zzaU((long) calendar.get(11));
            zzbtk.zzjW("minute");
            zzbtk.zzaU((long) calendar.get(12));
            zzbtk.zzjW("second");
            zzbtk.zzaU((long) calendar.get(13));
            zzbtk.zzabZ();
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzB(zzbti);
        }
    };
    public static final zzbse zzcpm = zzb(Calendar.class, GregorianCalendar.class, zzcpl);
    public static final zzbsd<Locale> zzcpn = new zzbsd<Locale>() {
        public Locale zzC(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            StringTokenizer stringTokenizer = new StringTokenizer(zzbti.nextString(), "_");
            String nextToken = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
            String nextToken2 = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
            String nextToken3 = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
            return (nextToken2 == null && nextToken3 == null) ? new Locale(nextToken) : nextToken3 == null ? new Locale(nextToken, nextToken2) : new Locale(nextToken, nextToken2, nextToken3);
        }

        public void zza(zzbtk zzbtk, Locale locale) throws IOException {
            zzbtk.zzjX(locale == null ? null : locale.toString());
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzC(zzbti);
        }
    };
    public static final zzbse zzcpo = zza(Locale.class, zzcpn);
    public static final zzbsd<zzbrr> zzcpp = new zzbsd<zzbrr>() {
        public zzbrr zzD(zzbti zzbti) throws IOException {
            zzbrr zzbro;
            switch (zzbti.zzabQ()) {
                case NUMBER:
                    return new zzbrx(new zzbso(zzbti.nextString()));
                case BOOLEAN:
                    return new zzbrx(Boolean.valueOf(zzbti.nextBoolean()));
                case STRING:
                    return new zzbrx(zzbti.nextString());
                case NULL:
                    zzbti.nextNull();
                    return zzbrt.zzcmL;
                case BEGIN_ARRAY:
                    zzbro = new zzbro();
                    zzbti.beginArray();
                    while (zzbti.hasNext()) {
                        zzbro.zzc((zzbrr) zzb(zzbti));
                    }
                    zzbti.endArray();
                    return zzbro;
                case BEGIN_OBJECT:
                    zzbro = new zzbru();
                    zzbti.beginObject();
                    while (zzbti.hasNext()) {
                        zzbro.zza(zzbti.nextName(), (zzbrr) zzb(zzbti));
                    }
                    zzbti.endObject();
                    return zzbro;
                default:
                    throw new IllegalArgumentException();
            }
        }

        public void zza(zzbtk zzbtk, zzbrr zzbrr) throws IOException {
            if (zzbrr == null || zzbrr.zzaby()) {
                zzbtk.zzaca();
            } else if (zzbrr.zzabx()) {
                zzbrx zzabB = zzbrr.zzabB();
                if (zzabB.zzabE()) {
                    zzbtk.zza(zzabB.zzabt());
                } else if (zzabB.zzabD()) {
                    zzbtk.zzbg(zzabB.getAsBoolean());
                } else {
                    zzbtk.zzjX(zzabB.zzabu());
                }
            } else if (zzbrr.zzabv()) {
                zzbtk.zzabW();
                Iterator it = zzbrr.zzabA().iterator();
                while (it.hasNext()) {
                    zza(zzbtk, (zzbrr) it.next());
                }
                zzbtk.zzabX();
            } else if (zzbrr.zzabw()) {
                zzbtk.zzabY();
                for (Entry entry : zzbrr.zzabz().entrySet()) {
                    zzbtk.zzjW((String) entry.getKey());
                    zza(zzbtk, (zzbrr) entry.getValue());
                }
                zzbtk.zzabZ();
            } else {
                String valueOf = String.valueOf(zzbrr.getClass());
                throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 15).append("Couldn't write ").append(valueOf).toString());
            }
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzD(zzbti);
        }
    };
    public static final zzbse zzcpq = zzb(zzbrr.class, zzcpp);
    public static final zzbse zzcpr = new zzbse() {
        public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
            Class zzacb = zzbth.zzacb();
            if (!Enum.class.isAssignableFrom(zzacb) || zzacb == Enum.class) {
                return null;
            }
            if (!zzacb.isEnum()) {
                zzacb = zzacb.getSuperclass();
            }
            return new zza(zzacb);
        }
    };

    private static final class zza<T extends Enum<T>> extends zzbsd<T> {
        private final Map<String, T> zzcpB = new HashMap();
        private final Map<T, String> zzcpC = new HashMap();

        public zza(Class<T> cls) {
            try {
                for (Enum enumR : (Enum[]) cls.getEnumConstants()) {
                    String name = enumR.name();
                    zzbsg zzbsg = (zzbsg) cls.getField(name).getAnnotation(zzbsg.class);
                    if (zzbsg != null) {
                        name = zzbsg.value();
                        for (Object put : zzbsg.zzabH()) {
                            this.zzcpB.put(put, enumR);
                        }
                    }
                    String str = name;
                    this.zzcpB.put(str, enumR);
                    this.zzcpC.put(enumR, str);
                }
            } catch (NoSuchFieldException e) {
                throw new AssertionError();
            }
        }

        public T zzF(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() != zzbtj.NULL) {
                return (Enum) this.zzcpB.get(zzbti.nextString());
            }
            zzbti.nextNull();
            return null;
        }

        public void zza(zzbtk zzbtk, T t) throws IOException {
            zzbtk.zzjX(t == null ? null : (String) this.zzcpC.get(t));
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzF(zzbti);
        }
    }

    public static <TT> zzbse zza(final zzbth<TT> zzbth, final zzbsd<TT> zzbsd) {
        return new zzbse() {
            public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
                return zzbth.equals(zzbth) ? zzbsd : null;
            }
        };
    }

    public static <TT> zzbse zza(final Class<TT> cls, final zzbsd<TT> zzbsd) {
        return new zzbse() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(zzbsd);
                return new StringBuilder((String.valueOf(valueOf).length() + 23) + String.valueOf(valueOf2).length()).append("Factory[type=").append(valueOf).append(",adapter=").append(valueOf2).append("]").toString();
            }

            public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
                return zzbth.zzacb() == cls ? zzbsd : null;
            }
        };
    }

    public static <TT> zzbse zza(final Class<TT> cls, final Class<TT> cls2, final zzbsd<? super TT> zzbsd) {
        return new zzbse() {
            public String toString() {
                String valueOf = String.valueOf(cls2.getName());
                String valueOf2 = String.valueOf(cls.getName());
                String valueOf3 = String.valueOf(zzbsd);
                return new StringBuilder(((String.valueOf(valueOf).length() + 24) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("Factory[type=").append(valueOf).append("+").append(valueOf2).append(",adapter=").append(valueOf3).append("]").toString();
            }

            public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
                Class zzacb = zzbth.zzacb();
                return (zzacb == cls || zzacb == cls2) ? zzbsd : null;
            }
        };
    }

    public static <TT> zzbse zzb(final Class<TT> cls, final zzbsd<TT> zzbsd) {
        return new zzbse() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(zzbsd);
                return new StringBuilder((String.valueOf(valueOf).length() + 32) + String.valueOf(valueOf2).length()).append("Factory[typeHierarchy=").append(valueOf).append(",adapter=").append(valueOf2).append("]").toString();
            }

            public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
                return cls.isAssignableFrom(zzbth.zzacb()) ? zzbsd : null;
            }
        };
    }

    public static <TT> zzbse zzb(final Class<TT> cls, final Class<? extends TT> cls2, final zzbsd<? super TT> zzbsd) {
        return new zzbse() {
            public String toString() {
                String valueOf = String.valueOf(cls.getName());
                String valueOf2 = String.valueOf(cls2.getName());
                String valueOf3 = String.valueOf(zzbsd);
                return new StringBuilder(((String.valueOf(valueOf).length() + 24) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("Factory[type=").append(valueOf).append("+").append(valueOf2).append(",adapter=").append(valueOf3).append("]").toString();
            }

            public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
                Class zzacb = zzbth.zzacb();
                return (zzacb == cls || zzacb == cls2) ? zzbsd : null;
            }
        };
    }
}
