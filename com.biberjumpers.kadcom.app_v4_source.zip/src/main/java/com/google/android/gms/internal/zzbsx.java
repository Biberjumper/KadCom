package com.google.android.gms.internal;

public final class zzbsx implements zzbse {
    private final zzbsl zzcmu;

    public zzbsx(zzbsl zzbsl) {
        this.zzcmu = zzbsl;
    }

    static zzbsd<?> zza(zzbsl zzbsl, zzbrl zzbrl, zzbth<?> zzbth, zzbsf zzbsf) {
        Class value = zzbsf.value();
        if (zzbsd.class.isAssignableFrom(value)) {
            return (zzbsd) zzbsl.zzb(zzbth.zzq(value)).zzabJ();
        }
        if (zzbse.class.isAssignableFrom(value)) {
            return ((zzbse) zzbsl.zzb(zzbth.zzq(value)).zzabJ()).zza(zzbrl, zzbth);
        }
        throw new IllegalArgumentException("@JsonAdapter value must be TypeAdapter or TypeAdapterFactory reference.");
    }

    public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
        zzbsf zzbsf = (zzbsf) zzbth.zzacb().getAnnotation(zzbsf.class);
        return zzbsf == null ? null : zza(this.zzcmu, zzbrl, zzbth, zzbsf);
    }
}
