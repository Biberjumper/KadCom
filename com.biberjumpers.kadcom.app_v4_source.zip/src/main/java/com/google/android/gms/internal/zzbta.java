package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class zzbta implements zzbse {
    private final zzbsl zzcmu;
    private final boolean zzcoj;

    private final class zza<K, V> extends zzbsd<Map<K, V>> {
        private final zzbsq<? extends Map<K, V>> zzcob;
        private final zzbsd<K> zzcok;
        private final zzbsd<V> zzcol;
        final /* synthetic */ zzbta zzcom;

        public zza(zzbta zzbta, zzbrl zzbrl, Type type, zzbsd<K> zzbsd, Type type2, zzbsd<V> zzbsd2, zzbsq<? extends Map<K, V>> zzbsq) {
            this.zzcom = zzbta;
            this.zzcok = new zzbtf(zzbrl, zzbsd, type);
            this.zzcol = new zzbtf(zzbrl, zzbsd2, type2);
            this.zzcob = zzbsq;
        }

        private String zze(zzbrr zzbrr) {
            if (zzbrr.zzabx()) {
                zzbrx zzabB = zzbrr.zzabB();
                if (zzabB.zzabE()) {
                    return String.valueOf(zzabB.zzabt());
                }
                if (zzabB.zzabD()) {
                    return Boolean.toString(zzabB.getAsBoolean());
                }
                if (zzabB.zzabF()) {
                    return zzabB.zzabu();
                }
                throw new AssertionError();
            } else if (zzbrr.zzaby()) {
                return "null";
            } else {
                throw new AssertionError();
            }
        }

        public void zza(zzbtk zzbtk, Map<K, V> map) throws IOException {
            int i = 0;
            if (map == null) {
                zzbtk.zzaca();
            } else if (this.zzcom.zzcoj) {
                List arrayList = new ArrayList(map.size());
                List arrayList2 = new ArrayList(map.size());
                int i2 = 0;
                for (Entry entry : map.entrySet()) {
                    zzbrr zzaL = this.zzcok.zzaL(entry.getKey());
                    arrayList.add(zzaL);
                    arrayList2.add(entry.getValue());
                    int i3 = (zzaL.zzabv() || zzaL.zzabw()) ? 1 : 0;
                    i2 = i3 | i2;
                }
                if (i2 != 0) {
                    zzbtk.zzabW();
                    while (i < arrayList.size()) {
                        zzbtk.zzabW();
                        zzbss.zzb((zzbrr) arrayList.get(i), zzbtk);
                        this.zzcol.zza(zzbtk, arrayList2.get(i));
                        zzbtk.zzabX();
                        i++;
                    }
                    zzbtk.zzabX();
                    return;
                }
                zzbtk.zzabY();
                while (i < arrayList.size()) {
                    zzbtk.zzjW(zze((zzbrr) arrayList.get(i)));
                    this.zzcol.zza(zzbtk, arrayList2.get(i));
                    i++;
                }
                zzbtk.zzabZ();
            } else {
                zzbtk.zzabY();
                for (Entry entry2 : map.entrySet()) {
                    zzbtk.zzjW(String.valueOf(entry2.getKey()));
                    this.zzcol.zza(zzbtk, entry2.getValue());
                }
                zzbtk.zzabZ();
            }
        }

        public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
            return zzl(zzbti);
        }

        public Map<K, V> zzl(zzbti zzbti) throws IOException {
            zzbtj zzabQ = zzbti.zzabQ();
            if (zzabQ == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            Map<K, V> map = (Map) this.zzcob.zzabJ();
            Object zzb;
            if (zzabQ == zzbtj.BEGIN_ARRAY) {
                zzbti.beginArray();
                while (zzbti.hasNext()) {
                    zzbti.beginArray();
                    zzb = this.zzcok.zzb(zzbti);
                    if (map.put(zzb, this.zzcol.zzb(zzbti)) != null) {
                        String valueOf = String.valueOf(zzb);
                        throw new zzbsa(new StringBuilder(String.valueOf(valueOf).length() + 15).append("duplicate key: ").append(valueOf).toString());
                    }
                    zzbti.endArray();
                }
                zzbti.endArray();
                return map;
            }
            zzbti.beginObject();
            while (zzbti.hasNext()) {
                zzbsn.zzcny.zzi(zzbti);
                zzb = this.zzcok.zzb(zzbti);
                if (map.put(zzb, this.zzcol.zzb(zzbti)) != null) {
                    valueOf = String.valueOf(zzb);
                    throw new zzbsa(new StringBuilder(String.valueOf(valueOf).length() + 15).append("duplicate key: ").append(valueOf).toString());
                }
            }
            zzbti.endObject();
            return map;
        }
    }

    public zzbta(zzbsl zzbsl, boolean z) {
        this.zzcmu = zzbsl;
        this.zzcoj = z;
    }

    private zzbsd<?> zza(zzbrl zzbrl, Type type) {
        return (type == Boolean.TYPE || type == Boolean.class) ? zzbtg.zzcoF : zzbrl.zza(zzbth.zzl(type));
    }

    public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
        Type zzacc = zzbth.zzacc();
        if (!Map.class.isAssignableFrom(zzbth.zzacb())) {
            return null;
        }
        Type[] zzb = zzbsk.zzb(zzacc, zzbsk.zzf(zzacc));
        zzbsd zza = zza(zzbrl, zzb[0]);
        zzbsd zza2 = zzbrl.zza(zzbth.zzl(zzb[1]));
        zzbsq zzb2 = this.zzcmu.zzb(zzbth);
        return new zza(this, zzbrl, zzb[0], zza, zzb[1], zza2, zzb2);
    }
}
