package com.google.android.gms.internal;

public interface zzn {
    void zza(zzk<?> zzk, zzm<?> zzm);

    void zza(zzk<?> zzk, zzm<?> zzm, Runnable runnable);

    void zza(zzk<?> zzk, zzr zzr);
}
