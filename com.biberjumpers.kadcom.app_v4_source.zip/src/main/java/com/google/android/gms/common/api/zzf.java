package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

public abstract class zzf {
    private static final Map<Object, zzf> zzayf = new WeakHashMap();
    private static final Object zztU = new Object();

    public abstract void remove(int i);
}
