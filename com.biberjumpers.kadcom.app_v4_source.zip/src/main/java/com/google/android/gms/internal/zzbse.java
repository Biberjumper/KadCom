package com.google.android.gms.internal;

public interface zzbse {
    <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth);
}
