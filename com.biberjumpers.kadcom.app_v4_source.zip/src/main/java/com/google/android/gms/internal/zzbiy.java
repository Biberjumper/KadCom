package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.internal.zzac;
import java.io.IOException;
import java.util.List;

public class zzbiy extends zzbsd<zzbjn> {
    private zzbrl zzbVW;

    public zzbjn zza(zzbti zzbti) throws IOException {
        if (zzbti.zzabQ() == zzbtj.NULL) {
            zzbti.nextNull();
            return null;
        }
        zzbjn zzbjn = new zzbjn();
        zzbsd zzj = this.zzbVW.zzj(zzbjl.class);
        zzbti.beginArray();
        while (zzbti.hasNext()) {
            zzbjn.zzUr().add((zzbjl) zzj.zzb(zzbti));
        }
        zzbti.endArray();
        return zzbjn;
    }

    public void zza(@NonNull zzbrl zzbrl) {
        this.zzbVW = (zzbrl) zzac.zzw(zzbrl);
    }

    public void zza(zzbtk zzbtk, zzbjn zzbjn) throws IOException {
        int i = 0;
        if (zzbjn == null) {
            zzbtk.zzaca();
            return;
        }
        zzbsd zzj = this.zzbVW.zzj(zzbjl.class);
        zzbtk.zzabW();
        List zzUr = zzbjn.zzUr();
        int size = zzUr != null ? zzUr.size() : 0;
        while (i < size) {
            zzj.zza(zzbtk, (zzbjl) zzUr.get(i));
            i++;
        }
        zzbtk.zzabX();
    }

    public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
        return zza(zzbti);
    }
}
