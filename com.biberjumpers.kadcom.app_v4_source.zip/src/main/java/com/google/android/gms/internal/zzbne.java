package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbng.zza;

public class zzbne extends zzbng {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbne.class.desiredAssertionStatus());

    public zzbne(zzbnh zzbnh, zzbmj zzbmj) {
        super(zza.ListenComplete, zzbnh, zzbmj);
        if (!$assertionsDisabled && zzbnh.zzXQ()) {
            throw new AssertionError("Can't have a listen complete from a user source");
        }
    }

    public String toString() {
        return String.format("ListenComplete { path=%s, source=%s }", new Object[]{zzVc(), zzXO()});
    }

    public zzbng zzc(zzbos zzbos) {
        return this.zzbXY.isEmpty() ? new zzbne(this.zzceD, zzbmj.zzXf()) : new zzbne(this.zzceD, this.zzbXY.zzXj());
    }
}
