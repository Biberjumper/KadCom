package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.internal.zzbly.zzb;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApiNotAvailableException;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseApp.zza;
import com.google.firebase.auth.GetTokenResult;
import java.util.concurrent.ScheduledExecutorService;

public class zzbkv implements zzbly {
    private final ScheduledExecutorService zzbYl;
    private final FirebaseApp zzbYm;

    public zzbkv(@NonNull FirebaseApp firebaseApp, @NonNull ScheduledExecutorService scheduledExecutorService) {
        this.zzbYm = firebaseApp;
        this.zzbYl = scheduledExecutorService;
    }

    private zza zzb(final zzb zzb) {
        return new zza(this) {
            final /* synthetic */ zzbkv zzbYp;

            public void zzb(@NonNull final zzbqm zzbqm) {
                this.zzbYp.zzbYl.execute(new Runnable(this) {
                    final /* synthetic */ AnonymousClass3 zzbYq;

                    public void run() {
                        zzb.zziV(zzbqm.getToken());
                    }
                });
            }
        };
    }

    public void zza(zzb zzb) {
        this.zzbYm.zza(zzb(zzb));
    }

    public void zza(boolean z, @NonNull final zzbly.zza zza) {
        this.zzbYm.getToken(z).addOnSuccessListener(this.zzbYl, new OnSuccessListener<GetTokenResult>(this) {
            public /* synthetic */ void onSuccess(Object obj) {
                zza((GetTokenResult) obj);
            }

            public void zza(GetTokenResult getTokenResult) {
                zza.zziM(getTokenResult.getToken());
            }
        }).addOnFailureListener(this.zzbYl, new OnFailureListener(this) {
            private boolean zza(Exception exception) {
                return (exception instanceof FirebaseApiNotAvailableException) || (exception instanceof zzbqn);
            }

            public void onFailure(@NonNull Exception exception) {
                if (zza(exception)) {
                    zza.zziM(null);
                } else {
                    zza.onError(exception.getMessage());
                }
            }
        });
    }
}
