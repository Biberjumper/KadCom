package com.google.android.gms.internal;

public final class zzbrt extends zzbrr {
    public static final zzbrt zzcmL = new zzbrt();

    public boolean equals(Object obj) {
        return this == obj || (obj instanceof zzbrt);
    }

    public int hashCode() {
        return zzbrt.class.hashCode();
    }
}
