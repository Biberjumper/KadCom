package com.google.android.gms.internal;

public interface zzboa {

    public enum zza {
        CHILD_REMOVED,
        CHILD_ADDED,
        CHILD_MOVED,
        CHILD_CHANGED,
        VALUE
    }

    String toString();

    void zzYj();
}
