package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbrz<T> {
    zzbrr zza(T t, Type type, zzbry zzbry);
}
