package com.google.android.gms.internal;

public class zzbps {
    private byte[] zzcif;
    private String zzcig;
    private byte zzcih = (byte) 1;

    public zzbps(String str) {
        this.zzcig = str;
    }

    public zzbps(byte[] bArr) {
        this.zzcif = bArr;
    }

    public String getText() {
        return this.zzcig;
    }
}
