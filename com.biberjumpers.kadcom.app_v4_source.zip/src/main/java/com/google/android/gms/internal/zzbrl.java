package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzbrl {
    final zzbry zzcmA;
    private final ThreadLocal<Map<zzbth<?>, zza<?>>> zzcmr;
    private final Map<zzbth<?>, zzbsd<?>> zzcms;
    private final List<zzbse> zzcmt;
    private final zzbsl zzcmu;
    private final boolean zzcmv;
    private final boolean zzcmw;
    private final boolean zzcmx;
    private final boolean zzcmy;
    final zzbrp zzcmz;

    static class zza<T> extends zzbsd<T> {
        private zzbsd<T> zzcmC;

        zza() {
        }

        public void zza(zzbsd<T> zzbsd) {
            if (this.zzcmC != null) {
                throw new AssertionError();
            }
            this.zzcmC = zzbsd;
        }

        public void zza(zzbtk zzbtk, T t) throws IOException {
            if (this.zzcmC == null) {
                throw new IllegalStateException();
            }
            this.zzcmC.zza(zzbtk, t);
        }

        public T zzb(zzbti zzbti) throws IOException {
            if (this.zzcmC != null) {
                return this.zzcmC.zzb(zzbti);
            }
            throw new IllegalStateException();
        }
    }

    public zzbrl() {
        this(zzbsm.zzcnn, zzbrj.IDENTITY, Collections.emptyMap(), false, false, false, true, false, false, zzbsb.DEFAULT, Collections.emptyList());
    }

    zzbrl(zzbsm zzbsm, zzbrk zzbrk, Map<Type, zzbrn<?>> map, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, zzbsb zzbsb, List<zzbse> list) {
        this.zzcmr = new ThreadLocal();
        this.zzcms = Collections.synchronizedMap(new HashMap());
        this.zzcmz = new zzbrp(this) {
            final /* synthetic */ zzbrl zzcmB;

            {
                this.zzcmB = r1;
            }
        };
        this.zzcmA = new zzbry(this) {
            final /* synthetic */ zzbrl zzcmB;

            {
                this.zzcmB = r1;
            }
        };
        this.zzcmu = new zzbsl(map);
        this.zzcmv = z;
        this.zzcmx = z3;
        this.zzcmw = z4;
        this.zzcmy = z5;
        List arrayList = new ArrayList();
        arrayList.add(zzbtg.zzcpq);
        arrayList.add(zzbtb.zzcnX);
        arrayList.add(zzbsm);
        arrayList.addAll(list);
        arrayList.add(zzbtg.zzcoX);
        arrayList.add(zzbtg.zzcoM);
        arrayList.add(zzbtg.zzcoG);
        arrayList.add(zzbtg.zzcoI);
        arrayList.add(zzbtg.zzcoK);
        arrayList.add(zzbtg.zza(Long.TYPE, Long.class, zza(zzbsb)));
        arrayList.add(zzbtg.zza(Double.TYPE, Double.class, zzbe(z6)));
        arrayList.add(zzbtg.zza(Float.TYPE, Float.class, zzbf(z6)));
        arrayList.add(zzbtg.zzcoR);
        arrayList.add(zzbtg.zzcoT);
        arrayList.add(zzbtg.zzcoZ);
        arrayList.add(zzbtg.zzcpb);
        arrayList.add(zzbtg.zza(BigDecimal.class, zzbtg.zzcoV));
        arrayList.add(zzbtg.zza(BigInteger.class, zzbtg.zzcoW));
        arrayList.add(zzbtg.zzcpd);
        arrayList.add(zzbtg.zzcpf);
        arrayList.add(zzbtg.zzcpj);
        arrayList.add(zzbtg.zzcpo);
        arrayList.add(zzbtg.zzcph);
        arrayList.add(zzbtg.zzcoD);
        arrayList.add(zzbsw.zzcnX);
        arrayList.add(zzbtg.zzcpm);
        arrayList.add(zzbte.zzcnX);
        arrayList.add(zzbtd.zzcnX);
        arrayList.add(zzbtg.zzcpk);
        arrayList.add(zzbsu.zzcnX);
        arrayList.add(zzbtg.zzcoB);
        arrayList.add(new zzbsv(this.zzcmu));
        arrayList.add(new zzbta(this.zzcmu, z2));
        arrayList.add(new zzbsx(this.zzcmu));
        arrayList.add(zzbtg.zzcpr);
        arrayList.add(new zzbtc(this.zzcmu, zzbrk, zzbsm));
        this.zzcmt = Collections.unmodifiableList(arrayList);
    }

    private zzbsd<Number> zza(zzbsb zzbsb) {
        return zzbsb == zzbsb.DEFAULT ? zzbtg.zzcoN : new zzbsd<Number>(this) {
            final /* synthetic */ zzbrl zzcmB;

            {
                this.zzcmB = r1;
            }

            public void zza(zzbtk zzbtk, Number number) throws IOException {
                if (number == null) {
                    zzbtk.zzaca();
                } else {
                    zzbtk.zzjX(number.toString());
                }
            }

            public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
                return zzg(zzbti);
            }

            public Number zzg(zzbti zzbti) throws IOException {
                if (zzbti.zzabQ() != zzbtj.NULL) {
                    return Long.valueOf(zzbti.nextLong());
                }
                zzbti.nextNull();
                return null;
            }
        };
    }

    private static void zza(Object obj, zzbti zzbti) {
        if (obj != null) {
            try {
                if (zzbti.zzabQ() != zzbtj.END_DOCUMENT) {
                    throw new zzbrs("JSON document was not fully consumed.");
                }
            } catch (Throwable e) {
                throw new zzbsa(e);
            } catch (Throwable e2) {
                throw new zzbrs(e2);
            }
        }
    }

    private zzbsd<Number> zzbe(boolean z) {
        return z ? zzbtg.zzcoP : new zzbsd<Number>(this) {
            final /* synthetic */ zzbrl zzcmB;

            {
                this.zzcmB = r1;
            }

            public void zza(zzbtk zzbtk, Number number) throws IOException {
                if (number == null) {
                    zzbtk.zzaca();
                    return;
                }
                this.zzcmB.zzm(number.doubleValue());
                zzbtk.zza(number);
            }

            public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
                return zze(zzbti);
            }

            public Double zze(zzbti zzbti) throws IOException {
                if (zzbti.zzabQ() != zzbtj.NULL) {
                    return Double.valueOf(zzbti.nextDouble());
                }
                zzbti.nextNull();
                return null;
            }
        };
    }

    private zzbsd<Number> zzbf(boolean z) {
        return z ? zzbtg.zzcoO : new zzbsd<Number>(this) {
            final /* synthetic */ zzbrl zzcmB;

            {
                this.zzcmB = r1;
            }

            public void zza(zzbtk zzbtk, Number number) throws IOException {
                if (number == null) {
                    zzbtk.zzaca();
                    return;
                }
                this.zzcmB.zzm((double) number.floatValue());
                zzbtk.zza(number);
            }

            public /* synthetic */ Object zzb(zzbti zzbti) throws IOException {
                return zzf(zzbti);
            }

            public Float zzf(zzbti zzbti) throws IOException {
                if (zzbti.zzabQ() != zzbtj.NULL) {
                    return Float.valueOf((float) zzbti.nextDouble());
                }
                zzbti.nextNull();
                return null;
            }
        };
    }

    private void zzm(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) {
            throw new IllegalArgumentException(d + " is not a valid double value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    public String toString() {
        return "{serializeNulls:" + this.zzcmv + "factories:" + this.zzcmt + ",instanceCreators:" + this.zzcmu + "}";
    }

    public <T> zzbsd<T> zza(zzbse zzbse, zzbth<T> zzbth) {
        Object obj = null;
        if (!this.zzcmt.contains(zzbse)) {
            obj = 1;
        }
        Object obj2 = obj;
        for (zzbse zzbse2 : this.zzcmt) {
            if (obj2 != null) {
                zzbsd<T> zza = zzbse2.zza(this, zzbth);
                if (zza != null) {
                    return zza;
                }
            } else if (zzbse2 == zzbse) {
                obj2 = 1;
            }
        }
        String valueOf = String.valueOf(zzbth);
        throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 22).append("GSON cannot serialize ").append(valueOf).toString());
    }

    public <T> zzbsd<T> zza(zzbth<T> zzbth) {
        Map map;
        zzbsd<T> zzbsd = (zzbsd) this.zzcms.get(zzbth);
        if (zzbsd == null) {
            Map map2 = (Map) this.zzcmr.get();
            Object obj = null;
            if (map2 == null) {
                HashMap hashMap = new HashMap();
                this.zzcmr.set(hashMap);
                map = hashMap;
                obj = 1;
            } else {
                map = map2;
            }
            zza zza = (zza) map.get(zzbth);
            if (zza == null) {
                try {
                    zza zza2 = new zza();
                    map.put(zzbth, zza2);
                    for (zzbse zza3 : this.zzcmt) {
                        zzbsd = zza3.zza(this, zzbth);
                        if (zzbsd != null) {
                            zza2.zza(zzbsd);
                            this.zzcms.put(zzbth, zzbsd);
                            map.remove(zzbth);
                            if (obj != null) {
                                this.zzcmr.remove();
                            }
                        }
                    }
                    String valueOf = String.valueOf(zzbth);
                    throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 19).append("GSON cannot handle ").append(valueOf).toString());
                } catch (Throwable th) {
                    map.remove(zzbth);
                    if (obj != null) {
                        this.zzcmr.remove();
                    }
                }
            }
        }
        return zzbsd;
    }

    public zzbtk zza(Writer writer) throws IOException {
        if (this.zzcmx) {
            writer.write(")]}'\n");
        }
        zzbtk zzbtk = new zzbtk(writer);
        if (this.zzcmy) {
            zzbtk.setIndent("  ");
        }
        zzbtk.zzbj(this.zzcmv);
        return zzbtk;
    }

    public <T> T zza(zzbrr zzbrr, Class<T> cls) throws zzbsa {
        return zzbsr.zzo(cls).cast(zza(zzbrr, (Type) cls));
    }

    public <T> T zza(zzbrr zzbrr, Type type) throws zzbsa {
        return zzbrr == null ? null : zza(new zzbsy(zzbrr), type);
    }

    public <T> T zza(zzbti zzbti, Type type) throws zzbrs, zzbsa {
        boolean z = true;
        boolean isLenient = zzbti.isLenient();
        zzbti.setLenient(true);
        try {
            zzbti.zzabQ();
            z = false;
            T zzb = zza(zzbth.zzl(type)).zzb(zzbti);
            zzbti.setLenient(isLenient);
            return zzb;
        } catch (Throwable e) {
            if (z) {
                zzbti.setLenient(isLenient);
                return null;
            }
            throw new zzbsa(e);
        } catch (Throwable e2) {
            throw new zzbsa(e2);
        } catch (Throwable e22) {
            throw new zzbsa(e22);
        } catch (Throwable th) {
            zzbti.setLenient(isLenient);
        }
    }

    public <T> T zza(Reader reader, Type type) throws zzbrs, zzbsa {
        zzbti zzbti = new zzbti(reader);
        Object zza = zza(zzbti, type);
        zza(zza, zzbti);
        return zza;
    }

    public <T> T zza(String str, Type type) throws zzbsa {
        return str == null ? null : zza(new StringReader(str), type);
    }

    public void zza(zzbrr zzbrr, zzbtk zzbtk) throws zzbrs {
        boolean isLenient = zzbtk.isLenient();
        zzbtk.setLenient(true);
        boolean zzacm = zzbtk.zzacm();
        zzbtk.zzbi(this.zzcmw);
        boolean zzacn = zzbtk.zzacn();
        zzbtk.zzbj(this.zzcmv);
        try {
            zzbss.zzb(zzbrr, zzbtk);
            zzbtk.setLenient(isLenient);
            zzbtk.zzbi(zzacm);
            zzbtk.zzbj(zzacn);
        } catch (Throwable e) {
            throw new zzbrs(e);
        } catch (Throwable th) {
            zzbtk.setLenient(isLenient);
            zzbtk.zzbi(zzacm);
            zzbtk.zzbj(zzacn);
        }
    }

    public void zza(zzbrr zzbrr, Appendable appendable) throws zzbrs {
        try {
            zza(zzbrr, zza(zzbss.zza(appendable)));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public void zza(Object obj, Type type, zzbtk zzbtk) throws zzbrs {
        zzbsd zza = zza(zzbth.zzl(type));
        boolean isLenient = zzbtk.isLenient();
        zzbtk.setLenient(true);
        boolean zzacm = zzbtk.zzacm();
        zzbtk.zzbi(this.zzcmw);
        boolean zzacn = zzbtk.zzacn();
        zzbtk.zzbj(this.zzcmv);
        try {
            zza.zza(zzbtk, obj);
            zzbtk.setLenient(isLenient);
            zzbtk.zzbi(zzacm);
            zzbtk.zzbj(zzacn);
        } catch (Throwable e) {
            throw new zzbrs(e);
        } catch (Throwable th) {
            zzbtk.setLenient(isLenient);
            zzbtk.zzbi(zzacm);
            zzbtk.zzbj(zzacn);
        }
    }

    public void zza(Object obj, Type type, Appendable appendable) throws zzbrs {
        try {
            zza(obj, type, zza(zzbss.zza(appendable)));
        } catch (Throwable e) {
            throw new zzbrs(e);
        }
    }

    public String zzaI(Object obj) {
        return obj == null ? zzb(zzbrt.zzcmL) : zzc(obj, obj.getClass());
    }

    public String zzb(zzbrr zzbrr) {
        Appendable stringWriter = new StringWriter();
        zza(zzbrr, stringWriter);
        return stringWriter.toString();
    }

    public String zzc(Object obj, Type type) {
        Appendable stringWriter = new StringWriter();
        zza(obj, type, stringWriter);
        return stringWriter.toString();
    }

    public <T> T zzf(String str, Class<T> cls) throws zzbsa {
        return zzbsr.zzo(cls).cast(zza(str, (Type) cls));
    }

    public <T> zzbsd<T> zzj(Class<T> cls) {
        return zza(zzbth.zzq(cls));
    }
}
