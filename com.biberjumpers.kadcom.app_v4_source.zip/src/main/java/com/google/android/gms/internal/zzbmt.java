package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseError;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;

public class zzbmt {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbmt.class.desiredAssertionStatus());
    private final zzbop zzbYx;
    private final zzbnn zzcdB;
    private zzbns<zzbms> zzcdC = zzbns.zzYd();
    private final zzbna zzcdD = new zzbna();
    private final Map<zzbmu, zzboe> zzcdE = new HashMap();
    private final Map<zzboe, zzbmu> zzcdF = new HashMap();
    private final Set<zzboe> zzcdG = new HashSet();
    private final zzd zzcdH;
    private long zzcdI = 1;

    public interface zza {
        List<? extends zzboa> zzb(DatabaseError databaseError);
    }

    public interface zzd {
        void zza(zzboe zzboe, zzbmu zzbmu);

        void zza(zzboe zzboe, zzbmu zzbmu, zzblq zzblq, zza zza);
    }

    private static class zzb extends zzbme {
        private zzboe zzcbz;

        public zzb(zzboe zzboe) {
            this.zzcbz = zzboe;
        }

        public boolean equals(Object obj) {
            return (obj instanceof zzb) && ((zzb) obj).zzcbz.equals(this.zzcbz);
        }

        public int hashCode() {
            return this.zzcbz.hashCode();
        }

        public zzboe zzWD() {
            return this.zzcbz;
        }

        public zzbme zza(zzboe zzboe) {
            return new zzb(zzboe);
        }

        public zzbnz zza(zzbny zzbny, zzboe zzboe) {
            return null;
        }

        public void zza(zzbnz zzbnz) {
        }

        public void zza(DatabaseError databaseError) {
        }

        public boolean zza(com.google.android.gms.internal.zzboa.zza zza) {
            return false;
        }

        public boolean zzc(zzbme zzbme) {
            return zzbme instanceof zzb;
        }
    }

    private class zzc implements zzblq, zza {
        final /* synthetic */ zzbmt zzcdN;
        private final zzbof zzcea;
        private final zzbmu zzceb;

        public zzc(zzbmt zzbmt, zzbof zzbof) {
            this.zzcdN = zzbmt;
            this.zzcea = zzbof;
            this.zzceb = zzbmt.zze(zzbof.zzYH());
        }

        public String zzVM() {
            return this.zzcea.zzYI().zzZc();
        }

        public boolean zzVN() {
            return zzbqb.zzt(this.zzcea.zzYI()) > 1024;
        }

        public zzblk zzVO() {
            zzbou zzi = zzbou.zzi(this.zzcea.zzYI());
            List<zzbmj> zzVF = zzi.zzVF();
            List arrayList = new ArrayList(zzVF.size());
            for (zzbmj zzXh : zzVF) {
                arrayList.add(zzXh.zzXh());
            }
            return new zzblk(arrayList, zzi.zzVG());
        }

        public List<? extends zzboa> zzb(DatabaseError databaseError) {
            if (databaseError == null) {
                return this.zzceb != null ? this.zzcdN.zza(this.zzceb) : this.zzcdN.zzt(this.zzcea.zzYH().zzVc());
            } else {
                zzbop zza = this.zzcdN.zzbYx;
                String valueOf = String.valueOf(this.zzcea.zzYH().zzVc());
                String valueOf2 = String.valueOf(databaseError.toString());
                zza.warn(new StringBuilder((String.valueOf(valueOf).length() + 19) + String.valueOf(valueOf2).length()).append("Listen at ").append(valueOf).append(" failed: ").append(valueOf2).toString());
                return this.zzcdN.zza(this.zzcea.zzYH(), databaseError);
            }
        }
    }

    public zzbmt(zzbmc zzbmc, zzbnn zzbnn, zzd zzd) {
        this.zzcdH = zzd;
        this.zzcdB = zzbnn;
        this.zzbYx = zzbmc.zziW("SyncTree");
    }

    private void zzX(List<zzboe> list) {
        for (zzboe zzboe : list) {
            if (!zzboe.zzYD()) {
                zzbmu zze = zze(zzboe);
                if ($assertionsDisabled || zze != null) {
                    this.zzcdF.remove(zzboe);
                    this.zzcdE.remove(zze);
                } else {
                    throw new AssertionError();
                }
            }
        }
    }

    private zzbmu zzXA() {
        long j = this.zzcdI;
        this.zzcdI = 1 + j;
        return new zzbmu(j);
    }

    private List<zzboa> zza(zzbng zzbng) {
        return zza(zzbng, this.zzcdC, null, this.zzcdD.zzu(zzbmj.zzXf()));
    }

    private List<zzboa> zza(zzbng zzbng, zzbns<zzbms> zzbns, zzbpe zzbpe, zzbnb zzbnb) {
        if (zzbng.zzVc().isEmpty()) {
            return zzb(zzbng, zzbns, zzbpe, zzbnb);
        }
        zzbms zzbms = (zzbms) zzbns.getValue();
        if (zzbpe == null && zzbms != null) {
            zzbpe = zzbms.zzs(zzbmj.zzXf());
        }
        List<zzboa> arrayList = new ArrayList();
        zzbos zzXi = zzbng.zzVc().zzXi();
        zzbng zzc = zzbng.zzc(zzXi);
        zzbns zzbns2 = (zzbns) zzbns.zzYe().get(zzXi);
        if (!(zzbns2 == null || zzc == null)) {
            arrayList.addAll(zza(zzc, zzbns2, zzbpe != null ? zzbpe.zzm(zzXi) : null, zzbnb.zzb(zzXi)));
        }
        if (zzbms != null) {
            arrayList.addAll(zzbms.zza(zzbng, zzbnb, zzbpe));
        }
        return arrayList;
    }

    private List<zzbof> zza(zzbns<zzbms> zzbns) {
        List arrayList = new ArrayList();
        zza((zzbns) zzbns, arrayList);
        return arrayList;
    }

    private List<? extends zzboa> zza(zzboe zzboe, zzbng zzbng) {
        zzbmj zzVc = zzboe.zzVc();
        zzbms zzbms = (zzbms) this.zzcdC.zzK(zzVc);
        if ($assertionsDisabled || zzbms != null) {
            return zzbms.zza(zzbng, this.zzcdD.zzu(zzVc), null);
        }
        throw new AssertionError("Missing sync point for query tag that we're tracking");
    }

    private void zza(zzbns<zzbms> zzbns, List<zzbof> list) {
        zzbms zzbms = (zzbms) zzbns.getValue();
        if (zzbms == null || !zzbms.zzXx()) {
            if (zzbms != null) {
                list.addAll(zzbms.zzXw());
            }
            Iterator it = zzbns.zzYe().iterator();
            while (it.hasNext()) {
                zza((zzbns) ((Entry) it.next()).getValue(), (List) list);
            }
            return;
        }
        list.add(zzbms.zzXy());
    }

    private void zza(zzboe zzboe, zzbof zzbof) {
        zzbmj zzVc = zzboe.zzVc();
        zzbmu zze = zze(zzboe);
        Object zzc = new zzc(this, zzbof);
        this.zzcdH.zza(zzd(zzboe), zze, zzc, zzc);
        zzbns zzI = this.zzcdC.zzI(zzVc);
        if (zze == null) {
            zzI.zza(new com.google.android.gms.internal.zzbns.zza<zzbms, Void>(this) {
                final /* synthetic */ zzbmt zzcdN;

                {
                    this.zzcdN = r1;
                }

                public Void zza(zzbmj zzbmj, zzbms zzbms, Void voidR) {
                    zzboe zzYH;
                    if (zzbmj.isEmpty() || !zzbms.zzXx()) {
                        for (zzbof zzYH2 : zzbms.zzXw()) {
                            zzYH = zzYH2.zzYH();
                            this.zzcdN.zzcdH.zza(this.zzcdN.zzd(zzYH), this.zzcdN.zze(zzYH));
                        }
                    } else {
                        zzYH = zzbms.zzXy().zzYH();
                        this.zzcdN.zzcdH.zza(this.zzcdN.zzd(zzYH), this.zzcdN.zze(zzYH));
                    }
                    return null;
                }
            });
        } else if (!$assertionsDisabled && ((zzbms) zzI.getValue()).zzXx()) {
            throw new AssertionError("If we're adding a query, it shouldn't be shadowed");
        }
    }

    private zzboe zzb(zzbmu zzbmu) {
        return (zzboe) this.zzcdE.get(zzbmu);
    }

    private List<zzboa> zzb(zzbng zzbng, zzbns<zzbms> zzbns, zzbpe zzbpe, zzbnb zzbnb) {
        zzbms zzbms = (zzbms) zzbns.getValue();
        final zzbpe zzs = (zzbpe != null || zzbms == null) ? zzbpe : zzbms.zzs(zzbmj.zzXf());
        final List<zzboa> arrayList = new ArrayList();
        final zzbnb zzbnb2 = zzbnb;
        final zzbng zzbng2 = zzbng;
        zzbns.zzYe().zza(new com.google.android.gms.internal.zzblf.zzb<zzbos, zzbns<zzbms>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public void zza(zzbos zzbos, zzbns<zzbms> zzbns) {
                zzbpe zzbpe = null;
                if (zzs != null) {
                    zzbpe = zzs.zzm(zzbos);
                }
                zzbnb zzb = zzbnb2.zzb(zzbos);
                zzbng zzc = zzbng2.zzc(zzbos);
                if (zzc != null) {
                    arrayList.addAll(this.zzcdN.zzb(zzc, zzbns, zzbpe, zzb));
                }
            }

            public /* synthetic */ void zzk(Object obj, Object obj2) {
                zza((zzbos) obj, (zzbns) obj2);
            }
        });
        if (zzbms != null) {
            arrayList.addAll(zzbms.zza(zzbng, zzbnb, zzs));
        }
        return arrayList;
    }

    private List<zzboa> zzb(final zzboe zzboe, final zzbme zzbme, final DatabaseError databaseError) {
        return (List) this.zzcdB.zzf(new Callable<List<zzboa>>(this) {
            static final /* synthetic */ boolean $assertionsDisabled = (!zzbmt.class.desiredAssertionStatus());
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<zzboa> zzLO() {
                zzbmj zzVc = zzboe.zzVc();
                zzbms zzbms = (zzbms) this.zzcdN.zzcdC.zzK(zzVc);
                List<zzboa> arrayList = new ArrayList();
                if (zzbms != null && (zzboe.isDefault() || zzbms.zzc(zzboe))) {
                    Object obj;
                    zzbqd zza = zzbms.zza(zzboe, zzbme, databaseError);
                    if (zzbms.isEmpty()) {
                        this.zzcdN.zzcdC = this.zzcdN.zzcdC.zzJ(zzVc);
                    }
                    List<zzboe> list = (List) zza.getFirst();
                    arrayList = (List) zza.zzZZ();
                    Object obj2 = null;
                    for (zzboe zzboe : list) {
                        this.zzcdN.zzcdB.zzh(zzboe);
                        obj = (obj2 != null || zzboe.zzYD()) ? 1 : null;
                        obj2 = obj;
                    }
                    zzbns zzd = this.zzcdN.zzcdC;
                    obj = (zzd.getValue() == null || !((zzbms) zzd.getValue()).zzXx()) ? null : 1;
                    Iterator it = zzVc.iterator();
                    zzbns zzbns = zzd;
                    Object obj3 = obj;
                    while (it.hasNext()) {
                        zzbns = zzbns.zze((zzbos) it.next());
                        obj = (obj3 != null || (zzbns.getValue() != null && ((zzbms) zzbns.getValue()).zzXx())) ? 1 : null;
                        if (obj != null) {
                            obj3 = obj;
                            break;
                        } else if (zzbns.isEmpty()) {
                            obj3 = obj;
                            break;
                        } else {
                            obj3 = obj;
                        }
                    }
                    if (obj2 != null && obj3 == null) {
                        zzbns zzI = this.zzcdN.zzcdC.zzI(zzVc);
                        if (!zzI.isEmpty()) {
                            for (zzbof zzbof : this.zzcdN.zza(zzI)) {
                                Object zzc = new zzc(this.zzcdN, zzbof);
                                this.zzcdN.zzcdH.zza(this.zzcdN.zzd(zzbof.zzYH()), zzc.zzceb, zzc, zzc);
                            }
                        }
                    }
                    if (obj3 == null && !list.isEmpty() && databaseError == null) {
                        if (obj2 != null) {
                            this.zzcdN.zzcdH.zza(this.zzcdN.zzd(zzboe), null);
                        } else {
                            for (zzboe zzboe2 : list) {
                                zzbmu zza2 = this.zzcdN.zze(zzboe2);
                                if ($assertionsDisabled || zza2 != null) {
                                    this.zzcdN.zzcdH.zza(this.zzcdN.zzd(zzboe2), zza2);
                                } else {
                                    throw new AssertionError();
                                }
                            }
                        }
                    }
                    this.zzcdN.zzX(list);
                }
                return arrayList;
            }
        });
    }

    private zzboe zzd(zzboe zzboe) {
        return (!zzboe.zzYD() || zzboe.isDefault()) ? zzboe : zzboe.zzN(zzboe.zzVc());
    }

    private zzbmu zze(zzboe zzboe) {
        return (zzbmu) this.zzcdF.get(zzboe);
    }

    public boolean isEmpty() {
        return this.zzcdC.isEmpty();
    }

    public List<? extends zzboa> zzXz() {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            {
                this.zzcdN = r1;
            }

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() throws Exception {
                this.zzcdN.zzcdB.zzVh();
                if (this.zzcdN.zzcdD.zzXI().isEmpty()) {
                    return Collections.emptyList();
                }
                return this.zzcdN.zza(new zzbnd(zzbmj.zzXf(), new zzbns(Boolean.valueOf(true)), true));
            }
        });
    }

    public List<? extends zzboa> zza(long j, boolean z, boolean z2, zzbpy zzbpy) {
        final boolean z3 = z2;
        final long j2 = j;
        final boolean z4 = z;
        final zzbpy zzbpy2 = zzbpy;
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                if (z3) {
                    this.zzcdN.zzcdB.zzaA(j2);
                }
                zzbmx zzaL = this.zzcdN.zzcdD.zzaL(j2);
                boolean zzaM = this.zzcdN.zzcdD.zzaM(j2);
                if (zzaL.isVisible() && !z4) {
                    Map zza = zzbmp.zza(zzbpy2);
                    if (zzaL.zzXF()) {
                        this.zzcdN.zzcdB.zzk(zzaL.zzVc(), zzbmp.zza(zzaL.zzXD(), zza));
                    } else {
                        this.zzcdN.zzcdB.zzc(zzaL.zzVc(), zzbmp.zza(zzaL.zzXE(), zza));
                    }
                }
                if (!zzaM) {
                    return Collections.emptyList();
                }
                zzbns zzb;
                zzbns zzYd = zzbns.zzYd();
                if (zzaL.zzXF()) {
                    zzb = zzYd.zzb(zzbmj.zzXf(), Boolean.valueOf(true));
                } else {
                    Iterator it = zzaL.zzXE().iterator();
                    zzb = zzYd;
                    while (it.hasNext()) {
                        zzb = zzb.zzb((zzbmj) ((Entry) it.next()).getKey(), Boolean.valueOf(true));
                    }
                }
                return this.zzcdN.zza(new zzbnd(zzaL.zzVc(), zzb, z4));
            }
        });
    }

    public List<? extends zzboa> zza(zzbmj zzbmj, zzbma zzbma, zzbma zzbma2, long j, boolean z) {
        final boolean z2 = z;
        final zzbmj zzbmj2 = zzbmj;
        final zzbma zzbma3 = zzbma;
        final long j2 = j;
        final zzbma zzbma4 = zzbma2;
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() throws Exception {
                if (z2) {
                    this.zzcdN.zzcdB.zza(zzbmj2, zzbma3, j2);
                }
                this.zzcdN.zzcdD.zza(zzbmj2, zzbma4, Long.valueOf(j2));
                return this.zzcdN.zza(new zzbnf(zzbnh.zzceJ, zzbmj2, zzbma4));
            }
        });
    }

    public List<? extends zzboa> zza(final zzbmj zzbmj, final zzbpe zzbpe, final zzbmu zzbmu) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                zzboe zza = this.zzcdN.zzb(zzbmu);
                if (zza == null) {
                    return Collections.emptyList();
                }
                zzbmj zza2 = zzbmj.zza(zza.zzVc(), zzbmj);
                this.zzcdN.zzcdB.zza(zza2.isEmpty() ? zza : zzboe.zzN(zzbmj), zzbpe);
                return this.zzcdN.zza(zza, new zzbni(zzbnh.zzc(zza.zzYG()), zza2, zzbpe));
            }
        });
    }

    public List<? extends zzboa> zza(zzbmj zzbmj, zzbpe zzbpe, zzbpe zzbpe2, long j, boolean z, boolean z2) {
        boolean z3 = z || !z2;
        zzbqg.zzb(z3, "We shouldn't be persisting non-visible writes.");
        final boolean z4 = z2;
        final zzbmj zzbmj2 = zzbmj;
        final zzbpe zzbpe3 = zzbpe;
        final long j2 = j;
        final zzbpe zzbpe4 = zzbpe2;
        final boolean z5 = z;
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                if (z4) {
                    this.zzcdN.zzcdB.zza(zzbmj2, zzbpe3, j2);
                }
                this.zzcdN.zzcdD.zza(zzbmj2, zzbpe4, Long.valueOf(j2), z5);
                return !z5 ? Collections.emptyList() : this.zzcdN.zza(new zzbni(zzbnh.zzceJ, zzbmj2, zzbpe4));
            }
        });
    }

    public List<? extends zzboa> zza(zzbmj zzbmj, List<zzbpj> list, zzbmu zzbmu) {
        zzboe zzb = zzb(zzbmu);
        if (zzb == null) {
            return Collections.emptyList();
        }
        if ($assertionsDisabled || zzbmj.equals(zzb.zzVc())) {
            zzbms zzbms = (zzbms) this.zzcdC.zzK(zzb.zzVc());
            if ($assertionsDisabled || zzbms != null) {
                zzbof zzb2 = zzbms.zzb(zzb);
                if ($assertionsDisabled || zzb2 != null) {
                    zzbpe zzYI = zzb2.zzYI();
                    zzbpe zzbpe = zzYI;
                    for (zzbpj zzr : list) {
                        zzbpe = zzr.zzr(zzbpe);
                    }
                    return zza(zzbmj, zzbpe, zzbmu);
                }
                throw new AssertionError("Missing view for query tag that we're tracking");
            }
            throw new AssertionError("Missing sync point for query tag that we're tracking");
        }
        throw new AssertionError();
    }

    public List<? extends zzboa> zza(final zzbmj zzbmj, final Map<zzbmj, zzbpe> map) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                zzbma zzaB = zzbma.zzaB(map);
                this.zzcdN.zzcdB.zzd(zzbmj, zzaB);
                return this.zzcdN.zza(new zzbnf(zzbnh.zzceK, zzbmj, zzaB));
            }
        });
    }

    public List<? extends zzboa> zza(final zzbmj zzbmj, final Map<zzbmj, zzbpe> map, final zzbmu zzbmu) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                zzboe zza = this.zzcdN.zzb(zzbmu);
                if (zza == null) {
                    return Collections.emptyList();
                }
                zzbmj zza2 = zzbmj.zza(zza.zzVc(), zzbmj);
                zzbma zzaB = zzbma.zzaB(map);
                this.zzcdN.zzcdB.zzd(zzbmj, zzaB);
                return this.zzcdN.zza(zza, new zzbnf(zzbnh.zzc(zza.zzYG()), zza2, zzaB));
            }
        });
    }

    public List<? extends zzboa> zza(final zzbmu zzbmu) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                zzboe zza = this.zzcdN.zzb(zzbmu);
                if (zza == null) {
                    return Collections.emptyList();
                }
                this.zzcdN.zzcdB.zzi(zza);
                return this.zzcdN.zza(zza, new zzbne(zzbnh.zzc(zza.zzYG()), zzbmj.zzXf()));
            }
        });
    }

    public List<zzboa> zza(zzboe zzboe, DatabaseError databaseError) {
        return zzb(zzboe, null, databaseError);
    }

    public void zza(zzboe zzboe, boolean z) {
        if (z && !this.zzcdG.contains(zzboe)) {
            zzg(new zzb(zzboe));
            this.zzcdG.add(zzboe);
        } else if (!z && this.zzcdG.contains(zzboe)) {
            zzh(new zzb(zzboe));
            this.zzcdG.remove(zzboe);
        }
    }

    public List<? extends zzboa> zzb(zzbmj zzbmj, List<zzbpj> list) {
        zzbms zzbms = (zzbms) this.zzcdC.zzK(zzbmj);
        if (zzbms == null) {
            return Collections.emptyList();
        }
        zzbof zzXy = zzbms.zzXy();
        if (zzXy == null) {
            return Collections.emptyList();
        }
        zzbpe zzYI = zzXy.zzYI();
        zzbpe zzbpe = zzYI;
        for (zzbpj zzr : list) {
            zzbpe = zzr.zzr(zzbpe);
        }
        return zzi(zzbmj, zzbpe);
    }

    public zzbpe zzc(zzbmj zzbmj, List<Long> list) {
        zzbpe zzs;
        zzbns zzbns = this.zzcdC;
        zzbns.getValue();
        zzbpe zzbpe = null;
        zzbmj zzXf = zzbmj.zzXf();
        zzbns zzbns2 = zzbns;
        zzbmj zzbmj2 = zzbmj;
        while (true) {
            zzbos zzXi = zzbmj2.zzXi();
            zzbmj zzXj = zzbmj2.zzXj();
            zzbmj2 = zzXf.zza(zzXi);
            zzbmj zza = zzbmj.zza(zzbmj2, zzbmj);
            zzbns2 = zzXi != null ? zzbns2.zze(zzXi) : zzbns.zzYd();
            zzbms zzbms = (zzbms) zzbns2.getValue();
            zzs = zzbms != null ? zzbms.zzs(zza) : zzbpe;
            if (!zzXj.isEmpty() && zzs == null) {
                zzbpe = zzs;
                zzXf = zzbmj2;
                zzbmj2 = zzXj;
            }
        }
        return this.zzcdD.zza(zzbmj, zzs, (List) list, true);
    }

    public List<? extends zzboa> zzg(final zzbme zzbme) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            static final /* synthetic */ boolean $assertionsDisabled = (!zzbmt.class.desiredAssertionStatus());
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                zzbms zzbms;
                zzbpe zzbpe;
                zzbms zzbms2;
                zzbnw zzbnw;
                zzboe zzWD = zzbme.zzWD();
                zzbmj zzVc = zzWD.zzVc();
                zzbpe zzbpe2 = null;
                zzbmj zzbmj = zzVc;
                zzbns zzd = this.zzcdN.zzcdC;
                boolean z = false;
                while (!zzd.isEmpty()) {
                    boolean z2;
                    zzbpe zzbpe3;
                    zzbms = (zzbms) zzd.getValue();
                    if (zzbms != null) {
                        if (zzbpe2 == null) {
                            zzbpe2 = zzbms.zzs(zzbmj);
                        }
                        z2 = z || zzbms.zzXx();
                        zzbpe3 = zzbpe2;
                    } else {
                        z2 = z;
                        zzbpe3 = zzbpe2;
                    }
                    zzd = zzd.zze(zzbmj.isEmpty() ? zzbos.zzjb("") : zzbmj.zzXi());
                    zzbmj = zzbmj.zzXj();
                    zzbpe2 = zzbpe3;
                    z = z2;
                }
                zzbms = (zzbms) this.zzcdN.zzcdC.zzK(zzVc);
                zzbms zzbms3;
                boolean z3;
                if (zzbms == null) {
                    zzbms = new zzbms(this.zzcdN.zzcdB);
                    this.zzcdN.zzcdC = this.zzcdN.zzcdC.zzb(zzVc, (Object) zzbms);
                    zzbms3 = zzbms;
                    zzbpe = zzbpe2;
                    z3 = z;
                    zzbms2 = zzbms3;
                } else {
                    z = z || zzbms.zzXx();
                    if (zzbpe2 == null) {
                        zzbpe2 = zzbms.zzs(zzbmj.zzXf());
                    }
                    zzbms3 = zzbms;
                    zzbpe = zzbpe2;
                    z3 = z;
                    zzbms2 = zzbms3;
                }
                this.zzcdN.zzcdB.zzg(zzWD);
                if (zzbpe != null) {
                    zzbnw = new zzbnw(zzboz.zza(zzbpe, zzWD.zzYz()), true, false);
                } else {
                    zzbnw zzf = this.zzcdN.zzcdB.zzf(zzWD);
                    if (zzf.zzYg()) {
                        zzbnw = zzf;
                    } else {
                        zzbpe zzZp = zzbox.zzZp();
                        Iterator it = this.zzcdN.zzcdC.zzI(zzVc).zzYe().iterator();
                        while (it.hasNext()) {
                            Entry entry = (Entry) it.next();
                            zzbms zzbms4 = (zzbms) ((zzbns) entry.getValue()).getValue();
                            if (zzbms4 != null) {
                                zzbpe zzs = zzbms4.zzs(zzbmj.zzXf());
                                if (zzs != null) {
                                    zzbpe = zzZp.zze((zzbos) entry.getKey(), zzs);
                                    zzZp = zzbpe;
                                }
                            }
                            zzbpe = zzZp;
                            zzZp = zzbpe;
                        }
                        for (zzbpd zzbpd : zzf.zzUY()) {
                            if (!zzZp.zzk(zzbpd.zzZz())) {
                                zzZp = zzZp.zze(zzbpd.zzZz(), zzbpd.zzUY());
                            }
                        }
                        zzbnw = new zzbnw(zzboz.zza(zzZp, zzWD.zzYz()), false, false);
                    }
                }
                boolean zzc = zzbms2.zzc(zzWD);
                if (!(zzc || zzWD.zzYD())) {
                    if ($assertionsDisabled || !this.zzcdN.zzcdF.containsKey(zzWD)) {
                        zzbmu zzf2 = this.zzcdN.zzXA();
                        this.zzcdN.zzcdF.put(zzWD, zzf2);
                        this.zzcdN.zzcdE.put(zzf2, zzWD);
                    } else {
                        throw new AssertionError("View does not exist but we have a tag");
                    }
                }
                List<? extends zzboa> zza = zzbms2.zza(zzbme, this.zzcdN.zzcdD.zzu(zzVc), zzbnw);
                if (!(zzc || r4)) {
                    this.zzcdN.zza(zzWD, zzbms2.zzb(zzWD));
                }
                return zza;
            }
        });
    }

    public List<zzboa> zzh(zzbme zzbme) {
        return zzb(zzbme.zzWD(), zzbme, null);
    }

    public List<? extends zzboa> zzi(final zzbmj zzbmj, final zzbpe zzbpe) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                this.zzcdN.zzcdB.zza(zzboe.zzN(zzbmj), zzbpe);
                return this.zzcdN.zza(new zzbni(zzbnh.zzceK, zzbmj, zzbpe));
            }
        });
    }

    public List<? extends zzboa> zzt(final zzbmj zzbmj) {
        return (List) this.zzcdB.zzf(new Callable<List<? extends zzboa>>(this) {
            final /* synthetic */ zzbmt zzcdN;

            public /* synthetic */ Object call() throws Exception {
                return zzLO();
            }

            public List<? extends zzboa> zzLO() {
                this.zzcdN.zzcdB.zzi(zzboe.zzN(zzbmj));
                return this.zzcdN.zza(new zzbne(zzbnh.zzceK, zzbmj));
            }
        });
    }
}
