package com.google.android.gms.internal;

import com.google.android.gms.internal.zzboq.zza;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.Logger.Level;

public class zzbmd extends zzbmc {
    public synchronized void setLogLevel(Level level) {
        zzWN();
        switch (level) {
            case DEBUG:
                this.zzcbO = zza.DEBUG;
                break;
            case INFO:
                this.zzcbO = zza.INFO;
                break;
            case WARN:
                this.zzcbO = zza.WARN;
                break;
            case ERROR:
                this.zzcbO = zza.ERROR;
                break;
            case NONE:
                this.zzcbO = zza.NONE;
                break;
            default:
                String valueOf = String.valueOf(level);
                throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 19).append("Unknown log level: ").append(valueOf).toString());
        }
    }

    public synchronized void setPersistenceEnabled(boolean z) {
        zzWN();
        this.zzbZx = z;
    }

    public synchronized void zzf(FirebaseApp firebaseApp) {
        this.zzbYm = firebaseApp;
    }

    public synchronized void zziZ(String str) {
        zzWN();
        if (str == null || str.isEmpty()) {
            throw new IllegalArgumentException("Session identifier is not allowed to be empty or null!");
        }
        this.zzcbN = str;
    }
}
