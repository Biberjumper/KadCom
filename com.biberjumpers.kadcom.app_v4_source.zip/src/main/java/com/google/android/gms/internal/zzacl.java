package com.google.android.gms.internal;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public abstract class zzacl extends zzack implements SafeParcelable {
    public final int describeContents() {
        return 0;
    }

    public Object zzdw(String str) {
        return null;
    }

    public boolean zzdx(String str) {
        return false;
    }
}
