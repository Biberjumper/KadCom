package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class zzbmn {
    private static final zzbmn zzcdn = new zzbmn();
    private final Map<zzbmc, Map<String, zzbml>> zzcdo = new HashMap();

    /* renamed from: com.google.android.gms.internal.zzbmn$1 */
    class AnonymousClass1 implements Runnable {
        final /* synthetic */ zzbml zzccE;

        AnonymousClass1(zzbml zzbml) {
            this.zzccE = zzbml;
        }

        public void run() {
            this.zzccE.interrupt();
        }
    }

    /* renamed from: com.google.android.gms.internal.zzbmn$2 */
    class AnonymousClass2 implements Runnable {
        final /* synthetic */ zzbml zzccE;

        AnonymousClass2(zzbml zzbml) {
            this.zzccE = zzbml;
        }

        public void run() {
            this.zzccE.resume();
        }
    }

    public static zzbml zza(zzbmc zzbmc, zzbmm zzbmm, FirebaseDatabase firebaseDatabase) throws DatabaseException {
        return zzcdn.zzb(zzbmc, zzbmm, firebaseDatabase);
    }

    private zzbml zzb(zzbmc zzbmc, zzbmm zzbmm, FirebaseDatabase firebaseDatabase) throws DatabaseException {
        zzbml zzbml;
        zzbmc.zzWz();
        String str = zzbmm.zzbZA;
        String str2 = zzbmm.zzaFs;
        str2 = new StringBuilder((String.valueOf(str).length() + 9) + String.valueOf(str2).length()).append("https://").append(str).append("/").append(str2).toString();
        synchronized (this.zzcdo) {
            if (!this.zzcdo.containsKey(zzbmc)) {
                this.zzcdo.put(zzbmc, new HashMap());
            }
            Map map = (Map) this.zzcdo.get(zzbmc);
            if (map.containsKey(str2)) {
                throw new IllegalStateException("createLocalRepo() called for existing repo.");
            }
            zzbml = new zzbml(zzbmm, zzbmc, firebaseDatabase);
            map.put(str2, zzbml);
        }
        return zzbml;
    }

    public static void zzd(zzbmc zzbmc) {
        zzcdn.zzf(zzbmc);
    }

    public static void zze(zzbmc zzbmc) {
        zzcdn.zzg(zzbmc);
    }

    private void zzf(final zzbmc zzbmc) {
        zzbmo zzWR = zzbmc.zzWR();
        if (zzWR != null) {
            zzWR.zzs(new Runnable(this) {
                final /* synthetic */ zzbmn zzcdq;

                public void run() {
                    synchronized (this.zzcdq.zzcdo) {
                        if (this.zzcdq.zzcdo.containsKey(zzbmc)) {
                            Object obj = 1;
                            for (zzbml zzbml : ((Map) this.zzcdq.zzcdo.get(zzbmc)).values()) {
                                zzbml.interrupt();
                                Object obj2 = (obj == null || zzbml.zzXq()) ? null : 1;
                                obj = obj2;
                            }
                            if (obj != null) {
                                zzbmc.stop();
                            }
                        }
                    }
                }
            });
        }
    }

    private void zzg(final zzbmc zzbmc) {
        zzbmo zzWR = zzbmc.zzWR();
        if (zzWR != null) {
            zzWR.zzs(new Runnable(this) {
                final /* synthetic */ zzbmn zzcdq;

                public void run() {
                    synchronized (this.zzcdq.zzcdo) {
                        if (this.zzcdq.zzcdo.containsKey(zzbmc)) {
                            for (zzbml resume : ((Map) this.zzcdq.zzcdo.get(zzbmc)).values()) {
                                resume.resume();
                            }
                        }
                    }
                }
            });
        }
    }

    public static void zzk(zzbml zzbml) {
        zzbml.zzs(new AnonymousClass1(zzbml));
    }

    public static void zzl(zzbml zzbml) {
        zzbml.zzs(new AnonymousClass2(zzbml));
    }
}
