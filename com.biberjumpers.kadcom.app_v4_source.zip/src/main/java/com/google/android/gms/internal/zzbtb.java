package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class zzbtb extends zzbsd<Object> {
    public static final zzbse zzcnX = new zzbse() {
        public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
            return zzbth.zzacb() == Object.class ? new zzbtb(zzbrl) : null;
        }
    };
    private final zzbrl zzcmT;

    private zzbtb(zzbrl zzbrl) {
        this.zzcmT = zzbrl;
    }

    public void zza(zzbtk zzbtk, Object obj) throws IOException {
        if (obj == null) {
            zzbtk.zzaca();
            return;
        }
        zzbsd zzj = this.zzcmT.zzj(obj.getClass());
        if (zzj instanceof zzbtb) {
            zzbtk.zzabY();
            zzbtk.zzabZ();
            return;
        }
        zzj.zza(zzbtk, obj);
    }

    public Object zzb(zzbti zzbti) throws IOException {
        switch (zzbti.zzabQ()) {
            case BEGIN_ARRAY:
                List arrayList = new ArrayList();
                zzbti.beginArray();
                while (zzbti.hasNext()) {
                    arrayList.add(zzb(zzbti));
                }
                zzbti.endArray();
                return arrayList;
            case BEGIN_OBJECT:
                Map zzbsp = new zzbsp();
                zzbti.beginObject();
                while (zzbti.hasNext()) {
                    zzbsp.put(zzbti.nextName(), zzb(zzbti));
                }
                zzbti.endObject();
                return zzbsp;
            case STRING:
                return zzbti.nextString();
            case NUMBER:
                return Double.valueOf(zzbti.nextDouble());
            case BOOLEAN:
                return Boolean.valueOf(zzbti.nextBoolean());
            case NULL:
                zzbti.nextNull();
                return null;
            default:
                throw new IllegalStateException();
        }
    }
}
