package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbrn<T> {
    T zza(Type type);
}
