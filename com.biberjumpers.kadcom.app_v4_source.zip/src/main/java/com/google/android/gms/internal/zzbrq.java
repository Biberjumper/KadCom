package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbrq<T> {
    T zzb(zzbrr zzbrr, Type type, zzbrp zzbrp) throws zzbrv;
}
