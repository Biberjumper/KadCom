package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public final class zzbtc implements zzbse {
    private final zzbsm zzcmD;
    private final zzbrk zzcmF;
    private final zzbsl zzcmu;

    static abstract class zzb {
        final String name;
        final boolean zzcov;
        final boolean zzcow;

        protected zzb(String str, boolean z, boolean z2) {
            this.name = str;
            this.zzcov = z;
            this.zzcow = z2;
        }

        abstract void zza(zzbti zzbti, Object obj) throws IOException, IllegalAccessException;

        abstract void zza(zzbtk zzbtk, Object obj) throws IOException, IllegalAccessException;

        abstract boolean zzaQ(Object obj) throws IOException, IllegalAccessException;
    }

    public static final class zza<T> extends zzbsd<T> {
        private final zzbsq<T> zzcob;
        private final Map<String, zzb> zzcou;

        private zza(zzbsq<T> zzbsq, Map<String, zzb> map) {
            this.zzcob = zzbsq;
            this.zzcou = map;
        }

        public void zza(zzbtk zzbtk, T t) throws IOException {
            if (t == null) {
                zzbtk.zzaca();
                return;
            }
            zzbtk.zzabY();
            try {
                for (zzb zzb : this.zzcou.values()) {
                    if (zzb.zzaQ(t)) {
                        zzbtk.zzjW(zzb.name);
                        zzb.zza(zzbtk, (Object) t);
                    }
                }
                zzbtk.zzabZ();
            } catch (IllegalAccessException e) {
                throw new AssertionError();
            }
        }

        public T zzb(zzbti zzbti) throws IOException {
            if (zzbti.zzabQ() == zzbtj.NULL) {
                zzbti.nextNull();
                return null;
            }
            T zzabJ = this.zzcob.zzabJ();
            try {
                zzbti.beginObject();
                while (zzbti.hasNext()) {
                    zzb zzb = (zzb) this.zzcou.get(zzbti.nextName());
                    if (zzb == null || !zzb.zzcow) {
                        zzbti.skipValue();
                    } else {
                        zzb.zza(zzbti, (Object) zzabJ);
                    }
                }
                zzbti.endObject();
                return zzabJ;
            } catch (Throwable e) {
                throw new zzbsa(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }
    }

    public zzbtc(zzbsl zzbsl, zzbrk zzbrk, zzbsm zzbsm) {
        this.zzcmu = zzbsl;
        this.zzcmF = zzbrk;
        this.zzcmD = zzbsm;
    }

    private zzbsd<?> zza(zzbrl zzbrl, Field field, zzbth<?> zzbth) {
        zzbsf zzbsf = (zzbsf) field.getAnnotation(zzbsf.class);
        if (zzbsf != null) {
            zzbsd<?> zza = zzbsx.zza(this.zzcmu, zzbrl, zzbth, zzbsf);
            if (zza != null) {
                return zza;
            }
        }
        return zzbrl.zza((zzbth) zzbth);
    }

    private zzb zza(zzbrl zzbrl, Field field, String str, zzbth<?> zzbth, boolean z, boolean z2) {
        final boolean zzk = zzbsr.zzk(zzbth.zzacb());
        final zzbrl zzbrl2 = zzbrl;
        final Field field2 = field;
        final zzbth<?> zzbth2 = zzbth;
        return new zzb(this, str, z, z2) {
            final zzbsd<?> zzcoo = this.zzcot.zza(zzbrl2, field2, zzbth2);
            final /* synthetic */ zzbtc zzcot;

            void zza(zzbti zzbti, Object obj) throws IOException, IllegalAccessException {
                Object zzb = this.zzcoo.zzb(zzbti);
                if (zzb != null || !zzk) {
                    field2.set(obj, zzb);
                }
            }

            void zza(zzbtk zzbtk, Object obj) throws IOException, IllegalAccessException {
                new zzbtf(zzbrl2, this.zzcoo, zzbth2.zzacc()).zza(zzbtk, field2.get(obj));
            }

            public boolean zzaQ(Object obj) throws IOException, IllegalAccessException {
                return this.zzcov && field2.get(obj) != obj;
            }
        };
    }

    static List<String> zza(zzbrk zzbrk, Field field) {
        zzbsg zzbsg = (zzbsg) field.getAnnotation(zzbsg.class);
        List<String> linkedList = new LinkedList();
        if (zzbsg == null) {
            linkedList.add(zzbrk.zzc(field));
        } else {
            linkedList.add(zzbsg.value());
            for (Object add : zzbsg.zzabH()) {
                linkedList.add(add);
            }
        }
        return linkedList;
    }

    private Map<String, zzb> zza(zzbrl zzbrl, zzbth<?> zzbth, Class<?> cls) {
        Map<String, zzb> linkedHashMap = new LinkedHashMap();
        if (cls.isInterface()) {
            return linkedHashMap;
        }
        Type zzacc = zzbth.zzacc();
        Class zzacb;
        while (zzacb != Object.class) {
            for (Field field : zzacb.getDeclaredFields()) {
                boolean zza = zza(field, true);
                boolean zza2 = zza(field, false);
                if (zza || zza2) {
                    field.setAccessible(true);
                    Type zza3 = zzbsk.zza(r19.zzacc(), zzacb, field.getGenericType());
                    List zzd = zzd(field);
                    zzb zzb = null;
                    int i = 0;
                    while (i < zzd.size()) {
                        String str = (String) zzd.get(i);
                        if (i != 0) {
                            zza = false;
                        }
                        zzb zzb2 = (zzb) linkedHashMap.put(str, zza(zzbrl, field, str, zzbth.zzl(zza3), zza, zza2));
                        if (zzb != null) {
                            zzb2 = zzb;
                        }
                        i++;
                        zzb = zzb2;
                    }
                    if (zzb != null) {
                        String valueOf = String.valueOf(zzacc);
                        String str2 = zzb.name;
                        throw new IllegalArgumentException(new StringBuilder((String.valueOf(valueOf).length() + 37) + String.valueOf(str2).length()).append(valueOf).append(" declares multiple JSON fields named ").append(str2).toString());
                    }
                }
            }
            zzbth zzl = zzbth.zzl(zzbsk.zza(zzl.zzacc(), zzacb, zzacb.getGenericSuperclass()));
            zzacb = zzl.zzacb();
        }
        return linkedHashMap;
    }

    static boolean zza(Field field, boolean z, zzbsm zzbsm) {
        return (zzbsm.zza(field.getType(), z) || zzbsm.zza(field, z)) ? false : true;
    }

    private List<String> zzd(Field field) {
        return zza(this.zzcmF, field);
    }

    public <T> zzbsd<T> zza(zzbrl zzbrl, zzbth<T> zzbth) {
        Class zzacb = zzbth.zzacb();
        return !Object.class.isAssignableFrom(zzacb) ? null : new zza(this.zzcmu.zzb(zzbth), zza(zzbrl, (zzbth) zzbth, zzacb));
    }

    public boolean zza(Field field, boolean z) {
        return zza(field, z, this.zzcmD);
    }
}
