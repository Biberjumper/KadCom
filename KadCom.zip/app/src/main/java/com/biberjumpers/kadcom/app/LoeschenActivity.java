package com.biberjumpers.kadcom.app;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;

public class LoeschenActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> bann_map = new HashMap<>();
	private double delete = 0;
	
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	private ArrayList<String> str1 = new ArrayList<>();
	private ArrayList<String> str2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap2 = new ArrayList<>();
	
	private LinearLayout linear_oben;
	private LinearLayout linear_ganz;
	private ListView listview_name;
	private ListView listview_chat_user;
	private ListView listview_app_gebannt;
	private Button zuruek;
	private TextView textview2;
	private TextView textview1;
	private Button loeschen;
	
	private DatabaseReference Name = _firebase.getReference("Name");
	private ChildEventListener _Name_child_listener;
	private SharedPreferences namedata;
	private DatabaseReference Chat_user = _firebase.getReference("Chat_user");
	private ChildEventListener _Chat_user_child_listener;
	private SharedPreferences Usernumber;
	private DatabaseReference App_gebannte = _firebase.getReference("App_gebannte");
	private ChildEventListener _App_gebannte_child_listener;
	private Calendar Calender = Calendar.getInstance();
	private Intent i = new Intent();
	private TimerTask Timer;
	private TimerTask Timer2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.loeschen);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear_oben = (LinearLayout) findViewById(R.id.linear_oben);
		linear_ganz = (LinearLayout) findViewById(R.id.linear_ganz);
		listview_name = (ListView) findViewById(R.id.listview_name);
		listview_chat_user = (ListView) findViewById(R.id.listview_chat_user);
		listview_app_gebannt = (ListView) findViewById(R.id.listview_app_gebannt);
		zuruek = (Button) findViewById(R.id.zuruek);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		loeschen = (Button) findViewById(R.id.loeschen);
		namedata = getSharedPreferences("namedata", Activity.MODE_PRIVATE);
		Usernumber = getSharedPreferences("Usernumber", Activity.MODE_PRIVATE);
		
		zuruek.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				finish();
			}
		});
		
		loeschen.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Calender = Calendar.getInstance();
				bann_map = new HashMap<>();
				bann_map.put("Gebannt von", "der App. Zeit: ".concat(new SimpleDateFormat("yyyy/MM/dd hh:mm a").format(Calender.getTime())));
				bann_map.put("User", Usernumber.getString("Usernumber", ""));
				App_gebannte.push().updateChildren(bann_map);
				bann_map.clear();
				loeschen.setVisibility(View.GONE);
				textview1.setVisibility(View.GONE);
				zuruek.setVisibility(View.GONE);
				textview2.setVisibility(View.VISIBLE);
				delete = 1;
			}
		});
		
		_Name_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Name.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap1 = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap1.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						str1.clear();
						for (DataSnapshot dshot: _dataSnapshot.getChildren()){
							
							str1.add(dshot.getKey());
							
						}
						listview_name.setAdapter(new Listview_nameAdapter(listmap1));
						((BaseAdapter)listview_name.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Name.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap1 = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap1.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						str1.clear();
						for (DataSnapshot dshot: _dataSnapshot.getChildren()){
							
							str1.add(dshot.getKey());
							
						}
						listview_name.setAdapter(new Listview_nameAdapter(listmap1));
						((BaseAdapter)listview_name.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final String _errorCode = String.valueOf(_param1.getCode());
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Name.addChildEventListener(_Name_child_listener);
		
		_Chat_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Chat_user.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap2 = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap2.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						str2.clear();
						for (DataSnapshot dshot: _dataSnapshot.getChildren()){
							
							str2.add(dshot.getKey());
							
						}
						listview_chat_user.setAdapter(new Listview_chat_userAdapter(listmap2));
						((BaseAdapter)listview_chat_user.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Chat_user.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap2 = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap2.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						str2.clear();
						for (DataSnapshot dshot: _dataSnapshot.getChildren()){
							
							str2.add(dshot.getKey());
							
						}
						listview_chat_user.setAdapter(new Listview_chat_userAdapter(listmap2));
						((BaseAdapter)listview_chat_user.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final String _errorCode = String.valueOf(_param1.getCode());
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Chat_user.addChildEventListener(_Chat_user_child_listener);
		
		_App_gebannte_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final String _errorCode = String.valueOf(_param1.getCode());
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		App_gebannte.addChildEventListener(_App_gebannte_child_listener);
	}
	private void initializeLogic() {
		textview2.setVisibility(View.GONE);
		delete = 0;
		textview2.setText("Du kannst die App jetzt schließen und manuell löschen. Alle Daten in der Firebase von dir werden gelöscht, außer Nachrichten im Chat und die Statistiken.\nDu wurdest im übrigen aus der App gebannt um Fehler vor zu beugen. Um entbannt zu werden, musst du die App neu herunterladen.");
	}
	
	@Override
	public void onBackPressed() {
		
	}
	private void _customToast (final String _text) {
		LayoutInflater inflater = getLayoutInflater(); View toastLayout = inflater.inflate(R.layout.custom_toast1, null);
		
		TextView textview1 = (TextView) toastLayout.findViewById(R.id.textview1);
		textview1.setText(_text);
		LinearLayout linear1 = (LinearLayout) toastLayout.findViewById(R.id.linear1);
		
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#00B0FF"));
		gd.setCornerRadius(60);
		gd.setStroke(2, Color.parseColor("#ff0000"));
		linear1.setBackground(gd);
		
		Toast toast = new Toast(getApplicationContext()); toast.setDuration(Toast.LENGTH_LONG);
		toast.setView(toastLayout);
		toast.show();
	}
	
	
	public class Listview_nameAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview_nameAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.user_custom, null);
			}
			
			final LinearLayout linear_name = (LinearLayout) _v.findViewById(R.id.linear_name);
			final TextView name = (TextView) _v.findViewById(R.id.name);
			
			Timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (delete == 1) {
								if (listmap1.get((int)_position).get("Name").toString().equals(namedata.getString("nanedata", "").concat(" (".concat(Usernumber.getString("Usernumber", "").concat(")")))) || listmap1.get((int)_position).get("Name").toString().equals(namedata.getString("nanedata", "").concat(" (".concat(Usernumber.getString("Usernumber", "").concat(") ✅"))))) {
									Name.child(str1.get((int)(_position))).removeValue();
								}
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(Timer, (int)(0), (int)(500));
			
			return _v;
		}
	}
	
	public class Listview_chat_userAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview_chat_userAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.user, null);
			}
			
			final LinearLayout linear = (LinearLayout) _v.findViewById(R.id.linear);
			final TextView name = (TextView) _v.findViewById(R.id.name);
			
			Timer2 = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (delete == 1) {
								if (listmap2.get((int)_position).get("User").toString().equals(namedata.getString("nanedata", "").concat(" (".concat(Usernumber.getString("Usernumber", "").concat(")"))))) {
									Chat_user.child(str2.get((int)(_position))).removeValue();
								}
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(Timer2, (int)(0), (int)(500));
			
			return _v;
		}
	}
	
	public class Listview_app_gebanntAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview_app_gebanntAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.banned, null);
			}
			
			final LinearLayout linear = (LinearLayout) _v.findViewById(R.id.linear);
			final TextView banned_user = (TextView) _v.findViewById(R.id.banned_user);
			
			
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
